/*
    SalesApplet.java

    NOTE: This file is a generated file.
          Do not modify it by hand!
*/
// add your custom import statements here

public class SalesApplet extends ImpactMotorsMainForm 
{
    public SalesApplet()
    {
        super();
    }
    public void init()
    {
        super.init();
        addNotify();

        cd = new ProgressWindow(getFrame(this),"Applet Loading", this);
        try { cd.create();} catch (java.lang.Exception e){}

        createAppletForm();

        cd.destroy();

    }
    public void createAppletForm()
    {
        try {
            create();
        } catch ( java.lang.Exception __e ) {}
    }
    public static void main(String args[])
    {
        SalesApplet applet = new SalesApplet();
        _SalesApplet_frame f = new _SalesApplet_frame();
        f.setResizable(false);
        f.add(applet);
        f.addNotify();
        java.awt.Insets insets = f.insets();
        applet.setMainForm(true);
        applet.init();
        applet.move(insets.left,insets.top);
        f.resize(applet.preferredSize());
        applet.resize(applet.preferredSize());
        f.show();
    }
    // add your data members here
   ProgressWindow cd=null;
}

