/*
    VehicleOptions.java

    NOTE: This file is a generated file.
          Do not modify it by hand!
*/
import java.awt.Color;
import java.awt.Event;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Rectangle;
import java.awt.Insets;
import java.lang.Math;
import java.lang.String;

// custom imports for VehicleOptions
// add your custom import statements here

import java.util.Vector;
import java.util.Enumeration;
import powersoft.powerj.ui.grid.GridEnum;
import java.net.MalformedURLException;
import powersoft.powerj.ui.grid.GString;


class VehicleOptions extends java.awt.Dialog implements powersoft.powerj.ui.grid.SelectListener
{
    public Rectangle DURectangle( int x, int y, int w, int h )
    {
        String        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        FontMetrics   fm = getFontMetrics( getFont() );
        double        fw = ( fm != null ) ? ( fm.stringWidth( alphabet ) / alphabet.length() ) : 0;
        double        fh = ( fm != null ) ? ( fm.getHeight() / 2.0 ) : 0.0;

        return new Rectangle( (int) Math.round( ( (double)fw * (double)x ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)y ) / 4.0 ),
                              (int) Math.round( ( (double)fw * (double)w ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)h ) / 4.0 ) );
    }

    public void DUPositionComponent( java.awt.Component comp, int x, int y, int w, int h, java.awt.Insets formInsets )
    {
        Rectangle     rect = DURectangle( x, y, w, h );
        if( formInsets != null ) {
             rect.x += formInsets.left;
             rect.y += formInsets.top;
        }
        comp.reshape( rect.x, rect.y, rect.width, rect.height );
    }

    public void setMainForm( boolean isMainForm )
    {
        __mainForm = isMainForm;
    }
    public boolean isMainForm()
    {
        return __mainForm;
    }
    public boolean create() throws java.lang.Exception
    {
        setTitle("Vehicle Options Selector");

        setResizable(false);

        setFont( new Font( "Dialog", Font.PLAIN, 12 ) );

        boolean retval = true;
        if( getPeer() == null ) {
            addNotify();
        }
        Insets formInsets = insets();
        setBackground( Color.lightGray );
        setForeground( Color.black );

        powersoft.powerj.ui.ResizePercentLayout layout = new powersoft.powerj.ui.ResizePercentLayout();
        setLayout( layout );
        powersoft.powerj.ui.ResizePercentLayout groupb_availoptions_layout = new powersoft.powerj.ui.ResizePercentLayout();
        groupb_availoptions.setLayout( groupb_availoptions_layout );
        add(groupb_availoptions);
        groupb_availoptions.add(grid_availableoptions);
        add(label_1);
        powersoft.powerj.ui.ResizePercentLayout groupb_current_layout = new powersoft.powerj.ui.ResizePercentLayout();
        groupb_current.setLayout( groupb_current_layout );
        add(groupb_current);
        groupb_current.add(grid_currentoptions);
        groupb_current.add(label_2);
        groupb_current.add(textf_total);
        add(pictbttn_add);
        add(pictbttn_delete);
        add(pictbttn_ok);
        add(pictbttn_cancel);
        DUPositionComponent( this, 103, 102, 439, 283, null );

        DUPositionComponent( groupb_availoptions, 5, 10, 322, 100, formInsets );
        groupb_availoptions.setBackground( Color.lightGray );
        groupb_availoptions.setForeground( Color.black );
        groupb_availoptions.enable(true);
        groupb_availoptions.show();

        groupb_availoptions.setText("Available Options ");

        grid_availableoptions.addSelectListener(this);
        DUPositionComponent( grid_availableoptions, 5, 20, 305, 70, null );
        grid_availableoptions.setNumColumns( 5 );
        grid_availableoptions.setNumRows( 10 );
        grid_availableoptions.setShowHorizontalHeader( true );
        grid_availableoptions.setShowVerticalHeader( false );
        grid_availableoptions.setShowColumnLines( true );
        grid_availableoptions.setShowRowLines( true );
        grid_availableoptions.setFullRowSelection( true );
        grid_availableoptions.setLiveEditMode( false );
        grid_availableoptions.setMultipleSelection( true );
        grid_availableoptions.setResizableColumns( false );
        grid_availableoptions.setResizableRows( false );
        grid_availableoptions.setReadOnly( true );
        grid_availableoptions.setBackground( powersoft.powerj.ui.grid.GridEnum.ALLCELLS, powersoft.powerj.ui.grid.GridEnum.ALLCELLS, Color.lightGray );
        grid_availableoptions.setForeground( Color.black );
        grid_availableoptions.enable(true);
        grid_availableoptions.show();

        grid_availableoptions.setHorizSBDisplay( powersoft.powerj.ui.grid.GridEnum.SBDISPLAY_NEVER );
        grid_availableoptions.setVertSBDisplay( powersoft.powerj.ui.grid.GridEnum.SBDISPLAY_AS_NEEDED );

        DUPositionComponent( label_1, 76, 299, 41, 10, formInsets );
        label_1.setAlignment(java.awt.Label.LEFT);
        label_1.setText( "Total" );
        label_1.setBackground( Color.lightGray );
        label_1.setForeground( Color.black );
        label_1.enable(true);
        label_1.show();


        DUPositionComponent( groupb_current, 5, 140, 320, 120, formInsets );
        groupb_current.setBackground( Color.lightGray );
        groupb_current.setForeground( Color.black );
        groupb_current.enable(true);
        groupb_current.show();

        groupb_current.setText("Your Current Selection");

        grid_currentoptions.addSelectListener(this);
        DUPositionComponent( grid_currentoptions, 5, 15, 300, 80, null );
        grid_currentoptions.setNumColumns( 5 );
        grid_currentoptions.setNumRows( 10 );
        grid_currentoptions.setShowHorizontalHeader( true );
        grid_currentoptions.setShowVerticalHeader( false );
        grid_currentoptions.setShowColumnLines( true );
        grid_currentoptions.setShowRowLines( true );
        grid_currentoptions.setFullRowSelection( true );
        grid_currentoptions.setLiveEditMode( false );
        grid_currentoptions.setMultipleSelection( false );
        grid_currentoptions.setResizableColumns( false );
        grid_currentoptions.setResizableRows( false );
        grid_currentoptions.setReadOnly( true );
        grid_currentoptions.setBackground( powersoft.powerj.ui.grid.GridEnum.ALLCELLS, powersoft.powerj.ui.grid.GridEnum.ALLCELLS, Color.lightGray );
        grid_currentoptions.setForeground( Color.black );
        grid_currentoptions.enable(true);
        grid_currentoptions.show();

        grid_currentoptions.setHorizSBDisplay( powersoft.powerj.ui.grid.GridEnum.SBDISPLAY_NEVER );
        grid_currentoptions.setVertSBDisplay( powersoft.powerj.ui.grid.GridEnum.SBDISPLAY_AS_NEEDED );

        DUPositionComponent( label_2, 59, 105, 46, 10, null );
        label_2.setAlignment(java.awt.Label.LEFT);
        label_2.setText( "Total" );
        label_2.setFont( new Font( "Dialog", Font.PLAIN, 10 ) );
        label_2.setBackground( Color.lightGray );
        label_2.setForeground( Color.black );
        label_2.enable(true);
        label_2.show();


        DUPositionComponent( textf_total, 10, 105, 50, 12, null );
        textf_total.setBackground( Color.lightGray );
        textf_total.setForeground( Color.black );
        textf_total.enable(true);
        textf_total.show();


        DUPositionComponent( pictbttn_add, 340, 145, 88, 40, formInsets );
        pictbttn_add.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        pictbttn_add.setBackground( Color.lightGray );
        pictbttn_add.setForeground( Color.black );
        pictbttn_add.enable(false);
        pictbttn_add.show();

        Rectangle pictbttn_add_size_rect = DURectangle( 0, 0, 88, 40);
        pictbttn_add.resize(pictbttn_add_size_rect.width,pictbttn_add_size_rect.height);
        pictbttn_add.setLabel("Add Option");
        pictbttn_add.setLabelPosition( powersoft.powerj.ui.PictureButton.LABEL_TOP );
        pictbttn_add.setInsets( new java.awt.Insets(1,1,1,1) );
        pictbttn_add.setShowFocus( true );

        pictbttn_add_objectCreated( new powersoft.powerj.event.EventData( pictbttn_add ) );
        DUPositionComponent( pictbttn_delete, 340, 195, 88, 40, formInsets );
        pictbttn_delete.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        pictbttn_delete.setBackground( Color.lightGray );
        pictbttn_delete.setForeground( Color.black );
        pictbttn_delete.enable(false);
        pictbttn_delete.show();

        Rectangle pictbttn_delete_size_rect = DURectangle( 0, 0, 88, 40);
        pictbttn_delete.resize(pictbttn_delete_size_rect.width,pictbttn_delete_size_rect.height);
        pictbttn_delete.setLabel("Delete Option");
        pictbttn_delete.setLabelPosition( powersoft.powerj.ui.PictureButton.LABEL_TOP );
        pictbttn_delete.setInsets( new java.awt.Insets(1,1,1,1) );
        pictbttn_delete.setShowFocus( true );

        pictbttn_delete_objectCreated( new powersoft.powerj.event.EventData( pictbttn_delete ) );
        DUPositionComponent( pictbttn_ok, 340, 15, 88, 40, formInsets );
        pictbttn_ok.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        pictbttn_ok.setBackground( Color.lightGray );
        pictbttn_ok.setForeground( Color.black );
        pictbttn_ok.enable(true);
        pictbttn_ok.show();

        Rectangle pictbttn_ok_size_rect = DURectangle( 0, 0, 88, 40);
        pictbttn_ok.resize(pictbttn_ok_size_rect.width,pictbttn_ok_size_rect.height);
        pictbttn_ok.setLabel("OK");
        pictbttn_ok.setLabelPosition( powersoft.powerj.ui.PictureButton.LABEL_TOP );
        pictbttn_ok.setInsets( new java.awt.Insets(1,1,1,1) );
        pictbttn_ok.setShowFocus( true );

        pictbttn_ok_objectCreated( new powersoft.powerj.event.EventData( pictbttn_ok ) );
        DUPositionComponent( pictbttn_cancel, 340, 65, 88, 40, formInsets );
        pictbttn_cancel.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        pictbttn_cancel.setBackground( Color.lightGray );
        pictbttn_cancel.setForeground( Color.black );
        pictbttn_cancel.enable(true);
        pictbttn_cancel.show();

        Rectangle pictbttn_cancel_size_rect = DURectangle( 0, 0, 88, 40);
        pictbttn_cancel.resize(pictbttn_cancel_size_rect.width,pictbttn_cancel_size_rect.height);
        pictbttn_cancel.setLabel("Cancel");
        pictbttn_cancel.setLabelPosition( powersoft.powerj.ui.PictureButton.LABEL_TOP );
        pictbttn_cancel.setInsets( new java.awt.Insets(1,1,1,1) );
        pictbttn_cancel.setShowFocus( true );

        pictbttn_cancel_objectCreated( new powersoft.powerj.event.EventData( pictbttn_cancel ) );
        layout.setResizePercent(groupb_availoptions,new java.awt.Rectangle(0,0,0,0));
        groupb_availoptions_layout.setResizePercent(grid_availableoptions,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(label_1,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(groupb_current,new java.awt.Rectangle(0,0,0,0));
        groupb_current_layout.setResizePercent(grid_currentoptions,new java.awt.Rectangle(0,0,0,0));
        groupb_current_layout.setResizePercent(label_2,new java.awt.Rectangle(0,0,0,0));
        groupb_current_layout.setResizePercent(textf_total,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(pictbttn_add,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(pictbttn_delete,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(pictbttn_ok,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(pictbttn_cancel,new java.awt.Rectangle(0,0,0,0));

        VehicleOptions_objectCreated( new powersoft.powerj.event.EventData( this ) );
        show();
        return retval;
    }

    public synchronized boolean destroy()
    {
        if( (java.awt.Container)this instanceof java.awt.Window ) {
            ((java.awt.Window)(java.awt.Container)this).dispose();
        } else {
            removeNotify();
        }
        if( isMainForm() ) {
            System.gc();
            System.runFinalization();
            System.exit(0);
        }
        return true;
    }


    public boolean defaultHandleEvent(java.awt.Event event)
    {
        Object eventTarget = event.target;
        if( eventTarget == this && event.id == java.awt.Event.WINDOW_DESTROY ) {
            return VehicleOptions_WindowDestroy(event);
        } else if( eventTarget == grid_availableoptions && event.id == java.awt.Event.LOST_FOCUS ) {
            return grid_availableoptions_LostFocus(event);
        } else if( eventTarget == grid_currentoptions && event.id == java.awt.Event.LOST_FOCUS ) {
            return grid_currentoptions_LostFocus(event);
        } else if( eventTarget == pictbttn_add && event.id == java.awt.Event.ACTION_EVENT ) {
            return pictbttn_add_Action(event);
        } else if( eventTarget == pictbttn_delete && event.id == java.awt.Event.ACTION_EVENT ) {
            return pictbttn_delete_Action(event);
        } else if( eventTarget == pictbttn_ok && event.id == java.awt.Event.ACTION_EVENT ) {
            return pictbttn_ok_Action(event);
        } else if( eventTarget == pictbttn_cancel && event.id == java.awt.Event.ACTION_EVENT ) {
            return pictbttn_cancel_Action(event);
        }
        return super.handleEvent(event);
    }

    public void selectBegin( powersoft.powerj.ui.grid.SelectEvent event )
    {
        Object eventTarget = event.getSource();
        if( eventTarget == grid_availableoptions ) {
            grid_availableoptions_selectBegin( event );
        } else {
            unhandledEvent( "powersoft.powerj.ui.grid.SelectListener", "selectBegin", event );
        }
    }
    public void selectEnd( powersoft.powerj.ui.grid.SelectEvent event )
    {
        Object eventTarget = event.getSource();
        if( eventTarget == grid_availableoptions ) {
            grid_availableoptions_selectEnd( event );
        } else if( eventTarget == grid_currentoptions ) {
            grid_currentoptions_selectEnd( event );
        } else {
            unhandledEvent( "powersoft.powerj.ui.grid.SelectListener", "selectEnd", event );
        }
    }
    public VehicleOptions(java.awt.Frame parent)
    {
        super(parent,true);
    }
    public VehicleOptions(ImpactMotorsMainForm caller, java.awt.Frame parent, Vector options)
    {
        super(parent,true);
        _optionList = options;
        _parent = caller;
    }
    public boolean handleEvent(java.awt.Event event)
    {

        return defaultHandleEvent(event);
    }
    public void unhandledEvent( String listenerName, String methodName, java.lang.Object event )
    {

    }
    public void addOptions()
    {
        String sTemp = new String("");
        int total=0;
        int len=0;
        int i;

        len = grid_currentoptions.getNumRows();

        for(i=0;i<len;i++)
        {
            sTemp = (String)grid_currentoptions.getCell(i,0);
            if (!(sTemp.equals(""))){

                total += unformatCurrency(sTemp.substring(1).trim());

            }
         }
    textf_total.setText(formatCurrency(Integer.toString(total)));


    }
    public String formatCurrency(String org)
    {
            StringBuffer sTemp=null;
        int decimalPos=0;
        int len=0;

        if(org == null)
            return "";

        if(org.equals(""))
            return "";


       sTemp = new StringBuffer(org);
        len = org.length();
        // check for decimal place
        if (!(org.indexOf(".") >0)){
            sTemp.append(".00");
        }
        // check for 2 digits to right of decimal
        if(org.indexOf(".") >0){
            if(len > (org.indexOf(".") - 2)){
                sTemp.setLength(len - (org.indexOf(".") - 3));
            }
        }
        org = sTemp.toString();

        // add ","
            if(org.length() > 6){
                sTemp.insert(org.indexOf(".")-3, ',');
            }

    sTemp.insert(0, '$');
    return sTemp.toString();

    }
    public float unformatCurrency(String s)
    {
        String sTemp="";
        Float f ;

        if (s.indexOf(",") > 0)
            sTemp = s.substring(0, s.indexOf(",")) + s.substring(s.indexOf(",")+1);
        else
            sTemp = s;

        sTemp.trim();

        f = new Float(sTemp);
        return f.floatValue();


    }
    public java.awt.Image getPicImage(String name)
    {
	return _parent.getPicture( name);
    }
    public void returnOptions()
    {
     Vector odv = new Vector();
     OptionsData od = new OptionsData();
     int rowCount=0;

     rowCount = grid_currentoptions.getNumRows();

    if (rowCount >0)
        {
            for (int i=1; i<=rowCount;i++)
            {
            od = (OptionsData)grid_currentoptions.getUserdata(i,2);
            odv.addElement(od);
            }

            _parent.addOptionsToOrder(odv);    
        }

    }
    public boolean VehicleOptions_WindowDestroy(java.awt.Event event)
    {

        _parent.requestFocus();
        hide();
        destroy();
        return false;
    }
    public boolean VehicleOptions_objectCreated(powersoft.powerj.event.EventData event)
    {
        int count, len;
        int i=0;
        OptionsData od = new OptionsData();
        String options[] = new String[2];
        java.awt.Image imgCheck = getPicImage("check16.gif");
        java.awt.Image imgDollar = getPicImage("check16.gif");
        powersoft.powerj.ui.grid.GString[] gstring = new GString[2];

        grid_currentoptions.setNumRows( 0 );
        grid_currentoptions.setNumColumns( 2 );
        grid_availableoptions.setNumColumns( 2 );

        String[] labels = {"Price", "Option Description"};

        gstring[0] = new powersoft.powerj.ui.grid.GString(labels[0], imgDollar, 1);
        gstring[1] = new powersoft.powerj.ui.grid.GString(labels[1], imgCheck, 1);

        grid_availableoptions.setCharWidth( 0, 5 );
        grid_currentoptions.setCharWidth( 0, 5 );

        grid_availableoptions.setCharWidth( 1, 30 );
        grid_currentoptions.setCharWidth( 1, 30 );

        grid_availableoptions.setBorderType( -1,0,GridEnum.BORDER_OUT );
        grid_availableoptions.setBorderType( -1,1,GridEnum.BORDER_OUT );

        grid_currentoptions.setBorderType( -1,0, GridEnum.BORDER_OUT );
        grid_currentoptions.setBorderType( -1,1, GridEnum.BORDER_OUT );

        grid_availableoptions.setColumnLabel( 0, gstring[0] );
        grid_currentoptions.setColumnLabel( 0, gstring[0] );

        grid_availableoptions.setColumnLabel( 1, gstring[1] );
        grid_currentoptions.setColumnLabel( 1, gstring[1] );


        grid_availableoptions.setForeground( -1, 0, java.awt.Color.black );
        grid_availableoptions.setBackground( -1, 0, java.awt.Color.lightGray );
        grid_availableoptions.setForeground( -1, 1, java.awt.Color.black );
        grid_availableoptions.setBackground( -1, 1, java.awt.Color.lightGray );
        grid_availableoptions.setFont( -1, 0, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12 ));
        grid_availableoptions.setFont( -1, 1, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12 ));
        grid_availableoptions.setAlignment( -1, 0, GridEnum.MIDDLECENTER );
        grid_availableoptions.setAlignment( -1, 1, GridEnum.MIDDLECENTER );

        grid_currentoptions.setForeground( -1, 0, java.awt.Color.black );
        grid_currentoptions.setBackground( -1, 0, java.awt.Color.lightGray );
        grid_currentoptions.setForeground( -1, 1, java.awt.Color.black );
        grid_currentoptions.setBackground( -1, 1, java.awt.Color.lightGray );
        grid_currentoptions.setFont( -1, 0, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12 ));
        grid_currentoptions.setFont( -1, 1, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12 ));
        grid_currentoptions.setAlignment( -1, 0, GridEnum.MIDDLECENTER );
        grid_currentoptions.setAlignment( -1, 1, GridEnum.MIDDLECENTER );


        len = _optionList.size();
        grid_availableoptions.setNumRows( len );

        for (Enumeration e = _optionList.elements() ; e.hasMoreElements() ;) {
            od = (OptionsData)e.nextElement();
            grid_availableoptions.setCell(i,0, od.getPrice());
            grid_availableoptions.setCell(i,1, od.getDesc());
            grid_availableoptions.setUserdata(i,2,od);
            i++;
        }


        return false;
    }
    public boolean grid_availableoptions_LostFocus(java.awt.Event event)
    {
        grid_availableoptions.clearSelectedCells();


        return false;
    }
    public void grid_availableoptions_selectBegin( powersoft.powerj.ui.grid.SelectEvent event )
    {
        pictbttn_add.enable(true);


    }
    public void grid_availableoptions_selectEnd( powersoft.powerj.ui.grid.SelectEvent event )
    {
            int temp;

            temp = event.getRow();
            if(temp >= 0)
            {
             _availRowNumber = temp;
             _availColNumber = event.getColumn();
             pictbttn_add.enable(true);
            }
            else
                pictbttn_add.enable(false);
    }
    public boolean grid_currentoptions_LostFocus(java.awt.Event event)
    {
        grid_currentoptions.clearSelectedCells();


        return false;
    }
    public void grid_currentoptions_selectEnd( powersoft.powerj.ui.grid.SelectEvent event )
    {
            int temp;

            temp = event.getRow();
            if(temp >= 0)
            {
             _currentRowNumber = temp;
             _currentColNumber = event.getColumn();
             pictbttn_delete.enable(true);
            }
            else
                pictbttn_delete.enable(false);


    }
    public boolean pictbttn_add_Action(java.awt.Event event)
    {
        Vector v = new Vector();
        String cellValue=null;
        OptionsData od = new OptionsData();

            cellValue = (String)grid_availableoptions.getCell( _availRowNumber, 0 );
            v.addElement(cellValue);

            cellValue = (String)grid_availableoptions.getCell( _availRowNumber, 1 );
            v.addElement(cellValue);

            od = (OptionsData)grid_availableoptions.getUserdata( _availRowNumber, 2 );
            if (grid_currentoptions.addRow( GridEnum.MAXINT, null, v ))
            {
                grid_currentoptions.setUserdata(grid_currentoptions.getNumRows(),2, od);
                grid_availableoptions.deleteRow(_availRowNumber);
            }

            addOptions();
            pictbttn_add.enable(false);


        return false;
    }
    public boolean pictbttn_add_objectCreated(powersoft.powerj.event.EventData event)
    {
    pictbttn_add.setImage("addoptions.jpg");    

        return false;
    }
    public boolean pictbttn_delete_Action(java.awt.Event event)
    {
        Vector v = new Vector();
        String cellValue=null;

            cellValue = (String)grid_currentoptions.getCell( _currentRowNumber, 0 );
            v.addElement(cellValue);

            cellValue = (String)grid_currentoptions.getCell( _currentRowNumber, 1 );
            v.addElement(cellValue);

            if (grid_availableoptions.addRow( GridEnum.MAXINT, null, v ))
            {
                grid_currentoptions.deleteRow(_currentRowNumber);
            }

            addOptions();
            pictbttn_delete.enable(false);


        return false;
    }
    public boolean pictbttn_delete_objectCreated(powersoft.powerj.event.EventData event)
    {
    pictbttn_delete.setImage("cutoption.jpg");    

        return false;
    }
    public boolean pictbttn_ok_Action(java.awt.Event event)
    {
    returnOptions();    
    dispose();    
        return false;
    }
    public boolean pictbttn_ok_objectCreated(powersoft.powerj.event.EventData event)
    {
    pictbttn_ok.setImage("ok.jpg");    

        return false;
    }
    public boolean pictbttn_cancel_Action(java.awt.Event event)
    {
    dispose();    


        return false;
    }
    public boolean pictbttn_cancel_objectCreated(powersoft.powerj.event.EventData event)
    {
    pictbttn_cancel.setImage("cancel.jpg");    

        return false;
    }
    /****************************************
     * data members
     ****************************************/

    boolean __mainForm = false;

    private  powersoft.powerj.ui.GroupBox  groupb_availoptions = new powersoft.powerj.ui.GroupBox();
    private  powersoft.powerj.ui.grid.Grid  grid_availableoptions = new powersoft.powerj.ui.grid.Grid();
    private  java.awt.Label  label_1 = new java.awt.Label();
    private  powersoft.powerj.ui.GroupBox  groupb_current = new powersoft.powerj.ui.GroupBox();
    private  powersoft.powerj.ui.grid.Grid  grid_currentoptions = new powersoft.powerj.ui.grid.Grid();
    private  java.awt.Label  label_2 = new java.awt.Label();
    private  java.awt.TextField  textf_total = new java.awt.TextField();
    private  powersoft.powerj.ui.PictureButton  pictbttn_add = new powersoft.powerj.ui.PictureButton();
    private  powersoft.powerj.ui.PictureButton  pictbttn_delete = new powersoft.powerj.ui.PictureButton();
    private  powersoft.powerj.ui.PictureButton  pictbttn_ok = new powersoft.powerj.ui.PictureButton();
    private  powersoft.powerj.ui.PictureButton  pictbttn_cancel = new powersoft.powerj.ui.PictureButton();

    // add your data members here
    Vector _optionList = new Vector();
    Vector _optionsSelectd = new Vector();

    int _availRowNumber=-1;
    int _availColNumber=-1;
    int _currentRowNumber=-1;
    int _currentColNumber=-1;
    ImpactMotorsMainForm _parent;
}

