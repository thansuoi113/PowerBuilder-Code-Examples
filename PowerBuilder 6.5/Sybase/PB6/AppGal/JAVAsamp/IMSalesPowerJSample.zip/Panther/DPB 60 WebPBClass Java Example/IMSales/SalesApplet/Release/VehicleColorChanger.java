/*
    VehicleColorChanger.java

    NOTE: This file is a generated file.
          Do not modify it by hand!
*/
import java.awt.Color;
import java.awt.Event;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Rectangle;
import java.awt.Insets;
import java.lang.Math;
import java.lang.String;

// custom imports for VehicleColorChanger
// add your custom import statements here


class VehicleColorChanger extends java.awt.Dialog
{
    public Rectangle DURectangle( int x, int y, int w, int h )
    {
        String        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        FontMetrics   fm = getFontMetrics( getFont() );
        double        fw = ( fm != null ) ? ( fm.stringWidth( alphabet ) / alphabet.length() ) : 0;
        double        fh = ( fm != null ) ? ( fm.getHeight() / 2.0 ) : 0.0;

        return new Rectangle( (int) Math.round( ( (double)fw * (double)x ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)y ) / 4.0 ),
                              (int) Math.round( ( (double)fw * (double)w ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)h ) / 4.0 ) );
    }

    public void DUPositionComponent( java.awt.Component comp, int x, int y, int w, int h, java.awt.Insets formInsets )
    {
        Rectangle     rect = DURectangle( x, y, w, h );
        if( formInsets != null ) {
             rect.x += formInsets.left;
             rect.y += formInsets.top;
        }
        comp.reshape( rect.x, rect.y, rect.width, rect.height );
    }

    public void setMainForm( boolean isMainForm )
    {
        __mainForm = isMainForm;
    }
    public boolean isMainForm()
    {
        return __mainForm;
    }
    public boolean create() throws java.lang.Exception
    {
        setTitle("Vehicle Color Changer");

        setResizable(true);

        setFont( new Font( "Dialog", Font.PLAIN, 12 ) );

        boolean retval = true;
        if( getPeer() == null ) {
            addNotify();
        }
        Insets formInsets = insets();
        setBackground( Color.lightGray );
        setForeground( Color.black );

        powersoft.powerj.ui.ResizePercentLayout layout = new powersoft.powerj.ui.ResizePercentLayout();
        setLayout( layout );
        java.awt.FlowLayout groupb_carimage_layout = new java.awt.FlowLayout(java.awt.FlowLayout.LEFT,5,20);
        groupb_carimage.setLayout( groupb_carimage_layout );
        add(groupb_carimage);
        java.awt.FlowLayout groupb_extcolors_layout = new java.awt.FlowLayout(java.awt.FlowLayout.LEFT,5,20);
        groupb_extcolors.setLayout( groupb_extcolors_layout );
        add(groupb_extcolors);
        java.awt.FlowLayout groupb_intcolors_layout = new java.awt.FlowLayout(java.awt.FlowLayout.LEFT,5,20);
        groupb_intcolors.setLayout( groupb_intcolors_layout );
        add(groupb_intcolors);
        java.awt.FlowLayout groupb_currentint_layout = new java.awt.FlowLayout(java.awt.FlowLayout.CENTER,20,20);
        groupb_currentint.setLayout( groupb_currentint_layout );
        add(groupb_currentint);
        java.awt.FlowLayout groupb_currentext_layout = new java.awt.FlowLayout(java.awt.FlowLayout.CENTER,20,20);
        groupb_currentext.setLayout( groupb_currentext_layout );
        add(groupb_currentext);
        java.awt.FlowLayout groupb_currentcolors_layout = new java.awt.FlowLayout(java.awt.FlowLayout.CENTER,20,20);
        groupb_currentcolors.setLayout( groupb_currentcolors_layout );
        add(groupb_currentcolors);
        add(pictbttn_ok);
        add(pictbttn_cancel);
        DUPositionComponent( this, 89, 88, 338, 207, null );

        DUPositionComponent( groupb_carimage, 5, 10, 220, 105, formInsets );
        groupb_carimage.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        groupb_carimage.setBackground( Color.lightGray );
        groupb_carimage.setForeground( Color.black );
        groupb_carimage.enable(true);
        groupb_carimage.show();

        groupb_carimage.setText("Vehicle Image");

        DUPositionComponent( groupb_extcolors, 7, 125, 220, 30, formInsets );
        groupb_extcolors.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        groupb_extcolors.setBackground( Color.lightGray );
        groupb_extcolors.setForeground( Color.black );
        groupb_extcolors.enable(true);
        groupb_extcolors.show();

        groupb_extcolors.setText("Exterior Colors");

        DUPositionComponent( groupb_intcolors, 7, 160, 220, 30, formInsets );
        groupb_intcolors.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        groupb_intcolors.setBackground( Color.lightGray );
        groupb_intcolors.setForeground( Color.black );
        groupb_intcolors.enable(true);
        groupb_intcolors.show();

        groupb_intcolors.setText("Interior Colors");

        DUPositionComponent( groupb_currentint, 238, 161, 75, 25, formInsets );
        groupb_currentint.setBackground( Color.lightGray );
        groupb_currentint.setForeground( Color.black );
        groupb_currentint.enable(true);
        groupb_currentint.show();

        groupb_currentint.setText("Interior Color");

        DUPositionComponent( groupb_currentext, 238, 135, 75, 26, formInsets );
        groupb_currentext.setBackground( Color.lightGray );
        groupb_currentext.setForeground( Color.black );
        groupb_currentext.enable(true);
        groupb_currentext.show();

        groupb_currentext.setText("Exterior Color");

        DUPositionComponent( groupb_currentcolors, 233, 125, 85, 66, formInsets );
        groupb_currentcolors.setBackground( Color.lightGray );
        groupb_currentcolors.setForeground( Color.black );
        groupb_currentcolors.enable(true);
        groupb_currentcolors.show();

        groupb_currentcolors.setText("Current Colors");

        DUPositionComponent( pictbttn_ok, 230, 15, 88, 40, formInsets );
        pictbttn_ok.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        pictbttn_ok.setBackground( Color.lightGray );
        pictbttn_ok.setForeground( Color.black );
        pictbttn_ok.enable(true);
        pictbttn_ok.show();

        Rectangle pictbttn_ok_size_rect = DURectangle( 0, 0, 88, 40);
        pictbttn_ok.resize(pictbttn_ok_size_rect.width,pictbttn_ok_size_rect.height);
        pictbttn_ok.setLabel("OK");
        pictbttn_ok.setLabelPosition( powersoft.powerj.ui.PictureButton.LABEL_TOP );
        pictbttn_ok.setInsets( new java.awt.Insets(1,1,1,1) );
        pictbttn_ok.setShowFocus( true );

        pictbttn_ok_objectCreated( new powersoft.powerj.event.EventData( pictbttn_ok ) );
        DUPositionComponent( pictbttn_cancel, 230, 60, 88, 40, formInsets );
        pictbttn_cancel.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        pictbttn_cancel.setBackground( Color.lightGray );
        pictbttn_cancel.setForeground( Color.black );
        pictbttn_cancel.enable(true);
        pictbttn_cancel.show();

        Rectangle pictbttn_cancel_size_rect = DURectangle( 0, 0, 88, 40);
        pictbttn_cancel.resize(pictbttn_cancel_size_rect.width,pictbttn_cancel_size_rect.height);
        pictbttn_cancel.setLabel("Cancel");
        pictbttn_cancel.setLabelPosition( powersoft.powerj.ui.PictureButton.LABEL_TOP );
        pictbttn_cancel.setInsets( new java.awt.Insets(1,1,1,1) );
        pictbttn_cancel.setShowFocus( true );

        pictbttn_cancel_objectCreated( new powersoft.powerj.event.EventData( pictbttn_cancel ) );
        layout.setResizePercent(groupb_carimage,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(groupb_extcolors,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(groupb_intcolors,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(groupb_currentint,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(groupb_currentext,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(groupb_currentcolors,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(pictbttn_ok,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(pictbttn_cancel,new java.awt.Rectangle(0,0,0,0));

        VehicleColorChanger_objectCreated( new powersoft.powerj.event.EventData( this ) );
        show();
        return retval;
    }

    public synchronized boolean destroy()
    {
        if( (java.awt.Container)this instanceof java.awt.Window ) {
            ((java.awt.Window)(java.awt.Container)this).dispose();
        } else {
            removeNotify();
        }
        if( isMainForm() ) {
            System.gc();
            System.runFinalization();
            System.exit(0);
        }
        return true;
    }


    public boolean defaultHandleEvent(java.awt.Event event)
    {
        Object eventTarget = event.target;
        if( eventTarget == this && event.id == java.awt.Event.WINDOW_DESTROY ) {
            return VehicleColorChanger_WindowDestroy(event);
        } else if( eventTarget == pictbttn_ok && event.id == java.awt.Event.ACTION_EVENT ) {
            return pictbttn_ok_Action(event);
        } else if( eventTarget == pictbttn_cancel && event.id == java.awt.Event.ACTION_EVENT ) {
            return pictbttn_cancel_Action(event);
        }
        return super.handleEvent(event);
    }
    public VehicleColorChanger(java.awt.Frame parent)
    {
        super(parent,true);
    }
    public VehicleColorChanger( ImpactMotorsMainForm parent, ColorData colors, java.awt.Image img)
    {
        super(null,true);
        _parent = parent;
        _colorData = colors;
        _image = img;

    }
    public boolean handleEvent(java.awt.Event event)
    {

        return defaultHandleEvent(event);
    }
    public void unhandledEvent( String listenerName, String methodName, java.lang.Object event )
    {

    }
    public void setSelected(java.awt.Canvas color, ColorPallette obj)
    {
    String tmp;

    if (obj.getType().equals("int") )
        {
        _intSelected = color;
        _interiorCanvas.setBackground(color.getBackground());
        _interiorCanvas.setLabel(_colorData.getColorName(Integer.toString((color.getBackground().getRGB() & 0xffffff),16)));
        _interiorCanvas.repaint();
	    _picCanvas.colorImage(Integer.toString((_extSelected.getBackground().getRGB() & 0xffffff), 16), Integer.toString((color.getBackground().getRGB() & 0xffffff), 16) );

        }

    if (obj.getType().equals("ext"))
        {
        _extSelected = color;
        _exteriorCanvas.setBackground(color.getBackground());
        _exteriorCanvas.setLabel(_colorData.getColorName(Integer.toString((color.getBackground().getRGB() & 0xffffff),16)));
        _exteriorCanvas.repaint();
        //create interior color pallete
        tmp = _colorData.getColorName(Integer.toString((color.getBackground().getRGB() & 0xffffff),16));
        paintIntPal(tmp);
        _picCanvas.colorImage(Integer.toString(((color.getBackground().getRGB()) & 0xffffff), 16), Integer.toString(((_interiorCanvas.getBackground().getRGB()) & 0xffffff), 16));
        validate();

        }

    }
    public void paintIntPal(String color)
    {
    String colors[];
    int numColors;

    // first get RGB values for colors
    colors = _colorData.getInteriorRGBColors(color);
    numColors = _colorData.getArraySize(colors);
    _intCP.reset();
    _intCP.load(colors, numColors);


    }
    public void setUp()
    {

        _exteriorCanvas = new SwatchCanvas("");
        _interiorCanvas = new SwatchCanvas("");

        // set exterior color swatch
        _exteriorCanvas.setBackground(new Color(_colorData.getRGB(_colorData.getExteriorColor())));
        _exteriorCanvas.setLabel(_colorData.getExteriorColor());
        // set interior color swatch
        _interiorCanvas.setBackground(new Color(_colorData.getRGB(_colorData.getInteriorColor())));
        _interiorCanvas.setLabel(_colorData.getInteriorColor());

        groupb_currentext.add( _exteriorCanvas );
        groupb_currentint.add( _interiorCanvas );

        _picCanvas.setImage(_image, 1);
        _picCanvas.reshape(5, 5, _image.getWidth(_picCanvas)+10, _image.getHeight(_picCanvas)+10);

        // set image colors
        _picCanvas.colorImage(Integer.toString(_exteriorCanvas.getBackground().getRGB(), 16),Integer.toString(_interiorCanvas.getBackground().getRGB(), 16) );
        groupb_carimage.add( _picCanvas );


        // create exterior pallette
        _extCP = new ColorPallette(_colorData.getNDExtRGB(), _colorData.getNDNumColors(), this );
        _extCP.setType("ext");
        _extCP.setSelected(_exteriorCanvas);

        //create interior pallette
        int len = _colorData.getArraySize(_colorData.getNDIntRGB(_colorData.getExteriorColor()));
        _intCP = new ColorPallette(_colorData.getNDIntRGB(_colorData.getExteriorColor()), len, this);
        _intCP.setType("int");
        _intCP.setSelected(_interiorCanvas);

        groupb_extcolors.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER,5,20));
        groupb_intcolors.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER,5,20));


        groupb_extcolors.add( _extCP );
        groupb_intcolors.add( _intCP );


    }
    public boolean VehicleColorChanger_WindowDestroy(java.awt.Event event)
    {

        hide();
        destroy();
        return false;
    }
    public boolean VehicleColorChanger_objectCreated(powersoft.powerj.event.EventData event)
    {
String sextC, sintC;
int iextC, iintC;


sextC = _colorData.getExteriorColor();
sintC = _colorData.getInteriorColor();

iextC =_colorData.getRGB(sextC);
iintC = _colorData.getRGB(sintC);


        _exteriorCanvas = new SwatchCanvas(sextC);
        _interiorCanvas = new SwatchCanvas(sintC);
        groupb_currentext.add( _exteriorCanvas );
        groupb_currentint.add( _interiorCanvas );

        // set exterior color swatch
        _exteriorCanvas.setBackground(new Color(iextC));
        _exteriorCanvas.setLabel(sextC);
        // set interior color swatch
        _interiorCanvas.setBackground(new Color(iintC));
        _interiorCanvas.setLabel(sintC);


        _picCanvas = new ImageCanvas(_image);
        _picCanvas.setImage(_image,1);
        _picCanvas.reshape(5, 5, _image.getWidth(_picCanvas)+10, _image.getHeight(_picCanvas)+10);
        _picCanvas.repaint();

        // set image colors
        _picCanvas.colorImage(Integer.toString(_exteriorCanvas.getBackground().getRGB(), 16),Integer.toString(_interiorCanvas.getBackground().getRGB(), 16) );
        groupb_carimage.add( _picCanvas );


        // create exterior pallette
        _extCP = new ColorPallette(_colorData.getNDExtRGB(), _colorData.getNDNumColors(), this );
        _extCP.setType("ext");
        _extCP.setSelected(_exteriorCanvas);

        //create interior pallette
        int len = _colorData.getArraySize(_colorData.getNDIntRGB(_colorData.getExteriorColor()));
        _intCP = new ColorPallette(_colorData.getNDIntRGB(_colorData.getExteriorColor()), len, this);
        _intCP.setType("int");
        _intCP.setSelected(_interiorCanvas);

        groupb_extcolors.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER,5,20));
        groupb_intcolors.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER,5,20));


        groupb_extcolors.add( _extCP );
        groupb_intcolors.add( _intCP );

        return false;
    }
    public boolean pictbttn_ok_Action(java.awt.Event event)
    {

        _parent.checkSelectedColors(_exteriorCanvas.getBackground(), _interiorCanvas.getBackground());
        dispose();    
        return false;
    }
    public boolean pictbttn_ok_objectCreated(powersoft.powerj.event.EventData event)
    {
    pictbttn_ok.setImage("ok.jpg");    

        return false;
    }
    public boolean pictbttn_cancel_Action(java.awt.Event event)
    {
    dispose();    


        return false;
    }
    public boolean pictbttn_cancel_objectCreated(powersoft.powerj.event.EventData event)
    {
    pictbttn_cancel.setImage("cancel.jpg");    

        return false;
    }
    /****************************************
     * data members
     ****************************************/

    boolean __mainForm = false;

    private  powersoft.powerj.ui.GroupBox  groupb_carimage = new powersoft.powerj.ui.GroupBox();
    private  powersoft.powerj.ui.GroupBox  groupb_extcolors = new powersoft.powerj.ui.GroupBox();
    private  powersoft.powerj.ui.GroupBox  groupb_intcolors = new powersoft.powerj.ui.GroupBox();
    private  powersoft.powerj.ui.GroupBox  groupb_currentint = new powersoft.powerj.ui.GroupBox();
    private  powersoft.powerj.ui.GroupBox  groupb_currentext = new powersoft.powerj.ui.GroupBox();
    private  powersoft.powerj.ui.GroupBox  groupb_currentcolors = new powersoft.powerj.ui.GroupBox();
    private  powersoft.powerj.ui.PictureButton  pictbttn_ok = new powersoft.powerj.ui.PictureButton();
    private  powersoft.powerj.ui.PictureButton  pictbttn_cancel = new powersoft.powerj.ui.PictureButton();

    // add your data members here
    ImageCanvas _picCanvas;
	ColorData _colorData;
    java.awt.Image _image;
    java.awt.Canvas _ExtColors[] = new java.awt.Canvas[16];        // color swatches
    java.awt.Canvas _IntColors[] = new java.awt.Canvas[16];        //     ''
    java.awt.Canvas _extSelected = new java.awt.Canvas();         // the exterior selected color
    java.awt.Canvas _intSelected = new java.awt.Canvas();         // the exterior selected color
    ColorPallette _intCP;
    ColorPallette _extCP;
    SwatchCanvas _interiorCanvas=null;
    SwatchCanvas _exteriorCanvas=null;
    ImpactMotorsMainForm _parent;
}

