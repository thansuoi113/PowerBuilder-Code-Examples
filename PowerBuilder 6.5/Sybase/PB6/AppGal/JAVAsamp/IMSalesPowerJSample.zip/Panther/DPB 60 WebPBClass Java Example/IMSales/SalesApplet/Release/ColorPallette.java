/*
    ColorPallette.java

    NOTE: This file is a generated file.
          Do not modify it by hand!
*/
// add your custom import statements here
import java.awt.*;

class ColorPallette extends Panel
{
    int getArraySize(Object[] array)
    {
        int count;
        int len = array.length;
        for(count=0; count<len;count++)
        {
            if(array[count] == null)
            return count;
        }
    return count;
    }
    public ColorPallette(String[] colors, int numColors, VehicleColorChanger  obj)
    {
       _parent = obj;
        // set colors
        sColors = colors;

        // get the colors for this model
        numColors = numColors;


        int rgbVal=0;
        int count=0;
        int j=16;
        int i=5;
        for (count = 0; count < numColors; count ++)
            {
                try {
                    rgbVal = Integer.parseInt(sColors[count], 16);
                    }
 	            catch (NumberFormatException e)
 	            {
 	            }

	            Colors[count] = new Canvas();
	            Colors[count].reshape(i,j,25,25);
	            Colors[count].setBackground(new Color(rgbVal));
	            this.add(Colors[count]);

                i += 30;
                if (i >= (this.size().width))
                    {
                        i = 5;
                        j += 30;
                    }
	        }

        }
void paintSwatches()
{
        int rgbVal=0;
        int count;
        int j=16;
        int i=5;
        this.show(false);

        for (count = 0; count < numColors; count ++)
            {
                try {
                    rgbVal = Integer.parseInt(sColors[count], 16);
                    }
 	            catch (NumberFormatException e){}

	            Colors[count] = new Canvas();
	            Colors[count].reshape(i,j,25,25);
	            Colors[count].setBackground(new Color(rgbVal));
	            this.add(Colors[count]);

                i += 30;
                if (i >= (this.size().width))
                    {
                        i = 5;
                        j += 30;
                    }
	        }
            //force layout
            validate();
            show(true);
}
public Canvas getSelected(){
    return selected;
}
public void setType(String t)
{
    type = t;
}
public void reset()
{
    int count;
    int len;
    len = getArraySize(Colors);

    // remove all valid canvas
    for(count=0;count<len;count++)
        {
            Colors[count].isValid();
            remove(Colors[count]);
        }
}
public void load(String[] colors, int num)
{
      // set colors
        sColors = colors;
        // get the colors for this model
        numColors = num;

        paintSwatches();
}
public String getType()
{
    return type;
}
public void paint(Graphics g)
{

    if (selected.isValid())
    {
    g.draw3DRect(selected.bounds().x -1,
                 selected.bounds().y -1,
                 selected.bounds().width +2,
                 selected.bounds().height +2, false);
    }
}
public void setSelected(Canvas select)
{
    int count;
    int len;

    len = getArraySize(Colors);

    for ( count=0; count<len;count++)
    {
        if (Colors[count].getBackground().equals(select.getBackground()))
            selected = Colors[count];
    }

    repaint();
}
public boolean mouseDown(Event e, int x, int y)
     {
        if (e.target instanceof Canvas)
        {
            Graphics g = this.getGraphics();

            for (int i=0; i < 16;i++)
            {   // is it a color swatch?
                if (e.target.equals(Colors[i]))
                {
                   if (e.target.equals(selected)){
                            break;}
                     else{
                      // erase old selector
                      g.setColor(this.getBackground());
                      g.drawRect(selected.bounds().x -1,
                              selected.bounds().y -1,
                              selected.bounds().width +2,
                              selected.bounds().height +2);

                       selected = Colors[i];
                        g.setColor(this.getBackground());
                        g.draw3DRect(selected.bounds().x -1,
                               selected.bounds().y -1,
                               selected.bounds().width +2,
                               selected.bounds().height +2, true);

                    _parent.setSelected(selected, this);

                           }
                    }
                }

              }

        return false;
  }
    // add your data members here
    Canvas Colors[] = new Canvas[16];    // color swatches
    Canvas selected = new Canvas();         // the selected color
    String sColors[] = new String[32];
    int numColors;
    VehicleColorChanger _parent;
    String type;                        // used to determine if used for interior/exterior
}

