/*
    SwatchCanvas.java

    NOTE: This file is a generated file.
          Do not modify it by hand!
*/
// add your custom import statements here
import java.awt.*;

public class SwatchCanvas extends Canvas
{
    public SwatchCanvas(String text) {
        label = text;

    }
    public void setLabel(String text){
        FontMetrics fm = getFontMetrics(getFont());

        this.label = checkCap(text);
        if (getBackground().equals( Color.white))
            setForeground(Color.black);
          else
            setForeground(Color.white);

        resize(20 + fm.stringWidth(label), fm.getHeight()+ 5);

        repaint();
    }
    public void paint(Graphics g) {
           g.drawString(label, labelLoc.x, labelLoc.y);

    }
    public void setInsets(Insets insets) {
        this.insets = insets;
        repaint();
    }
    public String  getLabel  () { return label;                }
    public void resize(int w, int h) {
        reshape(location().x, location().y, w, h);
    }
    public void reshape(int x, int y, int w, int h) {
        super.reshape(x, y, w, h);
        labelLoc = labelLocation(getGraphics());
    }
    public Dimension minimumSize() {
        return preferredSize();
    }
   public Dimension preferredSize() {
        FontMetrics fm = getFontMetrics(getFont());
            return new Dimension( 20 + fm.stringWidth(label),
                     insets.top  + fm.getHeight() +
                     insets.bottom);

    }
    protected String paramString() {
        return super.paramString() + ",text=" + label;
    }
    private Point labelLocation(Graphics g) {
        Dimension   size = size();
        FontMetrics fm   = g.getFontMetrics();

        int x = ((size.width/3) - (fm.stringWidth(label)/2))+10;
        int y = (size.height/2) + (fm.getAscent()/2) - fm.getLeading();
        return new Point(x,y);
    }
    String checkCap(String label){
        String newLabel="";
        char ch='\t';

        if (label.length() == 0)
            return "";

        Character c = new Character(label.charAt(0));
        int spacePos=0;

        // cap first letter
        ch = c.toUpperCase(c.charValue());

        newLabel = ch+label.substring(1);

        // check for spaces
        spacePos = newLabel.indexOf(0x20);
       if (spacePos >0)
       {
        c = new Character(newLabel.charAt(spacePos+1));
        ch = c.toUpperCase(c.charValue());
        newLabel = newLabel.substring(0, spacePos+1)+ch+newLabel.substring(spacePos+2);
       }


        return newLabel;
    }
    public void eraseAll()
    {
        setBackground(getParent().getBackground());
        setLabel("");
        repaint();

    }
    // add your data members here
    private String  label;
    private Insets  insets   = new Insets(1,1,1,1);
    private Point   labelLoc = new Point(0,0);
}

