/*
    ColorFilter.java

    NOTE: This file is a generated file.
          Do not modify it by hand!
*/
// add your custom import statements here
import java.awt.image.*;
import java.awt.*;
import java.lang.*;

class ColorFilter extends RGBImageFilter
{
    public ColorFilter(String exterior, String interior) {
        extColor = exterior;
        intColor = interior;
        canFilterIndexColorModel = true;

    }
  public int filterRGB(int x, int y, int rgb) {
      String ehColor="";
      String ihColor="";
      DirectColorModel cm = (DirectColorModel) ColorModel.getRGBdefault();

      ehColor = extColor;
      ihColor = intColor;

     int    extRGB=0;
     int    intRGB=0;
     int    alpha = cm.getAlpha(rgb);
     int    cmRGB = (rgb & 0xffffff);
     int    srcRGBext =   (255 <<16);
     int    srcRGBint =   (255);

    if ((! ehColor.equals("")) & (! ihColor.equals("")))
    {
                try {
                    extRGB =  Integer.parseInt(ehColor, 16);
                    }
 	            catch (NumberFormatException e)
 	            {
 	            }
 	            try {
                    intRGB = Integer.parseInt(ihColor, 16);
                    }
 	            catch (NumberFormatException e)
 	            {
 	            }

    }

     alpha = alpha << 24;

    switch (cmRGB)
    {
        case (255 <<16):
            return alpha | extRGB;
        case 255:
            return alpha | intRGB;
        default:
            return rgb;
        }
    }
    // add your data members here
    String extColor;
    String intColor;
}

