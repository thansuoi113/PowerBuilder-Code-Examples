/*
    ImageCanvas.java

    NOTE: This file is a generated file.
          Do not modify it by hand!
*/
// add your custom import statements here
import java.awt.*;
import java.awt.image.*;
import ColorFilter;

class ImageCanvas extends Canvas
{
public ImageCanvas(Image image) {
        this.image = image;
        waitForImage(this, image);
        resize(image.getWidth(this)+10, image.getHeight(this)+10);
    }
public void paint(Graphics g) {

        switch(viewMode)
        {
            case 0:
                g.drawImage(image, 5, 5, this);
                break;
            case 1:
                g.drawImage(coloredImage, 5, 5, this);
                break;
            case 2:
                g.drawImage(newImage, 5, 5, this);
                break;
            case 3:
                break;


        }
 }
public Image getImage()
{
    return coloredImage;
}
void waitForImage(Component component,
                                    Image image) {
        MediaTracker tracker = new MediaTracker(component);
        try {
            tracker.addImage(image, 0);
            tracker.waitForID(0);
        }
        catch(InterruptedException e) {}
    }
 public void update(Graphics g) {
        paint(g);
    }
 public void colorImage( String extColor, String intColor)
        {
		ImageFilter f = new ColorFilter(extColor, intColor);
        ImageProducer producer = new FilteredImageSource(coloredImage.getSource(), f);
        newImage = this.createImage(producer);
        viewMode =2;
        repaint();
        }
 // function called to set the image to display
 public void setNewImage(Image i){

    newImage = i;
    viewMode =2;
    repaint();
 }
// function used to set the vewMode (image to view)
public void setViewMode(int m)
{
    viewMode = m;
    repaint();
}
 public void drawBorder()
 {
    Rectangle rec;
    Graphics g = getGraphics();
    rec = bounds();
    g.draw3DRect(rec.x, rec.y,image.getWidth(this)+5, image.getHeight(this)+5,false);

 }
    public ImageCanvas()
    {

    }
    public void setImage(Image img, int mode)
    {
    if (mode == 0)
    {
        image = img;
        waitForImage(this, image);
        resize(image.getWidth(this)+10, image.getHeight(this)+10);
    }
    else if (mode == 1)
    {
        coloredImage = img;
        waitForImage(this, coloredImage);
        resize(coloredImage.getWidth(this)+10, coloredImage.getHeight(this)+10);
    }
    else if (mode == 2)
    {
        newImage = img;
        waitForImage(this, newImage);
        resize(newImage.getWidth(this)+10, newImage.getHeight(this)+10);
    }

    setViewMode(mode);

    }
    public void eraseAll()
    {
        setBackground(getParent().getBackground());
        viewMode=3;
        repaint();

    }
    // add your data members here
    private Image image;
    private Image coloredImage;
    private Image newImage;
    int viewMode=0;                   // 0=view image; 1= view coloredImage; 2=view newImage
}

