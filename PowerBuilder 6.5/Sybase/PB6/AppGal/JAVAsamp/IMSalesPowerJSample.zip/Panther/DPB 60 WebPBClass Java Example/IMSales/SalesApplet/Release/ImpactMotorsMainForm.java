/*
    ImpactMotorsMainForm.java

    NOTE: This file is a generated file.
          Do not modify it by hand!
*/
import java.awt.Color;
import java.awt.Event;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Rectangle;
import java.awt.Insets;
import java.lang.Math;
import java.lang.String;

// custom imports for ImpactMotorsMainForm
// add your custom import statements here
import java.awt.*;
import jdbc.sql.ResultSet;
import jdbc.sql.SQLException;
import jdbc.sql.ResultSetMetaData;
import java.net.MalformedURLException;
import powersoft.powerj.webpb.jdbc_sql.WebPBCall;
import powersoft.powerj.webpb.jdbc_sql.WebPBResultSet;

// custom imports for ImpactMotorsMainForm_page_customer
// add your custom import statements here
import jdbc.sql.ResultSet;
import jdbc.sql.ResultSetMetaData;
import jdbc.sql.SQLException;

// custom imports for ImpactMotorsMainForm_page_vehicleinfo
// add your custom import statements here

// custom imports for ImpactMotorsMainForm_page_options
// add your custom import statements here
import java.util.Vector;
import jclass.util.JCString;
import jclass.bwt.BWTEnum;
import java.util.Enumeration;
import powersoft.powerj.ui.grid.GridEnum;
import java.net.MalformedURLException;
import powersoft.powerj.ui.grid.GString;

// custom imports for ImpactMotorsMainForm_page_bound
import jdbc.sql.SQLException;
import powersoft.powerj.webpb.jdbc_sql.WebPBResultSet;
import powersoft.powerj.webpb.jdbc_sql.WebPBResultSetMetaData;// add your custom import statements here

// custom imports for ImpactMotorsMainForm_page_sqlrunner
// add your custom import statements here
import jdbc.sql.ResultSetMetaData;
import jdbc.sql.SQLException;
import powersoft.powerj.webpb.jdbc_sql.WebPBResultSet;
import powersoft.powerj.webpb.jdbc_sql.WebPBResultSetMetaData;



class ImpactMotorsMainForm_page_customer extends java.awt.Panel
{
    public Rectangle DURectangle( int x, int y, int w, int h )
    {
        String        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        FontMetrics   fm = getFontMetrics( getFont() );
        double        fw = ( fm != null ) ? ( fm.stringWidth( alphabet ) / alphabet.length() ) : 0;
        double        fh = ( fm != null ) ? ( fm.getHeight() / 2.0 ) : 0.0;

        return new Rectangle( (int) Math.round( ( (double)fw * (double)x ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)y ) / 4.0 ),
                              (int) Math.round( ( (double)fw * (double)w ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)h ) / 4.0 ) );
    }

    public void DUPositionComponent( java.awt.Component comp, int x, int y, int w, int h, java.awt.Insets formInsets )
    {
        Rectangle     rect = DURectangle( x, y, w, h );
        if( formInsets != null ) {
             rect.x += formInsets.left;
             rect.y += formInsets.top;
        }
        comp.reshape( rect.x, rect.y, rect.width, rect.height );
    }

    public void setMainForm( boolean isMainForm )
    {
        __mainForm = isMainForm;
    }
    public boolean isMainForm()
    {
        return __mainForm;
    }
    public boolean create() throws java.lang.Exception
    {
        setFont( new Font( "Dialog", Font.PLAIN, 10 ) );

        boolean retval = true;
        __parentForm = (ImpactMotorsMainForm)(getParent().getParent().getParent());
        if( getPeer() == null ) {
            addNotify();
        }
        show();
        Insets formInsets = insets();
        hide();
        setBackground( Color.lightGray );
        setForeground( Color.black );

        powersoft.powerj.ui.ResizePercentLayout layout = new powersoft.powerj.ui.ResizePercentLayout();
        setLayout( layout );
        powersoft.powerj.ui.ResizePercentLayout groupb_customerinfo_layout = new powersoft.powerj.ui.ResizePercentLayout();
        groupb_customerinfo.setLayout( groupb_customerinfo_layout );
        add(groupb_customerinfo);
        groupb_customerinfo.add(textf_homephone);
        groupb_customerinfo.add(textf_last);
        groupb_customerinfo.add(label_1);
        groupb_customerinfo.add(label_2);
        groupb_customerinfo.add(label_3);
        groupb_customerinfo.add(label_4);
        groupb_customerinfo.add(label_5);
        groupb_customerinfo.add(label_6);
        groupb_customerinfo.add(textf_first);
        groupb_customerinfo.add(textf_city);
        groupb_customerinfo.add(textf_st);
        groupb_customerinfo.add(textf_zip);
        groupb_customerinfo.add(textf_wrkph);
        groupb_customerinfo.add(label_7);
        groupb_customerinfo.add(label_8);
        groupb_customerinfo.add(textf_userid);
        groupb_customerinfo.add(label_9);
        groupb_customerinfo.add(textf_street);
        groupb_customerinfo.add(pictbttn_vieworder);
        powersoft.powerj.ui.ResizePercentLayout groupb_search_layout = new powersoft.powerj.ui.ResizePercentLayout();
        groupb_search.setLayout( groupb_search_layout );
        add(groupb_search);
        groupb_search.add(label_10);
        groupb_search.add(textf_2);
        groupb_search.add(label_18);
        groupb_search.add(lb_custlist);
        groupb_search.add(pictbttn_search);
        powersoft.powerj.ui.ResizePercentLayout groupb_orderinfo_layout = new powersoft.powerj.ui.ResizePercentLayout();
        groupb_orderinfo.setLayout( groupb_orderinfo_layout );
        add(groupb_orderinfo);
        groupb_orderinfo.add(textf_salesrep);
        groupb_orderinfo.add(textf_orderdate);
        groupb_orderinfo.add(textf_status);
        groupb_orderinfo.add(textf_lastupdate);
        groupb_orderinfo.add(label_11);
        groupb_orderinfo.add(label_15);
        groupb_orderinfo.add(label_16);
        groupb_orderinfo.add(label_17);
        groupb_orderinfo.add(label_13);
        groupb_orderinfo.add(lb_orderid);
        DUPositionComponent( this, 0, 0, 429, 210, null );

        DUPositionComponent( groupb_customerinfo, 4, 64, 273, 128, formInsets );
        groupb_customerinfo.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        groupb_customerinfo.setBackground( Color.lightGray );
        groupb_customerinfo.setForeground( Color.black );
        groupb_customerinfo.enable(true);
        groupb_customerinfo.hide();

        groupb_customerinfo.setText("Customer");

        textf_homephone.setEditable(false);
        DUPositionComponent( textf_homephone, 200, 103, 70, 12, null );
        textf_homephone.setBackground( Color.lightGray );
        textf_homephone.setForeground( Color.black );
        textf_homephone.enable(true);
        textf_homephone.show();


        textf_last.setEditable(false);
        DUPositionComponent( textf_last, 60, 26, 100, 12, null );
        textf_last.setFont( new Font( "Dialog", Font.PLAIN, 10 ) );
        textf_last.setBackground( Color.lightGray );
        textf_last.setForeground( Color.black );
        textf_last.enable(true);
        textf_last.show();


        DUPositionComponent( label_1, 6, 27, 50, 12, null );
        label_1.setAlignment(java.awt.Label.RIGHT);
        label_1.setText( "Last Name:" );
        label_1.setFont( new Font( "Dialog", Font.PLAIN, 12 ) );
        label_1.setBackground( Color.lightGray );
        label_1.setForeground( Color.black );
        label_1.enable(true);
        label_1.show();


        DUPositionComponent( label_2, 6, 40, 50, 13, null );
        label_2.setAlignment(java.awt.Label.RIGHT);
        label_2.setText( "Street:" );
        label_2.setFont( new Font( "Dialog", Font.PLAIN, 12 ) );
        label_2.setBackground( Color.lightGray );
        label_2.setForeground( Color.black );
        label_2.enable(true);
        label_2.show();


        DUPositionComponent( label_3, 10, 57, 46, 12, null );
        label_3.setAlignment(java.awt.Label.RIGHT);
        label_3.setText( "City:" );
        label_3.setFont( new Font( "Dialog", Font.PLAIN, 12 ) );
        label_3.setBackground( Color.lightGray );
        label_3.setForeground( Color.black );
        label_3.enable(true);
        label_3.show();


        DUPositionComponent( label_4, 150, 26, 26, 12, null );
        label_4.setAlignment(java.awt.Label.RIGHT);
        label_4.setText( "First:" );
        label_4.setFont( new Font( "Dialog", Font.PLAIN, 12 ) );
        label_4.setBackground( Color.lightGray );
        label_4.setForeground( Color.black );
        label_4.enable(true);
        label_4.show();


        DUPositionComponent( label_5, 134, 56, 34, 13, null );
        label_5.setAlignment(java.awt.Label.RIGHT);
        label_5.setText( "State:" );
        label_5.setFont( new Font( "Dialog", Font.PLAIN, 12 ) );
        label_5.setBackground( Color.lightGray );
        label_5.setForeground( Color.black );
        label_5.enable(true);
        label_5.show();


        DUPositionComponent( label_6, 194, 56, 38, 13, null );
        label_6.setAlignment(java.awt.Label.RIGHT);
        label_6.setText( "Zipcode:" );
        label_6.setFont( new Font( "Dialog", Font.PLAIN, 12 ) );
        label_6.setBackground( Color.lightGray );
        label_6.setForeground( Color.black );
        label_6.enable(false);
        label_6.show();


        textf_first.setEditable(false);
        DUPositionComponent( textf_first, 180, 26, 88, 12, null );
        textf_first.setFont( new Font( "Dialog", Font.PLAIN, 10 ) );
        textf_first.setBackground( Color.lightGray );
        textf_first.setForeground( Color.black );
        textf_first.enable(true);
        textf_first.show();


        textf_city.setEditable(false);
        DUPositionComponent( textf_city, 60, 56, 76, 13, null );
        textf_city.setFont( new Font( "Dialog", Font.PLAIN, 10 ) );
        textf_city.setBackground( Color.lightGray );
        textf_city.setForeground( Color.black );
        textf_city.enable(true);
        textf_city.show();


        textf_st.setEditable(false);
        DUPositionComponent( textf_st, 172, 57, 25, 12, null );
        textf_st.setFont( new Font( "Dialog", Font.PLAIN, 10 ) );
        textf_st.setBackground( Color.lightGray );
        textf_st.setForeground( Color.black );
        textf_st.enable(true);
        textf_st.show();


        textf_zip.setEditable(false);
        DUPositionComponent( textf_zip, 232, 57, 36, 12, null );
        textf_zip.setFont( new Font( "Dialog", Font.PLAIN, 10 ) );
        textf_zip.setBackground( Color.lightGray );
        textf_zip.setForeground( Color.black );
        textf_zip.enable(true);
        textf_zip.show();


        textf_wrkph.setEditable(false);
        DUPositionComponent( textf_wrkph, 60, 103, 77, 12, null );
        textf_wrkph.setFont( new Font( "Dialog", Font.PLAIN, 10 ) );
        textf_wrkph.setBackground( Color.lightGray );
        textf_wrkph.setForeground( Color.black );
        textf_wrkph.enable(true);
        textf_wrkph.show();


        DUPositionComponent( label_7, 142, 100, 54, 15, null );
        label_7.setAlignment(java.awt.Label.RIGHT);
        label_7.setText( "Home Phone:" );
        label_7.setFont( new Font( "Dialog", Font.PLAIN, 12 ) );
        label_7.setBackground( Color.lightGray );
        label_7.setForeground( Color.black );
        label_7.enable(true);
        label_7.show();


        DUPositionComponent( label_8, 2, 100, 54, 15, null );
        label_8.setAlignment(java.awt.Label.RIGHT);
        label_8.setText( "Work Phone:" );
        label_8.setFont( new Font( "Dialog", Font.PLAIN, 12 ) );
        label_8.setBackground( Color.lightGray );
        label_8.setForeground( Color.black );
        label_8.enable(true);
        label_8.show();


        textf_userid.setEditable(false);
        DUPositionComponent( textf_userid, 60, 82, 76, 12, null );
        textf_userid.setFont( new Font( "Dialog", Font.PLAIN, 10 ) );
        textf_userid.setBackground( Color.lightGray );
        textf_userid.setForeground( Color.black );
        textf_userid.enable(true);
        textf_userid.show();


        DUPositionComponent( label_9, 6, 80, 50, 14, null );
        label_9.setAlignment(java.awt.Label.RIGHT);
        label_9.setText( "UserID:" );
        label_9.setFont( new Font( "Dialog", Font.PLAIN, 12 ) );
        label_9.setBackground( Color.lightGray );
        label_9.setForeground( Color.black );
        label_9.enable(true);
        label_9.show();


        textf_street.setEditable(false);
        DUPositionComponent( textf_street, 60, 42, 208, 12, null );
        textf_street.setBackground( Color.lightGray );
        textf_street.setForeground( Color.black );
        textf_street.enable(true);
        textf_street.show();


        DUPositionComponent( pictbttn_vieworder, 180, 8, 84, 14, null );
        pictbttn_vieworder.setFont( new Font( "Dialog", Font.PLAIN, 10 ) );
        pictbttn_vieworder.setBackground( Color.lightGray );
        pictbttn_vieworder.setForeground( Color.black );
        pictbttn_vieworder.enable(false);
        pictbttn_vieworder.show();

        Rectangle pictbttn_vieworder_size_rect = DURectangle( 0, 0, 84, 14);
        pictbttn_vieworder.resize(pictbttn_vieworder_size_rect.width,pictbttn_vieworder_size_rect.height);
        pictbttn_vieworder.setLabel("Retrieve Order Info.");
        pictbttn_vieworder.setLabelPosition( powersoft.powerj.ui.PictureButton.LABEL_BOTTOM );
        pictbttn_vieworder.setInsets( new java.awt.Insets(5,5,5,5) );
        pictbttn_vieworder.setShowFocus( true );

        DUPositionComponent( groupb_search, 4, 4, 408, 52, formInsets );
        groupb_search.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        groupb_search.setBackground( Color.lightGray );
        groupb_search.setForeground( Color.black );
        groupb_search.enable(true);
        groupb_search.show();

        groupb_search.setText("Search for Customer");

        DUPositionComponent( label_10, 265, 12, 90, 8, null );
        label_10.setAlignment(java.awt.Label.LEFT);
        label_10.setText( "Customer List:" );
        label_10.setFont( new Font( "Dialog", Font.PLAIN, 10 ) );
        label_10.setBackground( Color.lightGray );
        label_10.setForeground( Color.black );
        label_10.enable(true);
        label_10.show();


        DUPositionComponent( textf_2, 100, 20, 128, 12, null );
        textf_2.setBackground( Color.lightGray );
        textf_2.setForeground( Color.black );
        textf_2.enable(true);
        textf_2.show();


        DUPositionComponent( label_18, 94, 12, 130, 8, null );
        label_18.setAlignment(java.awt.Label.LEFT);
        label_18.setText( "Customer partial last name to seach for:" );
        label_18.setBackground( Color.lightGray );
        label_18.setForeground( Color.darkGray );
        label_18.enable(true);
        label_18.show();


        DUPositionComponent( lb_custlist, 264, 20, 128, 24, null );
        lb_custlist.setBackground( Color.lightGray );
        lb_custlist.setForeground( Color.black );
        lb_custlist.enable(true);
        lb_custlist.show();


        DUPositionComponent( pictbttn_search, 8, 16, 88, 28, null );
        pictbttn_search.setBackground( Color.lightGray );
        pictbttn_search.setForeground( Color.black );
        pictbttn_search.enable(true);
        pictbttn_search.show();

        Rectangle pictbttn_search_size_rect = DURectangle( 0, 0, 88, 28);
        pictbttn_search.resize(pictbttn_search_size_rect.width,pictbttn_search_size_rect.height);
        pictbttn_search.setLabel("Search");
        pictbttn_search.setLabelPosition( powersoft.powerj.ui.PictureButton.LABEL_BOTTOM );
        pictbttn_search.setInsets( new java.awt.Insets(5,5,5,5) );
        pictbttn_search.setShowFocus( true );

        pictbttn_search_objectCreated( new powersoft.powerj.event.EventData( pictbttn_search ) );
        DUPositionComponent( groupb_orderinfo, 280, 64, 132, 129, formInsets );
        groupb_orderinfo.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        groupb_orderinfo.setBackground( Color.lightGray );
        groupb_orderinfo.setForeground( Color.black );
        groupb_orderinfo.enable(true);
        groupb_orderinfo.hide();

        groupb_orderinfo.setText("Order Information");

        textf_salesrep.setEditable(false);
        DUPositionComponent( textf_salesrep, 64, 40, 64, 12, null );
        textf_salesrep.setFont( new Font( "Dialog", Font.PLAIN, 10 ) );
        textf_salesrep.setBackground( Color.lightGray );
        textf_salesrep.setForeground( Color.black );
        textf_salesrep.enable(true);
        textf_salesrep.show();


        textf_orderdate.setEditable(false);
        DUPositionComponent( textf_orderdate, 64, 60, 64, 12, null );
        textf_orderdate.setFont( new Font( "Dialog", Font.PLAIN, 10 ) );
        textf_orderdate.setBackground( Color.lightGray );
        textf_orderdate.setForeground( Color.black );
        textf_orderdate.enable(true);
        textf_orderdate.show();


        textf_status.setEditable(false);
        DUPositionComponent( textf_status, 64, 80, 64, 12, null );
        textf_status.setFont( new Font( "Dialog", Font.PLAIN, 10 ) );
        textf_status.setBackground( Color.lightGray );
        textf_status.setForeground( Color.black );
        textf_status.enable(true);
        textf_status.show();


        textf_lastupdate.setEditable(false);
        DUPositionComponent( textf_lastupdate, 64, 100, 64, 12, null );
        textf_lastupdate.setFont( new Font( "Dialog", Font.PLAIN, 10 ) );
        textf_lastupdate.setBackground( Color.lightGray );
        textf_lastupdate.setForeground( Color.black );
        textf_lastupdate.enable(true);
        textf_lastupdate.show();


        DUPositionComponent( label_11, 10, 40, 50, 12, null );
        label_11.setAlignment(java.awt.Label.RIGHT);
        label_11.setText( "Sales Rep:" );
        label_11.setFont( new Font( "Dialog", Font.PLAIN, 12 ) );
        label_11.setBackground( Color.lightGray );
        label_11.setForeground( Color.black );
        label_11.enable(true);
        label_11.show();


        DUPositionComponent( label_15, 10, 60, 50, 12, null );
        label_15.setAlignment(java.awt.Label.RIGHT);
        label_15.setText( "Order Date:" );
        label_15.setFont( new Font( "Dialog", Font.PLAIN, 12 ) );
        label_15.setBackground( Color.lightGray );
        label_15.setForeground( Color.black );
        label_15.enable(true);
        label_15.show();


        DUPositionComponent( label_16, 12, 80, 48, 12, null );
        label_16.setAlignment(java.awt.Label.RIGHT);
        label_16.setText( "Status:" );
        label_16.setFont( new Font( "Dialog", Font.PLAIN, 12 ) );
        label_16.setBackground( Color.lightGray );
        label_16.setForeground( Color.black );
        label_16.enable(true);
        label_16.show();


        DUPositionComponent( label_17, 12, 101, 48, 12, null );
        label_17.setAlignment(java.awt.Label.RIGHT);
        label_17.setText( "Last Chg:" );
        label_17.setFont( new Font( "Dialog", Font.PLAIN, 12 ) );
        label_17.setBackground( Color.lightGray );
        label_17.setForeground( Color.black );
        label_17.enable(true);
        label_17.show();


        DUPositionComponent( label_13, -2, 20, 62, 10, null );
        label_13.setAlignment(java.awt.Label.RIGHT);
        label_13.setText( "Order  Number:" );
        label_13.setFont( new Font( "Dialog", Font.PLAIN, 12 ) );
        label_13.setBackground( Color.lightGray );
        label_13.setForeground( Color.black );
        label_13.enable(true);
        label_13.show();


        DUPositionComponent( lb_orderid, 64, 20, 64, 12, null );
        lb_orderid.setBackground( Color.lightGray );
        lb_orderid.setForeground( Color.black );
        lb_orderid.enable(true);
        lb_orderid.show();


        layout.setResizePercent(groupb_customerinfo,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(textf_homephone,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(textf_last,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(label_1,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(label_2,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(label_3,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(label_4,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(label_5,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(label_6,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(textf_first,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(textf_city,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(textf_st,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(textf_zip,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(textf_wrkph,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(label_7,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(label_8,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(textf_userid,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(label_9,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(textf_street,new java.awt.Rectangle(0,0,0,0));
        groupb_customerinfo_layout.setResizePercent(pictbttn_vieworder,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(groupb_search,new java.awt.Rectangle(0,0,0,0));
        groupb_search_layout.setResizePercent(label_10,new java.awt.Rectangle(0,0,0,0));
        groupb_search_layout.setResizePercent(textf_2,new java.awt.Rectangle(0,0,0,0));
        groupb_search_layout.setResizePercent(label_18,new java.awt.Rectangle(0,0,0,0));
        groupb_search_layout.setResizePercent(lb_custlist,new java.awt.Rectangle(0,0,0,0));
        groupb_search_layout.setResizePercent(pictbttn_search,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(groupb_orderinfo,new java.awt.Rectangle(0,0,0,0));
        groupb_orderinfo_layout.setResizePercent(textf_salesrep,new java.awt.Rectangle(0,0,0,0));
        groupb_orderinfo_layout.setResizePercent(textf_orderdate,new java.awt.Rectangle(0,0,0,0));
        groupb_orderinfo_layout.setResizePercent(textf_status,new java.awt.Rectangle(0,0,0,0));
        groupb_orderinfo_layout.setResizePercent(textf_lastupdate,new java.awt.Rectangle(0,0,0,0));
        groupb_orderinfo_layout.setResizePercent(label_11,new java.awt.Rectangle(0,0,0,0));
        groupb_orderinfo_layout.setResizePercent(label_15,new java.awt.Rectangle(0,0,0,0));
        groupb_orderinfo_layout.setResizePercent(label_16,new java.awt.Rectangle(0,0,0,0));
        groupb_orderinfo_layout.setResizePercent(label_17,new java.awt.Rectangle(0,0,0,0));
        groupb_orderinfo_layout.setResizePercent(label_13,new java.awt.Rectangle(0,0,0,0));
        groupb_orderinfo_layout.setResizePercent(lb_orderid,new java.awt.Rectangle(0,0,0,0));

        return retval;
    }

    public synchronized boolean destroy()
    {
        if( (java.awt.Container)this instanceof java.awt.Window ) {
            ((java.awt.Window)(java.awt.Container)this).dispose();
        } else {
            removeNotify();
        }
        if( isMainForm() ) {
            System.gc();
            System.runFinalization();
            System.exit(0);
        }
        return true;
    }


    public boolean defaultHandleEvent(java.awt.Event event)
    {
        Object eventTarget = event.target;
        if( eventTarget == pictbttn_vieworder && event.id == java.awt.Event.ACTION_EVENT ) {
            return pictbttn_vieworder_Action(event);
        } else if( eventTarget == lb_custlist && event.id == java.awt.Event.LIST_SELECT ) {
            return lb_custlist_ListSelect(event);
        } else if( eventTarget == pictbttn_search && event.id == java.awt.Event.ACTION_EVENT ) {
            return pictbttn_search_Action(event);
        } else if( eventTarget == lb_orderid && event.id == java.awt.Event.LIST_SELECT ) {
            return lb_orderid_ListSelect(event);
        }
        return super.handleEvent(event);
    }
    public boolean handleEvent(java.awt.Event event)
    {

        return defaultHandleEvent(event);
    }
    public void unhandledEvent( String listenerName, String methodName, java.lang.Object event )
    {

    }
    public void setParent(ImpactMotorsMainForm parent)
    {
        _parent = parent;

    }
    public void resetChoice()
    {
        lb_custlist.clear();
    }
    public void resetCustInfo()
    {
        textf_last.setText (null);
        textf_first.setText (null);
        textf_street.setText (null);
        textf_city.setText (null);
        textf_st.setText (null);
        textf_zip.setText (null);
        textf_userid.setText (null);

    }
    public void resetOrderInfo()
    {
        textf_salesrep.setText( "" );
        textf_orderdate.setText( "" );
        textf_status.setText( "" );
        textf_lastupdate.setText( "" );
        resetOrderList();
    }
    public void getOrderInfo(String orderid)
    {      
        int result=0;
        boolean lastresult=false;
        String modelID="";
        String orderID="";


        orderID = orderid;

        if (query_2 == null)
            query_2 = _parent.getQuery2();

        _parent.set_sPBServer("niexdpbs");
        _parent.set_sDPBObject("n_cst_java");
        _parent.set_sDPBMethod("of_getorderinfo");
        _parent.set_sDPBArgs(orderid);


       _parent._PBObject.setResultSetConsumer( query_2 );

       result = _parent._PBObject.retrieve(_parent.get_sURLBase(), _parent.get_sPBServer(), _parent.get_sDPBObject(), _parent.get_sDPBMethod(), _parent.get_sDPBArgs() );


         if ( result > 0 ) 
               lastresult = query_2.moveFirst( true, true );
          else 
              System.out.println(_parent._PBObject.getErrorMsg());

    if (lastresult)
        {
        // set model name
        sModelName = query_2.getValue(1).toString().trim();

        // set model id and order id
        modelID = query_2.getValue (2).toString().trim();
        _parent.setModelClassID(modelID);

        // get vehicle colors
        sxColor = query_2.getValue(3).toString().trim();
        siColor = query_2.getValue(4).toString().trim();
        // get order information
        textf_orderdate.setText( query_2.getValue(5).toString() );
        textf_status.setText( query_2.getValue(6).toString() );
        textf_lastupdate.setText( query_2.getValue(7).toString() );
        // set sales rep
        textf_salesrep.setText( query_2.getValue(8).toString().trim() );

        if (textf_salesrep.getText().equals("0"))
        {
            textf_salesrep.setText("WebSite");
        }

        // show order groupbox if data
        if (!orderID.equals(""))
            groupb_orderinfo.show();


      if(!modelID.equals(""))
                {  
                _parent.setSOrderID(orderID);
                _parent.setModelClassID(modelID);

                _parent._ImpactMotorsMainForm_page_options.setOptions(modelID, orderID);
                _parent._ImpactMotorsMainForm_page_vehicleinfo.setColorInfo(modelID, sxColor, siColor, sModelName);
                _parent._ImpactMotorsMainForm_page_vehicleinfo.textf_modelname.setText(sModelName);

                _parent.setOrderEnable();
                }
            else
            {
                _parent.closeMsgWindow();
                _parent.setNoOrder();
            }
        }
        else
            _parent.setStatusText("Error Retrieving Order Information");
    }
    public void resetOrderList()
    {
       lb_orderid.clear();
        vOrderId.removeAllElements( );

    }
    public boolean pictbttn_vieworder_Action(java.awt.Event event)
    {
        java.lang.Object                item;
        int li_selected;
        String sOrderID="";

_parent.clearStatusText();

        sOrderID = lb_orderid.getSelectedItem();


        getOrderInfo(sOrderID);

        pictbttn_vieworder.disable();

        return false;
    }
    public boolean lb_custlist_ListSelect(java.awt.Event event)
    {
            int                             result;
        boolean                         lastresult=false;
        boolean                         resulttest;
        int li_selected;
        int li_Count;
        String lsSQL;
        String orderID;
        Vector vOrderId = new Vector();

_parent.clearStatusText();

        if (query_2 == null)
            query_2 = _parent.getQuery2();

    li_selected = lb_custlist.getSelectedIndex();
    li_Count = lb_custlist.countItems();



        if (li_selected == li_Count-1)
                return false;

 _parent.openMsgWindow("Retrieving Customer Information...");        


        lsSQL = (String)vCustID.elementAt(li_selected);


        _parent.set_sPBServer("niexdpbs");
        _parent.set_sDPBObject("n_cst_java");
        _parent.set_sDPBMethod("of_getcustomerinfo");
        _parent.set_sDPBArgs(lsSQL);


       _parent._PBObject.setResultSetConsumer( query_2 );

       result = _parent._PBObject.retrieve(_parent.get_sURLBase(), _parent.get_sPBServer(), _parent.get_sDPBObject(), _parent.get_sDPBMethod(), _parent.get_sDPBArgs() );


         if ( result > 0 ) 
               lastresult = query_2.moveFirst( true, true );
          else if (result < 0) 
              System.out.println(_parent._PBObject.getErrorMsg());


    if (lastresult)
        {
        // set customer info
        textf_last.setText (query_2.getValue(1).toString());
        textf_first.setText (query_2.getValue(2).toString());
        textf_street.setText (query_2.getValue(3).toString());
        textf_city.setText (query_2.getValue(4).toString());
        textf_zip.setText (query_2.getValue(5).toString());

        textf_st.setText (query_2.getValue(6).toString());
        textf_userid.setText (query_2.getValue(7).toString());
        textf_homephone.setText (query_2.getValue(8).toString());
        textf_wrkph.setText (query_2.getValue(9).toString());

        groupb_customerinfo.show();

        // order id
        orderID = query_2.getValue(10).toString();
        _parent.setSOrderID(orderID);

        if (!orderID.equals("-1"))
            {
                if (result >= 1 )
                {
                    for (int i=0;i<result;i++)
                    {
                    lb_orderid.addItem(orderID);
                    query_2.moveNext( true, true );
                    orderID = query_2.getValue(10).toString();
                    }
                }
            lb_orderid.select(0);
            pictbttn_vieworder.enable( true );

            }
            else
                {
                pictbttn_vieworder.disable();
                _parent.setOrderDisable();
                _parent.setNoOrder();
                }

        }
        else if (!lastresult)
        {
            _parent.setNoOrder();
            _parent.setStatusText("Error retrieving customer data");
        }

_parent.closeMsgWindow();        
        return false;
    }
    public boolean pictbttn_search_Action(java.awt.Event event)
    {
     boolean result=false;
_parent.clearStatusText();
        resetCustInfo();
        resetChoice();
        resetOrderInfo();
        _parent._ImpactMotorsMainForm_page_vehicleinfo.resetInfo();
        _parent._ImpactMotorsMainForm_page_options.resetOptionsInfo();

        _parent._ImpactMotorsMainForm_page_customer.groupb_orderinfo.hide();
        _parent._ImpactMotorsMainForm_page_customer.groupb_customerinfo.hide();

        vCustID.removeAllElements();


        String forSQL = "select  customer_id, customer_lname,customer_fname from customers where customer_lname like '";
        String aftSQL = "%' order by customer_lname";

        if ( !textf_2.getText().equals(""))
        {

        _parent.openMsgWindow("Retrieving Customer List...");

        if(query_1 == null)
            query_1 = _parent.getQuery1();

        query_1.setSQL (forSQL + textf_2.getText() + aftSQL);
        query_1.open();


        result = query_1.moveFirst(false, false);

        if (result)
        {
            while (result == true)
                {  

                vCustID.addElement(query_1.getValue(1).toString());
                lb_custlist.addItem(query_1.getValue(2).toString().trim() + ", " + 
                                 query_1.getValue(3).toString().trim());


                result = query_1.moveNext (false, false);
                }
                lb_custlist.addItem("<END>");
                lb_custlist.select( 0 );
                _parent.closeMsgWindow();
        }
        else
            _parent.setStatusText("Error Retrieving Customer List");
        }
        else 
        {

            // message box
            MessageDlg mdlg = new MessageDlg(_parent.getFrame(getParent()));
            mdlg.setMessageText("Please enter partial customer last name to search for.");
           try { mdlg.create();} catch (java.lang.Exception e){}

        }    


        return false;
    }
    public boolean pictbttn_search_objectCreated(powersoft.powerj.event.EventData event)
    {

        pictbttn_search.setImage("search.jpg");
        return false;
    }
    public boolean lb_orderid_ListSelect(java.awt.Event event)
    {
            pictbttn_vieworder.enable( true );

        return false;
    }
    /****************************************
     * data members
     ****************************************/

    boolean __mainForm = false;

    public ImpactMotorsMainForm __parentForm = null;
    public  powersoft.powerj.ui.GroupBox  groupb_customerinfo = new powersoft.powerj.ui.GroupBox();
    public  java.awt.TextField  textf_homephone = new java.awt.TextField();
    public  java.awt.TextField  textf_last = new java.awt.TextField();
    public  java.awt.Label  label_1 = new java.awt.Label();
    public  java.awt.Label  label_2 = new java.awt.Label();
    public  java.awt.Label  label_3 = new java.awt.Label();
    public  java.awt.Label  label_4 = new java.awt.Label();
    public  java.awt.Label  label_5 = new java.awt.Label();
    public  java.awt.Label  label_6 = new java.awt.Label();
    public  java.awt.TextField  textf_first = new java.awt.TextField();
    public  java.awt.TextField  textf_city = new java.awt.TextField();
    public  java.awt.TextField  textf_st = new java.awt.TextField();
    public  java.awt.TextField  textf_zip = new java.awt.TextField();
    public  java.awt.TextField  textf_wrkph = new java.awt.TextField();
    public  java.awt.Label  label_7 = new java.awt.Label();
    public  java.awt.Label  label_8 = new java.awt.Label();
    public  java.awt.TextField  textf_userid = new java.awt.TextField();
    public  java.awt.Label  label_9 = new java.awt.Label();
    public  java.awt.TextField  textf_street = new java.awt.TextField();
    public  powersoft.powerj.ui.PictureButton  pictbttn_vieworder = new powersoft.powerj.ui.PictureButton();
    public  powersoft.powerj.ui.GroupBox  groupb_search = new powersoft.powerj.ui.GroupBox();
    public  java.awt.Label  label_10 = new java.awt.Label();
    public  java.awt.TextField  textf_2 = new java.awt.TextField();
    public  java.awt.Label  label_18 = new java.awt.Label();
    public  java.awt.List  lb_custlist = new java.awt.List();
    public  powersoft.powerj.ui.PictureButton  pictbttn_search = new powersoft.powerj.ui.PictureButton();
    public  powersoft.powerj.ui.GroupBox  groupb_orderinfo = new powersoft.powerj.ui.GroupBox();
    public  java.awt.TextField  textf_salesrep = new java.awt.TextField();
    public  java.awt.TextField  textf_orderdate = new java.awt.TextField();
    public  java.awt.TextField  textf_status = new java.awt.TextField();
    public  java.awt.TextField  textf_lastupdate = new java.awt.TextField();
    public  java.awt.Label  label_11 = new java.awt.Label();
    public  java.awt.Label  label_15 = new java.awt.Label();
    public  java.awt.Label  label_16 = new java.awt.Label();
    public  java.awt.Label  label_17 = new java.awt.Label();
    public  java.awt.Label  label_13 = new java.awt.Label();
    public  java.awt.List  lb_orderid = new java.awt.List();

    // add your data members here

    powersoft.powerj.db.Query  query_1 = null;
    powersoft.powerj.db.jdbc_sql.Query  query_2 = null;
    Vector vOrderId = new Vector();

    ImpactMotorsMainForm _parent;
    Vector vCustID = new Vector();
    String siColor;
    String sxColor;
    String sModelName;
    Image coloredImage;
    Image orginalImage;
}




class ImpactMotorsMainForm_page_vehicleinfo extends java.awt.Panel implements powersoft.powerj.event.ClickListener
{
    public Rectangle DURectangle( int x, int y, int w, int h )
    {
        String        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        FontMetrics   fm = getFontMetrics( getFont() );
        double        fw = ( fm != null ) ? ( fm.stringWidth( alphabet ) / alphabet.length() ) : 0;
        double        fh = ( fm != null ) ? ( fm.getHeight() / 2.0 ) : 0.0;

        return new Rectangle( (int) Math.round( ( (double)fw * (double)x ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)y ) / 4.0 ),
                              (int) Math.round( ( (double)fw * (double)w ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)h ) / 4.0 ) );
    }

    public void DUPositionComponent( java.awt.Component comp, int x, int y, int w, int h, java.awt.Insets formInsets )
    {
        Rectangle     rect = DURectangle( x, y, w, h );
        if( formInsets != null ) {
             rect.x += formInsets.left;
             rect.y += formInsets.top;
        }
        comp.reshape( rect.x, rect.y, rect.width, rect.height );
    }

    public void setMainForm( boolean isMainForm )
    {
        __mainForm = isMainForm;
    }
    public boolean isMainForm()
    {
        return __mainForm;
    }
    public boolean create() throws java.lang.Exception
    {
        setFont( new Font( "Dialog", Font.PLAIN, 10 ) );

        boolean retval = true;
        __parentForm = (ImpactMotorsMainForm)(getParent().getParent().getParent());
        if( getPeer() == null ) {
            addNotify();
        }
        show();
        Insets formInsets = insets();
        hide();
        setBackground( Color.lightGray );
        setForeground( Color.black );

        powersoft.powerj.ui.ResizePercentLayout layout = new powersoft.powerj.ui.ResizePercentLayout();
        setLayout( layout );
        java.awt.FlowLayout groupb_carimage_layout = new java.awt.FlowLayout(java.awt.FlowLayout.LEFT,5,20);
        groupb_carimage.setLayout( groupb_carimage_layout );
        add(groupb_carimage);
        powersoft.powerj.ui.ResizePercentLayout groupb_currentcolors_layout = new powersoft.powerj.ui.ResizePercentLayout();
        groupb_currentcolors.setLayout( groupb_currentcolors_layout );
        add(groupb_currentcolors);
        java.awt.FlowLayout groupb_currentint_layout = new java.awt.FlowLayout(java.awt.FlowLayout.CENTER,20,20);
        groupb_currentint.setLayout( groupb_currentint_layout );
        groupb_currentcolors.add(groupb_currentint);
        java.awt.FlowLayout groupb_currentext_layout = new java.awt.FlowLayout(java.awt.FlowLayout.CENTER,20,20);
        groupb_currentext.setLayout( groupb_currentext_layout );
        groupb_currentcolors.add(groupb_currentext);
        add(pictbttn_colorchanger);
        add(textf_modelname);
        add(label_19);
        add(pictbttn_vieworiginal);
        DUPositionComponent( this, 0, 0, 429, 210, null );

        DUPositionComponent( groupb_carimage, 8, 40, 236, 112, formInsets );
        groupb_carimage.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        groupb_carimage.setBackground( Color.lightGray );
        groupb_carimage.setForeground( Color.black );
        groupb_carimage.enable(true);
        groupb_carimage.show();

        groupb_carimage.setText("Vehicle Image");

        DUPositionComponent( groupb_currentcolors, 8, 160, 236, 44, formInsets );
        groupb_currentcolors.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        groupb_currentcolors.setBackground( Color.lightGray );
        groupb_currentcolors.setForeground( Color.black );
        groupb_currentcolors.enable(true);
        groupb_currentcolors.show();

        groupb_currentcolors.setText("Current Colors");

        DUPositionComponent( groupb_currentint, 128, 11, 88, 27, null );
        groupb_currentint.setFont( new Font( "Dialog", Font.PLAIN, 12 ) );
        groupb_currentint.setBackground( Color.lightGray );
        groupb_currentint.setForeground( Color.black );
        groupb_currentint.enable(true);
        groupb_currentint.show();

        groupb_currentint.setText("Interior Color");

        DUPositionComponent( groupb_currentext, 12, 12, 88, 25, null );
        groupb_currentext.setFont( new Font( "Dialog", Font.PLAIN, 12 ) );
        groupb_currentext.setBackground( Color.lightGray );
        groupb_currentext.setForeground( Color.black );
        groupb_currentext.enable(true);
        groupb_currentext.show();

        groupb_currentext.setText("Exterior Color");

        pictbttn_colorchanger.addClickListener(this);
        DUPositionComponent( pictbttn_colorchanger, 264, 164, 88, 40, formInsets );
        pictbttn_colorchanger.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        pictbttn_colorchanger.setBackground( Color.lightGray );
        pictbttn_colorchanger.setForeground( Color.black );
        pictbttn_colorchanger.enable(true);
        pictbttn_colorchanger.show();

        Rectangle pictbttn_colorchanger_size_rect = DURectangle( 0, 0, 88, 40);
        pictbttn_colorchanger.resize(pictbttn_colorchanger_size_rect.width,pictbttn_colorchanger_size_rect.height);
        pictbttn_colorchanger.setLabel("Color Changer");
        pictbttn_colorchanger.setLabelPosition( powersoft.powerj.ui.PictureButton.LABEL_TOP );
        pictbttn_colorchanger.setInsets( new java.awt.Insets(1,1,1,1) );
        pictbttn_colorchanger.setShowFocus( true );

        pictbttn_colorchanger_objectCreated( new powersoft.powerj.event.EventData( pictbttn_colorchanger ) );
        DUPositionComponent( textf_modelname, 160, 24, 84, 12, formInsets );
        textf_modelname.setBackground( Color.lightGray );
        textf_modelname.setForeground( Color.black );
        textf_modelname.enable(true);
        textf_modelname.show();


        DUPositionComponent( label_19, 114, 24, 38, 12, formInsets );
        label_19.setAlignment(java.awt.Label.RIGHT);
        label_19.setText( "Model:" );
        label_19.setBackground( Color.lightGray );
        label_19.setForeground( Color.black );
        label_19.enable(true);
        label_19.show();


        pictbttn_vieworiginal.addClickListener(this);
        DUPositionComponent( pictbttn_vieworiginal, 264, 44, 88, 40, formInsets );
        pictbttn_vieworiginal.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        pictbttn_vieworiginal.setBackground( Color.lightGray );
        pictbttn_vieworiginal.setForeground( Color.black );
        pictbttn_vieworiginal.enable(true);
        pictbttn_vieworiginal.show();

        Rectangle pictbttn_vieworiginal_size_rect = DURectangle( 0, 0, 88, 40);
        pictbttn_vieworiginal.resize(pictbttn_vieworiginal_size_rect.width,pictbttn_vieworiginal_size_rect.height);
        pictbttn_vieworiginal.setLabel("View Original Picture");
        pictbttn_vieworiginal.setLabelPosition( powersoft.powerj.ui.PictureButton.LABEL_TOP );
        pictbttn_vieworiginal.setInsets( new java.awt.Insets(1,1,1,1) );
        pictbttn_vieworiginal.setShowFocus( true );

        pictbttn_vieworiginal_objectCreated( new powersoft.powerj.event.EventData( pictbttn_vieworiginal ) );
        layout.setResizePercent(groupb_carimage,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(groupb_currentcolors,new java.awt.Rectangle(0,0,0,0));
        groupb_currentcolors_layout.setResizePercent(groupb_currentint,new java.awt.Rectangle(0,0,0,0));
        groupb_currentcolors_layout.setResizePercent(groupb_currentext,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(pictbttn_colorchanger,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(textf_modelname,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(label_19,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(pictbttn_vieworiginal,new java.awt.Rectangle(0,0,0,0));

        page_vehicleinfo_objectCreated( new powersoft.powerj.event.EventData( this ) );
        return retval;
    }

    public synchronized boolean destroy()
    {
        if( (java.awt.Container)this instanceof java.awt.Window ) {
            ((java.awt.Window)(java.awt.Container)this).dispose();
        } else {
            removeNotify();
        }
        if( isMainForm() ) {
            System.gc();
            System.runFinalization();
            System.exit(0);
        }
        return true;
    }


    public boolean defaultHandleEvent(java.awt.Event event)
    {
        return super.handleEvent(event);
    }

    public void click( powersoft.powerj.event.ClickEvent event )
    {
        Object eventTarget = event.getSource();
        if( eventTarget == pictbttn_colorchanger ) {
            pictbttn_colorchanger_click( event );
        } else if( eventTarget == pictbttn_vieworiginal ) {
            pictbttn_vieworiginal_click( event );
        } else {
            unhandledEvent( "powersoft.powerj.event.ClickListener", "click", event );
        }
    }
    public boolean handleEvent(java.awt.Event event)
    {

        return defaultHandleEvent(event);
    }
    public void unhandledEvent( String listenerName, String methodName, java.lang.Object event )
    {

    }
    public void setParent(ImpactMotorsMainForm parent)
    {
        _parent = parent;

    }
    public void setColorInfo(String mid, String extColor, String intColor, String modelName)
    {

        _colorData = new ColorData(mid, _parent.getQuery1());


        _colorData.setExteriorColor(extColor);
        _colorData.setInteriorColor(intColor);


       // set exterior color swatch
        _exteriorCanvas.setBackground(new Color(_colorData.getRGB(_colorData.getExteriorColor())));
        _exteriorCanvas.setLabel(_colorData.getExteriorColor());
        // set interior color swatch
        _interiorCanvas.setBackground(new Color(_colorData.getRGB(_colorData.getInteriorColor())));
        _interiorCanvas.setLabel(_colorData.getInteriorColor());

        coloredImage = _parent.getPicture(modelName+"_c.gif");
        orginalImage = null;


        if ( _picCanvas == null)
        {
            _picCanvas = new ImageCanvas(coloredImage);
            groupb_carimage.add(_picCanvas);
        }

        _picCanvas.setImage(coloredImage,1);
        _picCanvas.reshape(5, 5, coloredImage.getWidth(_picCanvas)+10, coloredImage.getHeight(_picCanvas)+10);

        // set image colors
        _picCanvas.colorImage(Integer.toString(_exteriorCanvas.getBackground().getRGB(), 16),Integer.toString(_interiorCanvas.getBackground().getRGB(), 16) );



      }
    public void resetInfo()
    {
       if(_picCanvas != null)
        _picCanvas.eraseAll();

        textf_modelname.setText( "" );
       if(_interiorCanvas != null)
       {
        _interiorCanvas.eraseAll();
        _exteriorCanvas.eraseAll();
       }
    }
    public void setNewColors(Color extColor, Color intColor)
    {

    String sext="",sint="";

     _exteriorCanvas.setBackground(extColor);
     sext = (_colorData.getColorName(Integer.toString((_exteriorCanvas.getBackground().getRGB() & 0xffffff),16)));
     _exteriorCanvas.setLabel(sext);

      _interiorCanvas.setBackground(intColor);
      sint = _colorData.getColorName(Integer.toString((_interiorCanvas.getBackground().getRGB() & 0xffffff),16));
      _interiorCanvas.setLabel(sint);


      _colorData.setExteriorColor(sext);
      _colorData.setInteriorColor(sint);


	  // set image colors
	  _picCanvas.colorImage(Integer.toString(extColor.getRGB(), 16),Integer.toString(intColor.getRGB(), 16) );

    }
    public boolean page_vehicleinfo_objectCreated(powersoft.powerj.event.EventData event)
    {
        this.disable();
        _exteriorCanvas = new SwatchCanvas("");
        _interiorCanvas = new SwatchCanvas("");
        groupb_currentext.add( _exteriorCanvas );
        groupb_currentint.add( _interiorCanvas );


        return false;
    }
    public void pictbttn_colorchanger_click( powersoft.powerj.event.ClickEvent event )
    {

         coloredImage = _parent.getPicture(textf_modelname.getText()+"_c"+".gif" );

        VehicleColorChanger vcc = new VehicleColorChanger(_parent, _colorData, coloredImage);

        try { vcc.create();} catch (java.lang.Exception e){}




    }
    public boolean pictbttn_colorchanger_objectCreated(powersoft.powerj.event.EventData event)
    {
    pictbttn_colorchanger.setImage("color.jpg");

        return false;
    }
    public void pictbttn_vieworiginal_click( powersoft.powerj.event.ClickEvent event )
    {
        java.lang.String                label;
        if (orginalImage == null)
            orginalImage = _parent.getPicture(textf_modelname.getText()+".jpg");

            label = pictbttn_vieworiginal.getLabel();
        if (label.equals("View Original Picture"))
            {
                _picCanvas.setImage(orginalImage, 0);     
                pictbttn_vieworiginal.setLabel("View Colored Picture");
            }
         else if(label.equals("View Colored Picture"))
            {
                _picCanvas.setViewMode(2);     
                pictbttn_vieworiginal.setLabel("View Original Picture");
            }   

    }
    public boolean pictbttn_vieworiginal_objectCreated(powersoft.powerj.event.EventData event)
    {
    pictbttn_vieworiginal.setImage("picture.jpg");    

        return false;
    }
    /****************************************
     * data members
     ****************************************/

    boolean __mainForm = false;

    public ImpactMotorsMainForm __parentForm = null;
    public  powersoft.powerj.ui.GroupBox  groupb_carimage = new powersoft.powerj.ui.GroupBox();
    public  powersoft.powerj.ui.GroupBox  groupb_currentcolors = new powersoft.powerj.ui.GroupBox();
    public  powersoft.powerj.ui.GroupBox  groupb_currentint = new powersoft.powerj.ui.GroupBox();
    public  powersoft.powerj.ui.GroupBox  groupb_currentext = new powersoft.powerj.ui.GroupBox();
    public  powersoft.powerj.ui.PictureButton  pictbttn_colorchanger = new powersoft.powerj.ui.PictureButton();
    public  java.awt.TextField  textf_modelname = new java.awt.TextField();
    public  java.awt.Label  label_19 = new java.awt.Label();
    public  powersoft.powerj.ui.PictureButton  pictbttn_vieworiginal = new powersoft.powerj.ui.PictureButton();

    // add your data members here
    ImageCanvas _picCanvas=null;
    powersoft.powerj.db.jdbc_sql.Query  query_1 = null;
    ImpactMotorsMainForm _parent;
    SwatchCanvas _interiorCanvas=null;
    SwatchCanvas _exteriorCanvas=null;
   	ColorData _colorData;
    Image coloredImage=null;
    Image orginalImage=null;
}




class ImpactMotorsMainForm_page_options extends java.awt.Panel implements powersoft.powerj.ui.grid.SelectListener
{
    public Rectangle DURectangle( int x, int y, int w, int h )
    {
        String        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        FontMetrics   fm = getFontMetrics( getFont() );
        double        fw = ( fm != null ) ? ( fm.stringWidth( alphabet ) / alphabet.length() ) : 0;
        double        fh = ( fm != null ) ? ( fm.getHeight() / 2.0 ) : 0.0;

        return new Rectangle( (int) Math.round( ( (double)fw * (double)x ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)y ) / 4.0 ),
                              (int) Math.round( ( (double)fw * (double)w ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)h ) / 4.0 ) );
    }

    public void DUPositionComponent( java.awt.Component comp, int x, int y, int w, int h, java.awt.Insets formInsets )
    {
        Rectangle     rect = DURectangle( x, y, w, h );
        if( formInsets != null ) {
             rect.x += formInsets.left;
             rect.y += formInsets.top;
        }
        comp.reshape( rect.x, rect.y, rect.width, rect.height );
    }

    public void setMainForm( boolean isMainForm )
    {
        __mainForm = isMainForm;
    }
    public boolean isMainForm()
    {
        return __mainForm;
    }
    public boolean create() throws java.lang.Exception
    {
        setFont( new Font( "Dialog", Font.PLAIN, 10 ) );

        boolean retval = true;
        __parentForm = (ImpactMotorsMainForm)(getParent().getParent().getParent());
        if( getPeer() == null ) {
            addNotify();
        }
        show();
        Insets formInsets = insets();
        hide();
        setBackground( Color.lightGray );
        setForeground( Color.black );

        powersoft.powerj.ui.ResizePercentLayout layout = new powersoft.powerj.ui.ResizePercentLayout();
        setLayout( layout );
        add(pictbttn_addoptions);
        add(pictbttn_deleteoption);
        powersoft.powerj.ui.ResizePercentLayout groupb_3_layout = new powersoft.powerj.ui.ResizePercentLayout();
        groupb_3.setLayout( groupb_3_layout );
        add(groupb_3);
        groupb_3.add(grid_standardoptions);
        powersoft.powerj.ui.ResizePercentLayout groupb_4_layout = new powersoft.powerj.ui.ResizePercentLayout();
        groupb_4.setLayout( groupb_4_layout );
        add(groupb_4);
        groupb_4.add(grid_orderoptions);
        groupb_4.add(textf_total);
        groupb_4.add(label_12);
        DUPositionComponent( this, 0, 0, 429, 210, null );

        DUPositionComponent( pictbttn_addoptions, 316, 16, 88, 40, formInsets );
        pictbttn_addoptions.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        pictbttn_addoptions.setBackground( Color.lightGray );
        pictbttn_addoptions.setForeground( Color.black );
        pictbttn_addoptions.enable(true);
        pictbttn_addoptions.show();

        Rectangle pictbttn_addoptions_size_rect = DURectangle( 0, 0, 88, 40);
        pictbttn_addoptions.resize(pictbttn_addoptions_size_rect.width,pictbttn_addoptions_size_rect.height);
        pictbttn_addoptions.setLabel("Add Options");
        pictbttn_addoptions.setLabelPosition( powersoft.powerj.ui.PictureButton.LABEL_TOP );
        pictbttn_addoptions.setInsets( new java.awt.Insets(1,1,1,1) );
        pictbttn_addoptions.setShowFocus( true );

        pictbttn_addoptions_objectCreated( new powersoft.powerj.event.EventData( pictbttn_addoptions ) );
        DUPositionComponent( pictbttn_deleteoption, 316, 116, 88, 40, formInsets );
        pictbttn_deleteoption.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        pictbttn_deleteoption.setBackground( Color.lightGray );
        pictbttn_deleteoption.setForeground( Color.black );
        pictbttn_deleteoption.enable(false);
        pictbttn_deleteoption.show();

        Rectangle pictbttn_deleteoption_size_rect = DURectangle( 0, 0, 88, 40);
        pictbttn_deleteoption.resize(pictbttn_deleteoption_size_rect.width,pictbttn_deleteoption_size_rect.height);
        pictbttn_deleteoption.setLabel("Delete Option");
        pictbttn_deleteoption.setLabelPosition( powersoft.powerj.ui.PictureButton.LABEL_TOP );
        pictbttn_deleteoption.setInsets( new java.awt.Insets(1,1,1,1) );
        pictbttn_deleteoption.setShowFocus( true );

        pictbttn_deleteoption_objectCreated( new powersoft.powerj.event.EventData( pictbttn_deleteoption ) );
        DUPositionComponent( groupb_3, 4, 12, 296, 88, formInsets );
        groupb_3.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        groupb_3.setBackground( Color.lightGray );
        groupb_3.setForeground( Color.black );
        groupb_3.enable(true);
        groupb_3.show();

        groupb_3.setText("Standard Options");

        DUPositionComponent( grid_standardoptions, 8, 16, 280, 68, null );
        grid_standardoptions.setNumColumns( 0 );
        grid_standardoptions.setNumRows( 0 );
        grid_standardoptions.setShowHorizontalHeader( true );
        grid_standardoptions.setShowVerticalHeader( false );
        grid_standardoptions.setShowColumnLines( true );
        grid_standardoptions.setShowRowLines( true );
        grid_standardoptions.setFullRowSelection( true );
        grid_standardoptions.setLiveEditMode( false );
        grid_standardoptions.setMultipleSelection( false );
        grid_standardoptions.setResizableColumns( false );
        grid_standardoptions.setResizableRows( false );
        grid_standardoptions.setReadOnly( true );
        grid_standardoptions.setFont( new Font( "Dialog", Font.BOLD, 9234384 ) );
        grid_standardoptions.setBackground( powersoft.powerj.ui.grid.GridEnum.ALLCELLS, powersoft.powerj.ui.grid.GridEnum.ALLCELLS, Color.lightGray );
        grid_standardoptions.setForeground( Color.black );
        grid_standardoptions.enable(true);
        grid_standardoptions.show();

        grid_standardoptions.setHorizSBDisplay( powersoft.powerj.ui.grid.GridEnum.SBDISPLAY_NEVER );
        grid_standardoptions.setVertSBDisplay( powersoft.powerj.ui.grid.GridEnum.SBDISPLAY_AS_NEEDED );

        DUPositionComponent( groupb_4, 4, 112, 296, 88, formInsets );
        groupb_4.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        groupb_4.setBackground( Color.lightGray );
        groupb_4.setForeground( Color.black );
        groupb_4.enable(true);
        groupb_4.show();

        groupb_4.setText("Order Options");

        grid_orderoptions.addSelectListener(this);
        DUPositionComponent( grid_orderoptions, 4, 12, 280, 56, null );
        grid_orderoptions.setNumColumns( 0 );
        grid_orderoptions.setNumRows( 0 );
        grid_orderoptions.setShowHorizontalHeader( true );
        grid_orderoptions.setShowVerticalHeader( false );
        grid_orderoptions.setShowColumnLines( true );
        grid_orderoptions.setShowRowLines( true );
        grid_orderoptions.setFullRowSelection( true );
        grid_orderoptions.setLiveEditMode( false );
        grid_orderoptions.setMultipleSelection( false );
        grid_orderoptions.setResizableColumns( false );
        grid_orderoptions.setResizableRows( false );
        grid_orderoptions.setReadOnly( true );
        grid_orderoptions.setFont( new Font( "Dialog", Font.BOLD, 9234384 ) );
        grid_orderoptions.setBackground( powersoft.powerj.ui.grid.GridEnum.ALLCELLS, powersoft.powerj.ui.grid.GridEnum.ALLCELLS, Color.lightGray );
        grid_orderoptions.setForeground( Color.black );
        grid_orderoptions.enable(true);
        grid_orderoptions.show();

        grid_orderoptions.setHorizSBDisplay( powersoft.powerj.ui.grid.GridEnum.SBDISPLAY_NEVER );
        grid_orderoptions.setVertSBDisplay( powersoft.powerj.ui.grid.GridEnum.SBDISPLAY_AS_NEEDED );

        textf_total.setEditable(false);
        DUPositionComponent( textf_total, 8, 72, 48, 12, null );
        textf_total.setBackground( Color.lightGray );
        textf_total.setForeground( Color.black );
        textf_total.enable(true);
        textf_total.show();


        DUPositionComponent( label_12, 54, 72, 46, 12, null );
        label_12.setAlignment(java.awt.Label.LEFT);
        label_12.setText( "Total" );
        label_12.setBackground( Color.lightGray );
        label_12.setForeground( Color.black );
        label_12.enable(true);
        label_12.show();


        layout.setResizePercent(pictbttn_addoptions,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(pictbttn_deleteoption,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(groupb_3,new java.awt.Rectangle(0,0,0,0));
        groupb_3_layout.setResizePercent(grid_standardoptions,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(groupb_4,new java.awt.Rectangle(0,0,0,0));
        groupb_4_layout.setResizePercent(grid_orderoptions,new java.awt.Rectangle(0,0,0,0));
        groupb_4_layout.setResizePercent(textf_total,new java.awt.Rectangle(0,0,0,0));
        groupb_4_layout.setResizePercent(label_12,new java.awt.Rectangle(0,0,0,0));

        page_options_objectCreated( new powersoft.powerj.event.EventData( this ) );
        return retval;
    }

    public synchronized boolean destroy()
    {
        if( (java.awt.Container)this instanceof java.awt.Window ) {
            ((java.awt.Window)(java.awt.Container)this).dispose();
        } else {
            removeNotify();
        }
        if( isMainForm() ) {
            System.gc();
            System.runFinalization();
            System.exit(0);
        }
        return true;
    }


    public boolean defaultHandleEvent(java.awt.Event event)
    {
        Object eventTarget = event.target;
        if( eventTarget == pictbttn_addoptions && event.id == java.awt.Event.ACTION_EVENT ) {
            return pictbttn_addoptions_Action(event);
        } else if( eventTarget == pictbttn_deleteoption && event.id == java.awt.Event.ACTION_EVENT ) {
            return pictbttn_deleteoption_Action(event);
        }
        return super.handleEvent(event);
    }

    public void selectBegin( powersoft.powerj.ui.grid.SelectEvent event )
    {
    }
    public void selectEnd( powersoft.powerj.ui.grid.SelectEvent event )
    {
        Object eventTarget = event.getSource();
        if( eventTarget == grid_orderoptions ) {
            grid_orderoptions_selectEnd( event );
        } else {
            unhandledEvent( "powersoft.powerj.ui.grid.SelectListener", "selectEnd", event );
        }
    }
    public boolean handleEvent(java.awt.Event event)
    {

        return defaultHandleEvent(event);
    }
    public void unhandledEvent( String listenerName, String methodName, java.lang.Object event )
    {

    }
    public void setOptions(String mid, String oid)
    {
//     OptionsData standardOD = new  OptionsData();
     OptionsData orderOD = new  OptionsData();
     OptionsData od = new  OptionsData();
     String temp;
     boolean result = false;
     int count=0;
     int i=0;
//     String itemA;
     String sSQLStandard;

//     temp = "[IMAGE="+ _parent.getURLString()+"images/check16.gif][HORIZ_SPACE=10][ALIGN=MIDDLE]";

    Vector voDescStandardOptions = new Vector();


    sSQLStandard = "SELECT optional_equipment.option_description FROM model_options, optional_equipment"+  
         " WHERE ( optional_equipment.option_id = model_options.option_id ) and ( ( model_options.model_class_id ="+
         mid+
         " ) AND ( model_options.standard = 1 ) )";

_parent.cd.setLabelText("Retrieving Vehicle  Options Information...");

        if(query_1 == null)
            query_1 = _parent.getQuery1();

        query_1.close();
        query_1.setSQL (sSQLStandard);
        query_1.open();

        result = query_1.moveFirst(false, false);

        while (result == true)
        {  

         voDescStandardOptions.addElement(query_1.getValue(1).toString().trim());

          result = query_1.moveNext (false, false);
        }
/////////
        count = voDescStandardOptions.size();

        grid_standardoptions.setNumRows( count );
        i=0;
        for (Enumeration e = voDescStandardOptions.elements() ; e.hasMoreElements() ;) {
            temp = (String)e.nextElement();
            grid_standardoptions.setCell(i,0, temp);
//            grid_standardoptions.setCell(i,1, od.getDesc());
//            grid_standardoptions.setUserdata(i,2,od);
            i++;
        }

/////////

///////
   String sSQLorder = 
        "SELECT optional_equipment.option_description, optional_equipment.option_price, optional_equipment.option_id"+
        " FROM optional_equipment, order_options  WHERE ( order_options.option_id = optional_equipment.option_id ) and  ( ( order_options.order_id = "+
        oid+
        "))";



        query_1.close();
        query_1.setSQL (sSQLorder);
        result = query_1.open();
        result = query_1.moveFirst(false, false);

        while (result)
        {  
          orderOD.setDesc(query_1.getValue(1).toString().trim());
          orderOD.setPrice(query_1.getValue(2).toString().trim());
          orderOD.setId(query_1.getValue(3).toString().trim());

          voDescOrderOptions.addElement(new OptionsData(_parent.formatCurrency(orderOD.getPrice()), orderOD.getDesc(), orderOD.getId()));
          result = query_1.moveNext(false, false);


        }
//////////
        count = voDescOrderOptions.size();

        grid_orderoptions.setNumRows( count );
        i=0;
        for (Enumeration e = voDescOrderOptions.elements() ; e.hasMoreElements() ;) {
            od = (OptionsData)e.nextElement();
            grid_orderoptions.setCell(i,0, od.getPrice());
            grid_orderoptions.setCell(i,1, od.getDesc());
            grid_orderoptions.setUserdata(i,2,od);
            i++;
        }

/////////


        sumOptions();
    }
    public void setParent(ImpactMotorsMainForm parent)
    {
        _parent = parent;

    }
    public void resetOptionsInfo()

    {

        if (grid_standardoptions.getNumRows() > 0)
            grid_standardoptions.deleteAllRows();

        if(grid_orderoptions.getNumRows() > 0)
            grid_orderoptions.deleteAllRows();

        textf_total.setText( "" );

    }
    public void sumOptions()
    {

        String sTemp = new String("");
        int total=0;
        int len=0;
        int i;

        len = grid_orderoptions.getNumRows();

        for(i=0;i<len;i++)
        {
            sTemp = (String)grid_orderoptions.getCell(i,0);
            if (!(sTemp.equals(""))){

                total += _parent.unformatCurrency(sTemp.substring(1).trim());

            }
         }
    textf_total.setText(_parent.formatCurrency(Integer.toString(total)));

    }
    public void setAddedOptions(Vector v)
    {
        OptionsData od = new  OptionsData();
        int i=0;

//        count = voDescStandardOptions.size();

//        grid_standardoptions.setNumRows( count );
        i=0;
        for (Enumeration e = v.elements() ; e.hasMoreElements() ;) {
            od = (OptionsData)e.nextElement();
            grid_orderoptions.setCell(i,0, od.getPrice());
            grid_orderoptions.setCell(i,1, od.getDesc());
            grid_orderoptions.setUserdata(i,2,od);
            i++;
        }


        sumOptions();

    }
    public boolean page_options_objectCreated(powersoft.powerj.event.EventData event)
    {
        String options[] = new String[2];
       java.awt.Image imgCheck = null;
        java.awt.Image imgDollar = null;
        powersoft.powerj.ui.grid.GString[] gstring = new powersoft.powerj.ui.grid.GString[2];

        String[] labels = {"Price", "Option Description"};

//       imgCheck = _parent.getPicture("check16.gif");
//       imgDollar = _parent.getPicture("check16.gif");



        gstring[0] = new powersoft.powerj.ui.grid.GString(labels[0], imgDollar, 1);
        gstring[1] = new powersoft.powerj.ui.grid.GString(labels[1], imgCheck, 1);
////////////////////
        grid_standardoptions.setNumColumns( 1 );
        grid_orderoptions.setNumColumns( 2 );


        grid_standardoptions.setCharWidth( 0, 45 );
        grid_orderoptions.setCharWidth( 0, 5 );

//        grid_standardoptions.setCharWidth( 1, 30 );
        grid_orderoptions.setCharWidth( 1, 30 );

        grid_standardoptions.setBorderType( -1,0,GridEnum.BORDER_OUT );
        grid_standardoptions.setBorderType( -1,1,GridEnum.BORDER_OUT );

        grid_orderoptions.setBorderType( -1,0, GridEnum.BORDER_OUT );
        grid_orderoptions.setBorderType( -1,1, GridEnum.BORDER_OUT );

        grid_standardoptions.setColumnLabel( 0, gstring[1] );
        grid_orderoptions.setColumnLabel( 0, gstring[0] );

//        grid_standardoptions.setColumnLabel( 1, gstring[1] );
        grid_orderoptions.setColumnLabel( 1, gstring[1] );


        grid_standardoptions.setForeground( -1, 0, java.awt.Color.black );
        grid_standardoptions.setBackground( -1, 0, java.awt.Color.lightGray );
//        grid_standardoptions.setForeground( -1, 1, java.awt.Color.black );
//        grid_standardoptions.setBackground( -1, 1, java.awt.Color.lightGray );
        grid_standardoptions.setFont( -1, 0, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12 ));
//        grid_standardoptions.setFont( -1, 1, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12 ));
        grid_standardoptions.setAlignment( -1, 0, GridEnum.MIDDLECENTER );
//        grid_standardoptions.setAlignment( -1, 1, GridEnum.MIDDLECENTER );

        grid_orderoptions.setForeground( -1, 0, java.awt.Color.black );
        grid_orderoptions.setBackground( -1, 0, java.awt.Color.lightGray );
        grid_orderoptions.setForeground( -1, 1, java.awt.Color.black );
        grid_orderoptions.setBackground( -1, 1, java.awt.Color.lightGray );
        grid_orderoptions.setFont( -1, 0, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12 ));
        grid_orderoptions.setFont( -1, 1, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12 ));
        grid_orderoptions.setAlignment( -1, 0, GridEnum.MIDDLECENTER );
        grid_orderoptions.setAlignment( -1, 1, GridEnum.MIDDLECENTER );


        this.disable();

        return false;
    }
    public boolean pictbttn_addoptions_Action(java.awt.Event event)
    {
    OptionsData od = new OptionsData();
    OptionsData odl = new OptionsData();
    Vector list= new Vector();
    int j=0;

_parent.clearStatusText();

        list = _parent.getModelOptions();

        if (list.size() >0)
        {
        // filter to remove current order options
        for (Enumeration e = voDescOrderOptions.elements(); e.hasMoreElements();)
                {
                    od = (OptionsData)e.nextElement();
                    j=0;
                    for (Enumeration en = list.elements(); en.hasMoreElements();)
                    {
                        odl = (OptionsData)en.nextElement();
                        if (odl.getId().equals(od.getId()))
                              list.removeElementAt(j);
                              j++;
                    }
               }

        VehicleOptions vo = new  VehicleOptions(_parent, _parent.getFrame(this), list);
        try { vo.create();} catch (java.lang.Exception e){}

        }

        return false;
    }
    public boolean pictbttn_addoptions_objectCreated(powersoft.powerj.event.EventData event)
    {
    pictbttn_addoptions.setImage("addoptions.jpg");    

        return false;
    }
    public boolean pictbttn_deleteoption_Action(java.awt.Event event)
    {
        String deleteSQL="";
        OptionsData od = new OptionsData();

         boolean result=false;

        od = (OptionsData)grid_orderoptions.getUserdata(_currentRowOrders,2);


        deleteSQL = "DELETE FROM order_options WHERE ( order_options.order_id = "+
        _parent.getSOrderID()+ ") AND"+  
         "( order_options.option_id = "+
         od.getId()+ 
         ")";

         if (query_1 == null)
            query_1 = _parent.getQuery2();

         query_1.close();
         query_1.setSQL(deleteSQL);
         result = query_1.open();


         if(result)
         {
            grid_orderoptions.deleteRow(_currentRowOrders);;
            sumOptions();
            pictbttn_deleteoption.disable();
         }



        return false;
    }
    public boolean pictbttn_deleteoption_objectCreated(powersoft.powerj.event.EventData event)
    {
    pictbttn_deleteoption.setImage("cutoption.jpg");    

        return false;
    }
    public void grid_orderoptions_selectEnd( powersoft.powerj.ui.grid.SelectEvent event )
    {
            int temp;

            temp = event.getRow();
            if(temp >= 0)
            {
             _currentRowOrders = temp;
             pictbttn_deleteoption.enable(true);
            }
            else
                pictbttn_deleteoption.enable(false);


    }
    /****************************************
     * data members
     ****************************************/

    boolean __mainForm = false;

    public ImpactMotorsMainForm __parentForm = null;
    private  powersoft.powerj.ui.PictureButton  pictbttn_addoptions = new powersoft.powerj.ui.PictureButton();
    private  powersoft.powerj.ui.PictureButton  pictbttn_deleteoption = new powersoft.powerj.ui.PictureButton();
    private  powersoft.powerj.ui.GroupBox  groupb_3 = new powersoft.powerj.ui.GroupBox();
    private  powersoft.powerj.ui.grid.Grid  grid_standardoptions = new powersoft.powerj.ui.grid.Grid();
    private  powersoft.powerj.ui.GroupBox  groupb_4 = new powersoft.powerj.ui.GroupBox();
    private  powersoft.powerj.ui.grid.Grid  grid_orderoptions = new powersoft.powerj.ui.grid.Grid();
    private  java.awt.TextField  textf_total = new java.awt.TextField();
    private  java.awt.Label  label_12 = new java.awt.Label();

    // add your data members here
    powersoft.powerj.db.Query  query_1 = null;
    ImpactMotorsMainForm _parent;
    Vector voDescOrderOptions = new Vector();
    int _currentRowOrders=-1;
}




class ImpactMotorsMainForm_page_bound extends java.awt.Panel
{
    public Rectangle DURectangle( int x, int y, int w, int h )
    {
        String        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        FontMetrics   fm = getFontMetrics( getFont() );
        double        fw = ( fm != null ) ? ( fm.stringWidth( alphabet ) / alphabet.length() ) : 0;
        double        fh = ( fm != null ) ? ( fm.getHeight() / 2.0 ) : 0.0;

        return new Rectangle( (int) Math.round( ( (double)fw * (double)x ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)y ) / 4.0 ),
                              (int) Math.round( ( (double)fw * (double)w ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)h ) / 4.0 ) );
    }

    public void DUPositionComponent( java.awt.Component comp, int x, int y, int w, int h, java.awt.Insets formInsets )
    {
        Rectangle     rect = DURectangle( x, y, w, h );
        if( formInsets != null ) {
             rect.x += formInsets.left;
             rect.y += formInsets.top;
        }
        comp.reshape( rect.x, rect.y, rect.width, rect.height );
    }

    public void setMainForm( boolean isMainForm )
    {
        __mainForm = isMainForm;
    }
    public boolean isMainForm()
    {
        return __mainForm;
    }
    public boolean create() throws java.lang.Exception
    {
        setFont( new Font( "Dialog", Font.PLAIN, 10 ) );

        boolean retval = true;
        __parentForm = (ImpactMotorsMainForm)(getParent().getParent().getParent());
        if( getPeer() == null ) {
            addNotify();
        }
        show();
        Insets formInsets = insets();
        hide();
        setBackground( Color.lightGray );
        setForeground( Color.black );

        powersoft.powerj.ui.ResizePercentLayout layout = new powersoft.powerj.ui.ResizePercentLayout();
        setLayout( layout );
        groupb_textcontrols.setLayout( null );
        add(groupb_textcontrols);
        groupb_textcontrols.add(dataNavigator_1);
        groupb_textcontrols.add(textf_fname);
        groupb_textcontrols.add(textf_address1);
        groupb_textcontrols.add(textf_empuserid);
        groupb_textcontrols.add(textf_empcity);
        groupb_textcontrols.add(textf_empstate);
        groupb_textcontrols.add(textf_lname);
        groupb_textcontrols.add(label_14);
        groupb_textcontrols.add(label_20);
        groupb_textcontrols.add(label_21);
        groupb_textcontrols.add(label_22);
        groupb_textcontrols.add(label_23);
        groupb_textcontrols.add(label_24);
        groupb_textcontrols.add(textf_empzipcode);
        groupb_textcontrols.add(label_25);
        groupb_textcontrols.add(textf_empstartdate);
        groupb_textcontrols.add(textf_emphomephone);
        groupb_textcontrols.add(label_26);
        groupb_textcontrols.add(label_27);
        groupb_textcontrols.add(textf_empid);
        groupb_textcontrols.add(textf_deptid);
        groupb_textcontrols.add(label_28);
        groupb_textcontrols.add(label_29);
        groupb_textcontrols.add(textf_empssnum);
        groupb_textcontrols.add(label_30);
        groupb_textcontrols.add(textf_empsalary);
        groupb_textcontrols.add(label_31);
        groupb_textcontrols.add(textf_empbirthdate);
        groupb_textcontrols.add(label_32);
        groupb_textcontrols.add(textf_empsex);
        groupb_textcontrols.add(label_33);
        add(pictbttn_retrieveemp);
        DUPositionComponent( this, 0, 0, 429, 210, null );

        DUPositionComponent( groupb_textcontrols, 16, 12, 304, 180, formInsets );
        groupb_textcontrols.setBackground( Color.lightGray );
        groupb_textcontrols.setForeground( Color.black );
        groupb_textcontrols.enable(true);
        groupb_textcontrols.show();

        groupb_textcontrols.setText("Bound Text Controls");

        DUPositionComponent( dataNavigator_1, 60, 156, 176, 16, null );
        dataNavigator_1.setBackground( Color.lightGray );
        dataNavigator_1.setForeground( Color.black );
        dataNavigator_1.enable(true);
        dataNavigator_1.show();

        dataNavigator_1.setDataSource( powersoft.powerj.db.Query.findByName( "ImpactMotorsMainForm.query_2", false ) );
        dataNavigator_1.setBOFAction(powersoft.powerj.ui.DataNavigator.ACTION_MOVE_FIRST);
        dataNavigator_1.setEOFAction(powersoft.powerj.ui.DataNavigator.ACTION_MOVE_LAST);
        dataNavigator_1.setShowAdd(false);
        dataNavigator_1.setShowCancel(false);
        dataNavigator_1.setShowDelete(false);
        dataNavigator_1.setShowEdit(false);
        dataNavigator_1.setShowMoveFirst(false);
        dataNavigator_1.setShowMoveLast(false);
        dataNavigator_1.setShowMoveNext(false);
        dataNavigator_1.setShowMovePrevious(false);
        dataNavigator_1.setShowUpdate(false);

        dataNavigator_1_objectCreated( new powersoft.powerj.event.EventData( dataNavigator_1 ) );
        DUPositionComponent( textf_fname, 16, 24, 64, 12, null );
        textf_fname.setBackground( Color.lightGray );
        textf_fname.setForeground( Color.black );
        textf_fname.setDataSource( powersoft.powerj.db.Query.findByName( "ImpactMotorsMainForm.query_2", false ) );
        textf_fname.enable(true);
        textf_fname.show();


        DUPositionComponent( textf_address1, 16, 52, 172, 12, null );
        textf_address1.setBackground( Color.lightGray );
        textf_address1.setForeground( Color.black );
        textf_address1.setDataSource( powersoft.powerj.db.Query.findByName( "ImpactMotorsMainForm.query_2", false ) );
        textf_address1.enable(true);
        textf_address1.show();


        DUPositionComponent( textf_empuserid, 200, 52, 88, 12, null );
        textf_empuserid.setBackground( Color.lightGray );
        textf_empuserid.setForeground( Color.black );
        textf_empuserid.setDataSource( powersoft.powerj.db.Query.findByName( "ImpactMotorsMainForm.query_2", false ) );
        textf_empuserid.enable(true);
        textf_empuserid.show();


        DUPositionComponent( textf_empcity, 16, 80, 64, 12, null );
        textf_empcity.setBackground( Color.lightGray );
        textf_empcity.setForeground( Color.black );
        textf_empcity.setDataSource( powersoft.powerj.db.Query.findByName( "ImpactMotorsMainForm.query_2", false ) );
        textf_empcity.enable(true);
        textf_empcity.show();


        DUPositionComponent( textf_empstate, 92, 80, 16, 12, null );
        textf_empstate.setBackground( Color.lightGray );
        textf_empstate.setForeground( Color.black );
        textf_empstate.setDataSource( powersoft.powerj.db.Query.findByName( "ImpactMotorsMainForm.query_2", false ) );
        textf_empstate.enable(true);
        textf_empstate.show();


        DUPositionComponent( textf_lname, 88, 24, 100, 12, null );
        textf_lname.setBackground( Color.lightGray );
        textf_lname.setForeground( Color.black );
        textf_lname.setDataSource( powersoft.powerj.db.Query.findByName( "ImpactMotorsMainForm.query_2", false ) );
        textf_lname.enable(true);
        textf_lname.show();


        DUPositionComponent( label_14, 10, 12, 62, 10, null );
        label_14.setAlignment(java.awt.Label.LEFT);
        label_14.setText( "First Name" );
        label_14.setBackground( Color.lightGray );
        label_14.setForeground( Color.black );
        label_14.enable(true);
        label_14.show();


        DUPositionComponent( label_20, 82, 12, 62, 10, null );
        label_20.setAlignment(java.awt.Label.LEFT);
        label_20.setText( "Last Name" );
        label_20.setBackground( Color.lightGray );
        label_20.setForeground( Color.black );
        label_20.enable(true);
        label_20.show();


        DUPositionComponent( label_21, 10, 43, 62, 10, null );
        label_21.setAlignment(java.awt.Label.LEFT);
        label_21.setText( "Address 1" );
        label_21.setBackground( Color.lightGray );
        label_21.setForeground( Color.black );
        label_21.enable(true);
        label_21.show();


        DUPositionComponent( label_22, 194, 12, 46, 10, null );
        label_22.setAlignment(java.awt.Label.CENTER);
        label_22.setText( "Emp ID" );
        label_22.setBackground( Color.lightGray );
        label_22.setForeground( Color.black );
        label_22.enable(true);
        label_22.show();


        DUPositionComponent( label_23, 10, 72, 62, 10, null );
        label_23.setAlignment(java.awt.Label.LEFT);
        label_23.setText( "City" );
        label_23.setBackground( Color.lightGray );
        label_23.setForeground( Color.black );
        label_23.enable(true);
        label_23.show();


        DUPositionComponent( label_24, 86, 72, 22, 10, null );
        label_24.setAlignment(java.awt.Label.LEFT);
        label_24.setText( "State" );
        label_24.setBackground( Color.lightGray );
        label_24.setForeground( Color.black );
        label_24.enable(true);
        label_24.show();


        DUPositionComponent( textf_empzipcode, 120, 80, 70, 12, null );
        textf_empzipcode.setBackground( Color.lightGray );
        textf_empzipcode.setForeground( Color.black );
        textf_empzipcode.setDataSource( powersoft.powerj.db.Query.findByName( "ImpactMotorsMainForm.query_2", false ) );
        textf_empzipcode.enable(true);
        textf_empzipcode.show();


        DUPositionComponent( label_25, 114, 72, 76, 10, null );
        label_25.setAlignment(java.awt.Label.LEFT);
        label_25.setText( "Zip Code" );
        label_25.setBackground( Color.lightGray );
        label_25.setForeground( Color.black );
        label_25.enable(true);
        label_25.show();


        DUPositionComponent( textf_empstartdate, 16, 132, 70, 12, null );
        textf_empstartdate.setBackground( Color.lightGray );
        textf_empstartdate.setForeground( Color.black );
        textf_empstartdate.setDataSource( powersoft.powerj.db.Query.findByName( "ImpactMotorsMainForm.query_2", false ) );
        textf_empstartdate.enable(true);
        textf_empstartdate.show();


        DUPositionComponent( textf_emphomephone, 104, 132, 70, 12, null );
        textf_emphomephone.setBackground( Color.lightGray );
        textf_emphomephone.setForeground( Color.black );
        textf_emphomephone.setDataSource( powersoft.powerj.db.Query.findByName( "ImpactMotorsMainForm.query_2", false ) );
        textf_emphomephone.enable(true);
        textf_emphomephone.show();


        DUPositionComponent( label_26, 10, 124, 76, 10, null );
        label_26.setAlignment(java.awt.Label.LEFT);
        label_26.setText( "Start Date" );
        label_26.setBackground( Color.lightGray );
        label_26.setForeground( Color.black );
        label_26.enable(true);
        label_26.show();


        DUPositionComponent( label_27, 98, 124, 76, 10, null );
        label_27.setAlignment(java.awt.Label.LEFT);
        label_27.setText( "Home Phone" );
        label_27.setBackground( Color.lightGray );
        label_27.setForeground( Color.black );
        label_27.enable(true);
        label_27.show();


        DUPositionComponent( textf_empid, 200, 24, 40, 12, null );
        textf_empid.setBackground( Color.lightGray );
        textf_empid.setForeground( Color.black );
        textf_empid.setDataSource( powersoft.powerj.db.Query.findByName( "ImpactMotorsMainForm.query_2", false ) );
        textf_empid.enable(true);
        textf_empid.show();


        DUPositionComponent( textf_deptid, 248, 24, 40, 12, null );
        textf_deptid.setBackground( Color.lightGray );
        textf_deptid.setForeground( Color.black );
        textf_deptid.setDataSource( powersoft.powerj.db.Query.findByName( "ImpactMotorsMainForm.query_2", false ) );
        textf_deptid.enable(true);
        textf_deptid.show();


        DUPositionComponent( label_28, 242, 12, 46, 10, null );
        label_28.setAlignment(java.awt.Label.CENTER);
        label_28.setText( "Dept. ID" );
        label_28.setBackground( Color.lightGray );
        label_28.setForeground( Color.black );
        label_28.enable(true);
        label_28.show();


        DUPositionComponent( label_29, 194, 44, 50, 8, null );
        label_29.setAlignment(java.awt.Label.LEFT);
        label_29.setText( "User ID" );
        label_29.setBackground( Color.lightGray );
        label_29.setForeground( Color.black );
        label_29.enable(true);
        label_29.show();


        DUPositionComponent( textf_empssnum, 16, 108, 70, 12, null );
        textf_empssnum.setBackground( Color.lightGray );
        textf_empssnum.setForeground( Color.black );
        textf_empssnum.setDataSource( powersoft.powerj.db.Query.findByName( "ImpactMotorsMainForm.query_2", false ) );
        textf_empssnum.enable(true);
        textf_empssnum.show();


        DUPositionComponent( label_30, 10, 100, 76, 10, null );
        label_30.setAlignment(java.awt.Label.LEFT);
        label_30.setText( "Social Security #" );
        label_30.setBackground( Color.lightGray );
        label_30.setForeground( Color.black );
        label_30.enable(true);
        label_30.show();


        DUPositionComponent( textf_empsalary, 104, 108, 70, 12, null );
        textf_empsalary.setBackground( Color.lightGray );
        textf_empsalary.setForeground( Color.black );
        textf_empsalary.setDataSource( powersoft.powerj.db.Query.findByName( "ImpactMotorsMainForm.query_2", false ) );
        textf_empsalary.enable(true);
        textf_empsalary.show();


        DUPositionComponent( label_31, 98, 100, 74, 8, null );
        label_31.setAlignment(java.awt.Label.LEFT);
        label_31.setText( "Salary" );
        label_31.setBackground( Color.lightGray );
        label_31.setForeground( Color.black );
        label_31.enable(true);
        label_31.show();


        DUPositionComponent( textf_empbirthdate, 196, 108, 70, 12, null );
        textf_empbirthdate.setBackground( Color.lightGray );
        textf_empbirthdate.setForeground( Color.black );
        textf_empbirthdate.setDataSource( powersoft.powerj.db.Query.findByName( "ImpactMotorsMainForm.query_2", false ) );
        textf_empbirthdate.enable(true);
        textf_empbirthdate.show();


        DUPositionComponent( label_32, 190, 96, 76, 10, null );
        label_32.setAlignment(java.awt.Label.LEFT);
        label_32.setText( "Birthday" );
        label_32.setBackground( Color.lightGray );
        label_32.setForeground( Color.black );
        label_32.enable(true);
        label_32.show();


        DUPositionComponent( textf_empsex, 208, 132, 12, 12, null );
        textf_empsex.setBackground( Color.lightGray );
        textf_empsex.setForeground( Color.black );
        textf_empsex.setDataSource( powersoft.powerj.db.Query.findByName( "ImpactMotorsMainForm.query_2", false ) );
        textf_empsex.enable(true);
        textf_empsex.show();


        DUPositionComponent( label_33, 190, 124, 76, 10, null );
        label_33.setAlignment(java.awt.Label.LEFT);
        label_33.setText( "Employee Sex" );
        label_33.setBackground( Color.lightGray );
        label_33.setForeground( Color.black );
        label_33.enable(true);
        label_33.show();


        DUPositionComponent( pictbttn_retrieveemp, 344, 16, 80, 20, formInsets );
        pictbttn_retrieveemp.setBackground( Color.lightGray );
        pictbttn_retrieveemp.setForeground( Color.black );
        pictbttn_retrieveemp.enable(true);
        pictbttn_retrieveemp.show();

        Rectangle pictbttn_retrieveemp_size_rect = DURectangle( 0, 0, 80, 20);
        pictbttn_retrieveemp.resize(pictbttn_retrieveemp_size_rect.width,pictbttn_retrieveemp_size_rect.height);
        pictbttn_retrieveemp.setLabel("Retrieve Employees");
        pictbttn_retrieveemp.setLabelPosition( powersoft.powerj.ui.PictureButton.LABEL_BOTTOM );
        pictbttn_retrieveemp.setInsets( new java.awt.Insets(5,5,5,5) );
        pictbttn_retrieveemp.setShowFocus( true );

        layout.setResizePercent(groupb_textcontrols,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(pictbttn_retrieveemp,new java.awt.Rectangle(0,0,0,0));

        return retval;
    }

    public synchronized boolean destroy()
    {
        if( (java.awt.Container)this instanceof java.awt.Window ) {
            ((java.awt.Window)(java.awt.Container)this).dispose();
        } else {
            removeNotify();
        }
        if( isMainForm() ) {
            System.gc();
            System.runFinalization();
            System.exit(0);
        }
        return true;
    }


    public boolean defaultHandleEvent(java.awt.Event event)
    {
        Object eventTarget = event.target;
        if( eventTarget == pictbttn_retrieveemp && event.id == java.awt.Event.ACTION_EVENT ) {
            return pictbttn_retrieveemp_Action(event);
        }
        return super.handleEvent(event);
    }
    public boolean handleEvent(java.awt.Event event)
    {

        return defaultHandleEvent(event);
    }
    public void unhandledEvent( String listenerName, String methodName, java.lang.Object event )
    {

    }
    public void setControls()
    {
     int rCnt=0, cCnt=0;
     int result;
     boolean lastresult=false;
     String resultSet = "";
     String temp="";
     String label="";
     int width=0;


    if (query_1 == null)
        query_1 = _parent.getQuery2();

        _parent.set_sPBServer("niexdpbs");
        _parent.set_sDPBObject("n_cst_java");
        _parent.set_sDPBMethod("of_getemployees");
        _parent.set_sDPBArgs("");

       _parent._PBObject.setResultSetConsumer( query_1 );



       result = _parent._PBObject.retrieve(_parent.get_sURLBase(), _parent.get_sPBServer(), _parent.get_sDPBObject(), _parent.get_sDPBMethod(), _parent.get_sDPBArgs() );




         if ( result > 0 ) 
            {
                bindControls();
                query_1.moveNext( true, true );
            }
          else if (result < 0)
          { 
              System.out.println();
              _parent.setStatusText("Error Retrieving data: "+_parent._PBObject.getErrorMsg());
          }

_parent.closeMsgWindow();

    }
    public void bindControls()
    {
      // set control binding   

//       textf_empid.setDataSource( query_1 );
       textf_empid.setDataColumns( "1" );


//       textf_deptid.setDataSource( query_1 );
       textf_deptid.setDataColumns( "2" );

//       textf_empuserid.setDataSource( query_1 );
       textf_empuserid.setDataColumns( "3" );

//       textf_lname.setDataSource( query_1 );
       textf_lname.setDataColumns( "4" );

//       textf_fname.setDataSource( query_1 );
       textf_fname.setDataColumns( "5" );

//       textf_address1.setDataSource( query_1 );
       textf_address1.setDataColumns( "6" );

//       textf_empcity.setDataSource( query_1 );
       textf_empcity.setDataColumns( "7" );

//       textf_empstate.setDataSource( query_1 );
       textf_empstate.setDataColumns( "8" );

//       textf_empzipcode.setDataSource( query_1 );
       textf_empzipcode.setDataColumns( "9" );

//       textf_empssnum.setDataSource( query_1 );
       textf_empssnum.setDataColumns( "10" );

//       textf_empsalary.setDataSource( query_1 );
       textf_empsalary.setDataColumns( "11" );

//       textf_empstartdate.setDataSource( query_1 );
       textf_empstartdate.setDataColumns( "12" );

//       textf_empbirthdate.setDataSource( query_1 );
       textf_empbirthdate.setDataColumns( "13" );

//       textf_empsex.setDataSource( query_1 );
       textf_empsex.setDataColumns( "14" );

//       textf_emphomephone.setDataSource( query_1 );
       textf_emphomephone.setDataColumns( "15" );

//       dataNavigator_1.setDataSource( query_1 );

    }
    public void setParent(ImpactMotorsMainForm parent)
    {
        _parent = parent;    
    }
    public boolean dataNavigator_1_objectCreated(powersoft.powerj.event.EventData event)
    {
        dataNavigator_1.setShowMoveFirst( true );
        dataNavigator_1.setShowMoveLast( true );
        dataNavigator_1.setShowMoveNext( true );
        dataNavigator_1.setShowMovePrevious( true );


        return false;
    }
    public boolean pictbttn_retrieveemp_Action(java.awt.Event event)
    {
_parent.clearStatusText();        
_parent.openMsgWindow("Retrieving Employee data...");
        setControls();
        return false;
    }
    /****************************************
     * data members
     ****************************************/

    boolean __mainForm = false;

    public ImpactMotorsMainForm __parentForm = null;
    private  powersoft.powerj.ui.GroupBox  groupb_textcontrols = new powersoft.powerj.ui.GroupBox();
    private  powersoft.powerj.ui.DataNavigator  dataNavigator_1 = new powersoft.powerj.ui.DataNavigator();
    private  powersoft.powerj.ui.DBTextField  textf_fname = new powersoft.powerj.ui.DBTextField();
    private  powersoft.powerj.ui.DBTextField  textf_address1 = new powersoft.powerj.ui.DBTextField();
    private  powersoft.powerj.ui.DBTextField  textf_empuserid = new powersoft.powerj.ui.DBTextField();
    private  powersoft.powerj.ui.DBTextField  textf_empcity = new powersoft.powerj.ui.DBTextField();
    private  powersoft.powerj.ui.DBTextField  textf_empstate = new powersoft.powerj.ui.DBTextField();
    private  powersoft.powerj.ui.DBTextField  textf_lname = new powersoft.powerj.ui.DBTextField();
    private  java.awt.Label  label_14 = new java.awt.Label();
    private  java.awt.Label  label_20 = new java.awt.Label();
    private  java.awt.Label  label_21 = new java.awt.Label();
    private  java.awt.Label  label_22 = new java.awt.Label();
    private  java.awt.Label  label_23 = new java.awt.Label();
    private  java.awt.Label  label_24 = new java.awt.Label();
    private  powersoft.powerj.ui.DBTextField  textf_empzipcode = new powersoft.powerj.ui.DBTextField();
    private  java.awt.Label  label_25 = new java.awt.Label();
    private  powersoft.powerj.ui.DBTextField  textf_empstartdate = new powersoft.powerj.ui.DBTextField();
    private  powersoft.powerj.ui.DBTextField  textf_emphomephone = new powersoft.powerj.ui.DBTextField();
    private  java.awt.Label  label_26 = new java.awt.Label();
    private  java.awt.Label  label_27 = new java.awt.Label();
    private  powersoft.powerj.ui.DBTextField  textf_empid = new powersoft.powerj.ui.DBTextField();
    private  powersoft.powerj.ui.DBTextField  textf_deptid = new powersoft.powerj.ui.DBTextField();
    private  java.awt.Label  label_28 = new java.awt.Label();
    private  java.awt.Label  label_29 = new java.awt.Label();
    private  powersoft.powerj.ui.DBTextField  textf_empssnum = new powersoft.powerj.ui.DBTextField();
    private  java.awt.Label  label_30 = new java.awt.Label();
    private  powersoft.powerj.ui.DBTextField  textf_empsalary = new powersoft.powerj.ui.DBTextField();
    private  java.awt.Label  label_31 = new java.awt.Label();
    private  powersoft.powerj.ui.DBTextField  textf_empbirthdate = new powersoft.powerj.ui.DBTextField();
    private  java.awt.Label  label_32 = new java.awt.Label();
    private  powersoft.powerj.ui.DBTextField  textf_empsex = new powersoft.powerj.ui.DBTextField();
    private  java.awt.Label  label_33 = new java.awt.Label();
    private  powersoft.powerj.ui.PictureButton  pictbttn_retrieveemp = new powersoft.powerj.ui.PictureButton();

    // add your data members here
    ImpactMotorsMainForm _parent;
    // add your data members here
    WebPBResultSetMetaData _wpbResultSetMetadata = null;          // result set metadata  
    WebPBResultSet _wpbResultSet = null;          // result set data  
    String _sIPAdress = new String("");           // parameters for DPBCall
    String _sURLBase =new String("");                    //      "
    String _sPBServer = new String("");              //      "
    String _sObject = new String("n_cst_java");                //      "
    String _sWebPBLoc = new String("");              // the location of the web.pb files
    String _sMethod = new String("");                //      "
    String _sArgs =new String("");                   //      "
    int _row=1, _column=1;
    powersoft.powerj.db.Query  query_1 = null;
    powersoft.powerj.db.Transaction  transaction_1 = null;
}




class ImpactMotorsMainForm_page_sqlrunner extends java.awt.Panel
{
    public Rectangle DURectangle( int x, int y, int w, int h )
    {
        String        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        FontMetrics   fm = getFontMetrics( getFont() );
        double        fw = ( fm != null ) ? ( fm.stringWidth( alphabet ) / alphabet.length() ) : 0;
        double        fh = ( fm != null ) ? ( fm.getHeight() / 2.0 ) : 0.0;

        return new Rectangle( (int) Math.round( ( (double)fw * (double)x ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)y ) / 4.0 ),
                              (int) Math.round( ( (double)fw * (double)w ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)h ) / 4.0 ) );
    }

    public void DUPositionComponent( java.awt.Component comp, int x, int y, int w, int h, java.awt.Insets formInsets )
    {
        Rectangle     rect = DURectangle( x, y, w, h );
        if( formInsets != null ) {
             rect.x += formInsets.left;
             rect.y += formInsets.top;
        }
        comp.reshape( rect.x, rect.y, rect.width, rect.height );
    }

    public void setMainForm( boolean isMainForm )
    {
        __mainForm = isMainForm;
    }
    public boolean isMainForm()
    {
        return __mainForm;
    }
    public boolean create() throws java.lang.Exception
    {
        setFont( new Font( "Dialog", Font.PLAIN, 12 ) );

        boolean retval = true;
        __parentForm = (ImpactMotorsMainForm)(getParent().getParent().getParent());
        if( getPeer() == null ) {
            addNotify();
        }
        show();
        Insets formInsets = insets();
        hide();
        setBackground( Color.lightGray );
        setForeground( Color.black );

        powersoft.powerj.ui.ResizePercentLayout layout = new powersoft.powerj.ui.ResizePercentLayout();
        setLayout( layout );
        groupb_1.setLayout( null );
        add(groupb_1);
        groupb_1.add(grid_resultset);
        groupb_2.setLayout( null );
        add(groupb_2);
        groupb_2.add(texta_1);
        add(cb_runsql);
        DUPositionComponent( this, 0, 0, 429, 210, null );

        DUPositionComponent( groupb_1, 16, 116, 308, 84, formInsets );
        groupb_1.setBackground( Color.lightGray );
        groupb_1.setForeground( Color.black );
        groupb_1.enable(true);
        groupb_1.show();

        groupb_1.setText("Result Set");

        DUPositionComponent( grid_resultset, 20, 0, 288, 68, null );
        grid_resultset.setNumColumns( 5 );
        grid_resultset.setNumRows( 10 );
        grid_resultset.setShowHorizontalHeader( true );
        grid_resultset.setShowVerticalHeader( false );
        grid_resultset.setShowColumnLines( true );
        grid_resultset.setShowRowLines( true );
        grid_resultset.setFullRowSelection( true );
        grid_resultset.setLiveEditMode( false );
        grid_resultset.setMultipleSelection( false );
        grid_resultset.setResizableColumns( false );
        grid_resultset.setResizableRows( false );
        grid_resultset.setReadOnly( true );
        grid_resultset.setBackground( powersoft.powerj.ui.grid.GridEnum.ALLCELLS, powersoft.powerj.ui.grid.GridEnum.ALLCELLS, Color.lightGray );
        grid_resultset.setForeground( Color.black );
        grid_resultset.enable(true);
        grid_resultset.show();

        grid_resultset.setHorizSBDisplay( powersoft.powerj.ui.grid.GridEnum.SBDISPLAY_AS_NEEDED );
        grid_resultset.setVertSBDisplay( powersoft.powerj.ui.grid.GridEnum.SBDISPLAY_AS_NEEDED );

        DUPositionComponent( groupb_2, 16, 24, 308, 88, formInsets );
        groupb_2.setBackground( Color.lightGray );
        groupb_2.setForeground( Color.black );
        groupb_2.enable(true);
        groupb_2.show();

        groupb_2.setText("SQL Statement");

        DUPositionComponent( texta_1, 8, 16, 292, 64, null );
        texta_1.setBackground( Color.white );
        texta_1.setForeground( Color.black );
        texta_1.enable(true);
        texta_1.show();

        texta_1.setText("select * from colors");

        DUPositionComponent( cb_runsql, 336, 28, 80, 24, formInsets );
        cb_runsql.setBackground( Color.lightGray );
        cb_runsql.setForeground( Color.black );
        cb_runsql.enable(true);
        cb_runsql.show();

        cb_runsql.setLabel("Run SQL");


        layout.setResizePercent(groupb_1,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(groupb_2,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(cb_runsql,new java.awt.Rectangle(0,0,0,0));

        return retval;
    }

    public synchronized boolean destroy()
    {
        if( (java.awt.Container)this instanceof java.awt.Window ) {
            ((java.awt.Window)(java.awt.Container)this).dispose();
        } else {
            removeNotify();
        }
        if( isMainForm() ) {
            System.gc();
            System.runFinalization();
            System.exit(0);
        }
        return true;
    }


    public boolean defaultHandleEvent(java.awt.Event event)
    {
        Object eventTarget = event.target;
        if( eventTarget == texta_1 && event.id == java.awt.Event.LOST_FOCUS ) {
            return texta_1_LostFocus(event);
        } else if( eventTarget == cb_runsql && event.id == java.awt.Event.ACTION_EVENT ) {
            return cb_runsql_Action(event);
        }
        return super.handleEvent(event);
    }
    public boolean handleEvent(java.awt.Event event)
    {

        return defaultHandleEvent(event);
    }
    public void unhandledEvent( String listenerName, String methodName, java.lang.Object event )
    {

    }
    public void setParent(ImpactMotorsMainForm parent)
    {
    _parent = parent;    
    }
    public boolean texta_1_LostFocus(java.awt.Event event)
    {
        if( !texta_1.getText().equals(""))
        cb_runsql.enable( true );

        return false;
    }
    public boolean cb_runsql_Action(java.awt.Event event)
    {
     int rCnt=0, cCnt=0;
     int result;
     boolean lastresult=false;
     String resultSet = "";
     String temp="";
     String label="";
     int width=0;

_parent.clearStatusText();

    if (query_1 == null)
        query_1 = _parent.getQuery2();

        _parent.set_sPBServer("niexdpbs");
        _parent.set_sDPBObject("n_cst_java");
        _parent.set_sDPBMethod("of_executesql");
        _parent.set_sDPBArgs(texta_1.getText().trim());

_parent.openMsgWindow("Executing SQL Statement");

       _parent._PBObject.setResultSetConsumer( query_1 );

       result = _parent._PBObject.retrieve(_parent.get_sURLBase(), _parent.get_sPBServer(), _parent.get_sDPBObject(), _parent.get_sDPBMethod(), _parent.get_sDPBArgs() );


         if ( result > 0 ) 
            {
//                lastresult = query_1.moveFirst( true, true );
                _wpbResultSet = (WebPBResultSet)_parent._PBObject.getResultSetObject( );
                try {lastresult = _wpbResultSet.next();}
                catch ( jdbc.sql.SQLException e){}
                rCnt = result;
            }
          else if (result < 0)
                {
                    System.out.println(_parent._PBObject.getErrorMsg());
                    _parent.setStatusText("Error Executing SQL: "+_parent._PBObject.getErrorMsg());
                }



       if ( lastresult )
             {
                try {_wpbResultSetMetadata = (WebPBResultSetMetaData) _wpbResultSet.getMetaData();} 
                catch ( jdbc.sql.SQLException e){}

                try {cCnt = _wpbResultSetMetadata.getColumnCount( );}
                catch ( jdbc.sql.SQLException e){}
                // cCnt = query_1.getColumnCount( );

                 grid_resultset.setNumColumns( cCnt );
                 grid_resultset.setNumRows( rCnt );

                // set grid column labels
                for (int cnt=0; cnt < cCnt;cnt++)
                    {
                     try{ label = _wpbResultSetMetadata.getColumnLabel(cnt+1);} 
                     catch ( jdbc.sql.SQLException e){}
                     try { width = _wpbResultSetMetadata.getColumnDisplaySize(cnt+1);}
                     catch ( jdbc.sql.SQLException e){}
                     grid_resultset.setCharWidth(cnt, width);
                     grid_resultset.setColumnLabel(cnt, label);
                    }

                 //rows
                 for(int i=0; i<rCnt; i++)
                 {
                     //columns
                     for (int j=0; j<cCnt; j++)
                     {
                         try {temp = _wpbResultSet.getString(j+1);}
                         catch ( jdbc.sql.SQLException e){}
                         //temp = query_1.getStringValue(j+1);

                         grid_resultset.setCell( i, j, temp );
                     }
                     try { _wpbResultSet.next();} catch ( jdbc.sql.SQLException e){}
//                    query_1.moveNext(true, true); 
                 }
             }

               else
               {
                grid_resultset.setNumColumns( 1 );
                grid_resultset.setNumRows( 1 );
                resultSet = _parent._PBObject.getErrorMsg();
                grid_resultset.setCell( 0, 0,resultSet );
               }            
_parent.closeMsgWindow();

        return false;
    }
    /****************************************
     * data members
     ****************************************/

    boolean __mainForm = false;

    public ImpactMotorsMainForm __parentForm = null;
    public  powersoft.powerj.ui.GroupBox  groupb_1 = new powersoft.powerj.ui.GroupBox();
    public  powersoft.powerj.ui.grid.Grid  grid_resultset = new powersoft.powerj.ui.grid.Grid();
    public  powersoft.powerj.ui.GroupBox  groupb_2 = new powersoft.powerj.ui.GroupBox();
    public  java.awt.TextArea  texta_1 = new java.awt.TextArea();
    public  java.awt.Button  cb_runsql = new java.awt.Button();

    // add your data members here
    final static String[] column_labels = {
        "Vehicle ID", "Class ID", "Exterior", "Interior", "Price","Quantity"};
    final static int[] alignments = {
        BWTEnum.LEFT, BWTEnum.RIGHT, BWTEnum.RIGHT, BWTEnum.RIGHT,BWTEnum.RIGHT,BWTEnum.RIGHT};
    ImpactMotorsMainForm _parent;
    // add your data members here
    WebPBResultSetMetaData _wpbResultSetMetadata = null;          // result set metadata  
    WebPBResultSet _wpbResultSet = null;          // result set data  
    String _sIPAdress = new String("");           // parameters for DPBCall
    String _sURLBase =new String("");                    //      "
    String _sPBServer = new String("");              //      "
    String _sObject = new String("n_cst_java");                //      "
    String _sWebPBLoc = new String("");              // the location of the web.pb files
    String _sMethod = new String("");                //      "
    String _sArgs =new String("");                   //      "
    int _row=1, _column=1;
    powersoft.powerj.db.jdbc_sql.Query  query_1 = null;
}



class ImpactMotorsMainForm extends java.applet.Applet
{
    public Rectangle DURectangle( int x, int y, int w, int h )
    {
        String        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        FontMetrics   fm = getFontMetrics( getFont() );
        double        fw = ( fm != null ) ? ( fm.stringWidth( alphabet ) / alphabet.length() ) : 0;
        double        fh = ( fm != null ) ? ( fm.getHeight() / 2.0 ) : 0.0;

        return new Rectangle( (int) Math.round( ( (double)fw * (double)x ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)y ) / 4.0 ),
                              (int) Math.round( ( (double)fw * (double)w ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)h ) / 4.0 ) );
    }

    public void DUPositionComponent( java.awt.Component comp, int x, int y, int w, int h, java.awt.Insets formInsets )
    {
        Rectangle     rect = DURectangle( x, y, w, h );
        if( formInsets != null ) {
             rect.x += formInsets.left;
             rect.y += formInsets.top;
        }
        comp.reshape( rect.x, rect.y, rect.width, rect.height );
    }

    public void setMainForm( boolean isMainForm )
    {
        __mainForm = isMainForm;
    }
    public boolean isMainForm()
    {
        return __mainForm;
    }
    public boolean create() throws java.lang.Exception
    {
        setFont( new Font( "Dialog", Font.PLAIN, 12 ) );

        boolean retval = true;
        if( getPeer() == null ) {
            addNotify();
        }
        show();
        Insets formInsets = insets();
        hide();
        setBackground( Color.lightGray );
        setForeground( Color.black );

        powersoft.powerj.ui.ResizePercentLayout layout = new powersoft.powerj.ui.ResizePercentLayout();
        setLayout( layout );
        add(tabctrl_1);
        add(mlabel_Status);
        DUPositionComponent( this, 0, 0, 438, 269, null );

        transaction_1 = powersoft.powerj.db.Transaction.createFromDriver( "sun.jdbc.odbc.JdbcOdbcDriver", "ImpactMotorsMainForm.transaction_1", true );
        transaction_1.setDataSource("jdbc:odbc:nidemodb2");
        transaction_1.setUserID("dba");
        transaction_1.setPassword("sql");
        transaction_1.setAutoCommit(true);
        transaction_1.setLoginTimeout( 0 );
        query_1 = powersoft.powerj.db.Transaction.createQueryByName("ImpactMotorsMainForm.transaction_1", "ImpactMotorsMainForm.query_1",  true );
        query_2.setTraceToLog( true );
        query_2.setName( "ImpactMotorsMainForm.query_2" );
        query_2.setTransactionObject( powersoft.powerj.db.Transaction.findByName(null, false ) );

        DUPositionComponent( tabctrl_1, 4, 32, 430, 223, formInsets );
        tabctrl_1.setBackground( Color.lightGray );
        tabctrl_1.setForeground( Color.black );
        tabctrl_1.enable(true);
        tabctrl_1.show();

        tabctrl_1.setBackground( Color.lightGray );
        tabctrl_1.setForeground( Color.black );
        tabctrl_1.add( 0, "Customer Information", null );
        tabctrl_1.setPanel( 0, _ImpactMotorsMainForm_page_customer );
        _ImpactMotorsMainForm_page_customer.create();
        tabctrl_1.add( 1, "Vehicle Information", null );
        tabctrl_1.setPanel( 1, _ImpactMotorsMainForm_page_vehicleinfo );
        _ImpactMotorsMainForm_page_vehicleinfo.create();
        tabctrl_1.add( 2, "Vehicle Options", null );
        tabctrl_1.setPanel( 2, _ImpactMotorsMainForm_page_options );
        _ImpactMotorsMainForm_page_options.create();
        tabctrl_1.add( 3, "SQL Runner", null );
        tabctrl_1.setPanel( 3, _ImpactMotorsMainForm_page_sqlrunner );
        _ImpactMotorsMainForm_page_sqlrunner.create();
        tabctrl_1.add( 4, "Bound Controls", null );
        tabctrl_1.setPanel( 4, _ImpactMotorsMainForm_page_bound );
        _ImpactMotorsMainForm_page_bound.create();

        tabctrl_1.setSelected(0);




        DUPositionComponent( mlabel_Status, 8, 4, 432, 24, formInsets );
        mlabel_Status.setAlignment(powersoft.powerj.ui.MultiLineLabel.LEFT);
        mlabel_Status.setFont( new Font( "Dialog", Font.PLAIN, 10 ) );
        mlabel_Status.setBackground( Color.lightGray );
        mlabel_Status.setForeground( Color.red );
        mlabel_Status.enable(true);
        mlabel_Status.show();

        mlabel_Status.setInsets( new java.awt.Insets(0,0,0,0) );

        layout.setResizePercent(tabctrl_1,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(mlabel_Status,new java.awt.Rectangle(0,0,0,0));
        if( !transaction_1.connect() ){
            transaction_1.log("autoconnect failed");
        }
        query_1.setAutoEdit(true);
        query_1.setAllowUpdates(true);
        query_1.setUpdateConnectionMode( powersoft.powerj.db.Query.NO_AUTOCONNECT );
        query_1.setUpdateMode( powersoft.powerj.db.Query.IMMEDIATE_UPDATES );
        query_1.setUpdateType( powersoft.powerj.db.Query.KEYS_ONLY );
        query_1.setKeyUpdate( powersoft.powerj.db.Query.USE_UPDATE );
        query_1.setBindUpdates(true);
        query_1.setQueryTimeout( 0 );
        query_2.setAutoEdit(true);
        query_2.setAllowUpdates(true);
        query_2.setUpdateConnectionMode( powersoft.powerj.db.Query.NO_AUTOCONNECT );
        query_2.setUpdateMode( powersoft.powerj.db.Query.IMMEDIATE_UPDATES );
        query_2.setUpdateType( powersoft.powerj.db.Query.KEYS_ONLY );
        query_2.setKeyUpdate( powersoft.powerj.db.Query.USE_UPDATE );
        query_2.setBindUpdates(true);
        query_2.setQueryTimeout( 0 );
        query_1.setSQL("SELECT  * FROM DBA.colors colors ");
        query_2.setSQL("");
        if( query_1.open() ){
            query_1.moveNext( true, true );
        }
        if( query_2.open() ){
            query_2.moveNext( true, true );
        }

        show();
        ImpactMotorsMainForm_objectCreated( new powersoft.powerj.event.EventData( this ) );
        return retval;
    }

    public synchronized void destroy()
    {
        query_1.destroy();
        query_2.destroy();
        transaction_1.destroy();
        if( (java.awt.Container)this instanceof java.awt.Window ) {
            ((java.awt.Window)(java.awt.Container)this).dispose();
        } else {
            removeNotify();
        }
        if( isMainForm() ) {
            System.gc();
            System.runFinalization();
            System.exit(0);
        }
    }


    public boolean defaultHandleEvent(java.awt.Event event)
    {
        return super.handleEvent(event);
    }
    public ImpactMotorsMainForm()
    {
        super();
    }
    public boolean handleEvent(java.awt.Event event)
    {

        return defaultHandleEvent(event);
    }
    public void unhandledEvent( String listenerName, String methodName, java.lang.Object event )
    {

    }
    public powersoft.powerj.db.Query getQuery1()
    {
        return query_1;

    }
public java.awt.Frame getFrame(Component component) 
{
        Component c = component;

        if(c instanceof Frame)
            return (Frame)c;

        while((c = c.getParent()) != null) {
            if(c instanceof Frame)
                return (Frame)c;
        }
        return null;

    }
    public void setNoOrder()
    {
        _ImpactMotorsMainForm_page_customer.resetOrderInfo();
        _ImpactMotorsMainForm_page_customer.groupb_orderinfo.hide();
        _ImpactMotorsMainForm_page_vehicleinfo.resetInfo();
        _ImpactMotorsMainForm_page_options.resetOptionsInfo();
        _ImpactMotorsMainForm_page_customer.siColor = "";
        _ImpactMotorsMainForm_page_customer.sxColor = "";
        _ImpactMotorsMainForm_page_vehicleinfo.disable();
        _ImpactMotorsMainForm_page_options.disable();

    }
    public void loadOrderInfo()
    {

    }
    public void openMsgWindow(String msg)
    {
// progress window

   cd = new ProgressWindow(getFrame(this), msg, this);
    try { cd.create();} catch (java.lang.Exception e){}

    }
    public void closeMsgWindow()
    {
        cd.destroy();

    }
    public Vector getModelOptions()
    {
    boolean result=false;    
    Vector list = new Vector();
	OptionsData od= new OptionsData();
    String sql="";

    sql =  " SELECT optional_equipment.option_description, "+   
           " optional_equipment.option_price, optional_equipment.option_id "+  
           " FROM model_options, optional_equipment "+  
           " WHERE ( optional_equipment.option_id = model_options.option_id ) and "+  
           "( ( model_options.model_class_id = "+ 
            getModelClassID() + 
           " ) AND ( model_options.standard = 0 ) )";    

openMsgWindow("Retrieving Vehicle Options Data...");


        query_1.close();
        query_1.setSQL(sql);
        result = query_1.open();

        if (result)
        {
            result = query_1.moveFirst(false,false);

        while (result)
           {
            od.setDesc(query_1.getValue(1).toString().trim());
            od.setPrice(query_1.getValue(2).toString().trim());
            od.setId(query_1.getValue(3).toString().trim());

            list.addElement(new OptionsData(formatCurrency(od.getPrice()), od.getDesc(), od.getId()));
            result = query_1.moveNext(false, false);
            }
        }
        else
            setStatusText("Error Retrievinb Order Options");

  closeMsgWindow(); 
	return list;        


    }
    public String formatCurrency(String org)
    {
       StringBuffer sTemp=null;
        int decimalPos=0;
        int len=0;

    // check arguments
        if(org == null)
            return "";

        if(org.equals(""))
            return "";

     // set length of string
        len = org.length();

    // set temp string buffer
       sTemp = new StringBuffer(org);

    // check for 2 digits to right of decimal
       if(org.indexOf(".") >0){
            if(len > (org.indexOf(".") + 2)){
                sTemp.setLength(len - 2);
              }
        }
    // check for decimal place
        if (!(org.indexOf(".") >0)){
            sTemp.append(".00");
        }

    // reset the original string
    org = sTemp.toString();

    // add ","
       if(org.length() > 6){
           sTemp.insert(org.indexOf(".")-3, ',');
            }
    // insert dollar sign
    sTemp.insert(0, '$');

    // return formatted string
    return sTemp.toString();

    }
    public float unformatCurrency(String s)
    {
        String sTemp="";
        Float f ;

        if (s.indexOf(",") > 0)
            sTemp = s.substring(0, s.indexOf(",")) + s.substring(s.indexOf(",")+1);
        else
            sTemp = s;

        sTemp.trim();

        f = new Float(sTemp);
        return f.floatValue();
    }
    public void setOrderEnable()
    {
        _ImpactMotorsMainForm_page_vehicleinfo.enable();
        _ImpactMotorsMainForm_page_options.enable();

    }
    public void addOptionsToOrder(Vector vod)
    {
         java.awt.Frame tmpFrame;
         addedOptions = vod;
         tmpFrame  = getFrame(this);

        tmpFrame  = getFrame(this);
        ModifiedDlg md = new ModifiedDlg(tmpFrame,this,"Options for your order have Changed. Would you like to save the changes?","options");
        try { md.create();} catch (java.lang.Exception e){}


    }
    public void checkSelectedColors(Color extColor, Color intColor)
    {
        java.awt.Frame tmpFrame;
    // check if changed
    if( (!(_ImpactMotorsMainForm_page_vehicleinfo._exteriorCanvas.getBackground().equals(extColor)))|| 
        (!(_ImpactMotorsMainForm_page_vehicleinfo._interiorCanvas.getBackground().equals(intColor))))
        {

        newExtColor = extColor;
        newIntColor = intColor;
        tmpFrame = getFrame(this);
        // open modified dilaog

        ModifiedDlg md = new ModifiedDlg(tmpFrame,this,"Colors for your order have Changed. Would you like to save the changes?","colors");
        try { md.create();} catch (java.lang.Exception e){}

        }
    }
    public void saveChangedColors()
    {
    String updateSQL="";    
    String xColor,iColor;
    int ixColor, iiColor;
    boolean result=false;


    ixColor = newExtColor.getRGB();
    iiColor = newIntColor.getRGB();

    xColor = Integer.toString(ixColor & 0xffffff,16);
    iColor = Integer.toString(iiColor & 0xffffff,16);

    xColor = _ImpactMotorsMainForm_page_vehicleinfo._colorData.getColorName(xColor);
    iColor = _ImpactMotorsMainForm_page_vehicleinfo._colorData.getColorName(iColor);

    _ImpactMotorsMainForm_page_vehicleinfo.setNewColors(newExtColor, newIntColor);

    // save changes to database
     updateSQL =  "UPDATE orders SET exterior_color = "+'\''+xColor+'\''+", interior_color = "+'\''+iColor+
        '\''+" WHERE orders.order_id = "+ getSOrderID();

     query_1.close();
     query_1.setSQL(updateSQL);
     result = query_1.open();
    }
    public void saveAddedOptions()
    {
        boolean result=false;
        String updateSQL="";
        String optionID="";
        String orderID="";
        int count=0;
        OptionsData od = new OptionsData();

       count = addedOptions.size();

       if (count >0)
        {
            orderID = getSOrderID();

        for (Enumeration e = addedOptions.elements() ; e.hasMoreElements() ;) {
              od = (OptionsData)e.nextElement();
              optionID = od.getId();   
              updateSQL = "INSERT INTO order_options ( order_id, option_id ) VALUES ("+orderID+","+optionID+" )";     
              query_1.close();
              query_1.setSQL(updateSQL);
              result = query_1.open();
            }   

         }
    _ImpactMotorsMainForm_page_options.setAddedOptions(addedOptions);
    }
    public Image getPicture(String file)
    {
    /*java.net.URL url=null;

    try { url = new java.net.URL(_url+"images/"); }

    catch (MalformedURLException e){}
    */
    return getToolkit().getImage(file);    
    }
    public String getURLString()
    {
    return _url;    
    }
    public boolean getOrderInfo(String orderid)
    {
    int result=0;

openMsgWindow("Retrieving Order Information...");

        set_sPBServer("niexdpbs");
        set_sDPBObject("n_cst_java");
        set_sDPBMethod("of_getorderinfo");
        set_sDPBArgs(orderid);


       _PBObject.setResultSetConsumer( query_1 );

       result = _PBObject.retrieve(_sURLBase, _sDPBServer, _sDPBObject, _sDPBMethod, _sDPBArgs );

         if ( result > 0 ) 
            {
                query_1.moveNext( true, true );
                closeMsgWindow(); 
                return true;
            }
          else {
                    setStatusText("Error Retrieving order data: "+_PBObject.getErrorMsg());
                    closeMsgWindow();
               		System.out.println(_PBObject.getErrorMsg());
                    return false;
               }

    }
    public void setOrderDisable()
    {
        _ImpactMotorsMainForm_page_vehicleinfo.disable();
        _ImpactMotorsMainForm_page_options.disable();

    }
    public void setQuery(powersoft.powerj.db.jdbc_sql.Query q)
    {
        query_2 = q ;

    }
    public powersoft.powerj.db.Transaction getTrans()
    {
    return transaction_1;    
    }
    public powersoft.powerj.db.jdbc_sql.Query getQuery2()
    {
        return query_2;    
    }
    public void setStatusText(String text)
    {

        mlabel_Status.setText( text );
        mlabel_Status.show(true);
    }
    public void clearStatusText()
    {    
        mlabel_Status.setText("");
        mlabel_Status.show(false);
    }
    //
    // HostName Property
    //

    public String getHostName()
    {
        return sHostName;
    }

    public void setHostName( String newValue )
    {
        sHostName = newValue;
    }
    //
    // ModelClassID Property
    //

    public String getModelClassID()
    {
        return sModelClassID;
    }

    public void setModelClassID( String newValue )
    {
        sModelClassID = newValue;
    }
    //
    // _sDPBArgs Property
    //

    public String get_sDPBArgs()
    {
        return _sDPBArgs;
    }

    public void set_sDPBArgs( String newValue )
    {
        _sDPBArgs = newValue;
    }
    //
    // _sDPBMethod Property
    //

    public String get_sDPBMethod()
    {
       return _sDPBMethod;
    }

    public void set_sDPBMethod( String newValue )
    {
        _sDPBMethod = newValue;
    }
    //
    // _sDPBObject Property
    //

    public String get_sDPBObject()
    {
        return _sDPBObject;
    }

    public void set_sDPBObject( String newValue )
    {
        _sDPBObject = newValue;
    }
    //
    // _sIPAdress Property
    //

    public String get_sIPAdress()
    {
        return _sIPAdress;
    }

    public void set_sIPAdress( String newValue )
    {
        _sIPAdress = newValue;
    }
    //
    // _sPBServer Property
    //

    public String get_sPBServer()
    {
        return _sDPBServer;
    }

    public void set_sPBServer( String newValue )
    {
        _sDPBServer = newValue;
    }
    //
    // _sURLBase Property
    //

    public String get_sURLBase()
    {
        return _sURLBase;
    }

    public void set_sURLBase( String newValue )
    {
        _sURLBase = newValue;
    }
    //
    // _sWebPBLoc Property
    //

    public String get_sWebPBLoc()
    {
        return _sWebPBLoc;
    }

    public void set_sWebPBLoc( String newValue )
    {
        _sWebPBLoc = newValue;
    }
    //
    // sOrderID Property
    //

    public String getSOrderID()
    {
        return sOrderID;
    }

    public void setSOrderID( String newValue )
    {
        sOrderID = newValue;
    }
    public boolean ImpactMotorsMainForm_objectCreated(powersoft.powerj.event.EventData event)
    {    
        _ImpactMotorsMainForm_page_customer.setParent(this);
        _ImpactMotorsMainForm_page_vehicleinfo.setParent(this);
        _ImpactMotorsMainForm_page_options.setParent(this);
        _ImpactMotorsMainForm_page_sqlrunner.setParent(this);
        _ImpactMotorsMainForm_page_bound.setParent(this);

        _ImpactMotorsMainForm_page_customer.textf_2.requestFocus();

        return false;
    }
    /****************************************
     * data members
     ****************************************/

    boolean __mainForm = false;

    public  powersoft.powerj.db.Query  query_1 = null;
    public  ImpactMotorsMainForm_page_customer  _ImpactMotorsMainForm_page_customer = new ImpactMotorsMainForm_page_customer();
    public  ImpactMotorsMainForm_page_customer page_customer = _ImpactMotorsMainForm_page_customer;
    public  ImpactMotorsMainForm_page_vehicleinfo  _ImpactMotorsMainForm_page_vehicleinfo = new ImpactMotorsMainForm_page_vehicleinfo();
    public  ImpactMotorsMainForm_page_vehicleinfo page_vehicleinfo = _ImpactMotorsMainForm_page_vehicleinfo;
    public  ImpactMotorsMainForm_page_options  _ImpactMotorsMainForm_page_options = new ImpactMotorsMainForm_page_options();
    public  ImpactMotorsMainForm_page_options page_options = _ImpactMotorsMainForm_page_options;
    public  ImpactMotorsMainForm_page_sqlrunner  _ImpactMotorsMainForm_page_sqlrunner = new ImpactMotorsMainForm_page_sqlrunner();
    public  ImpactMotorsMainForm_page_sqlrunner page_sqlrunner = _ImpactMotorsMainForm_page_sqlrunner;
    public  ImpactMotorsMainForm_page_bound  _ImpactMotorsMainForm_page_bound = new ImpactMotorsMainForm_page_bound();
    public  ImpactMotorsMainForm_page_bound page_bound = _ImpactMotorsMainForm_page_bound;
    public  powersoft.powerj.ui.TabControl  tabctrl_1 = new powersoft.powerj.ui.TabControl();
    public  powersoft.powerj.db.Transaction  transaction_1 = null;
    public  powersoft.powerj.db.jdbc_sql.Query  query_2 = new powersoft.powerj.db.jdbc_sql.Query();
    public  powersoft.powerj.ui.MultiLineLabel  mlabel_Status = new powersoft.powerj.ui.MultiLineLabel();

    // add your data members here
    ProgressWindow cd=null;
    String sOrderID;
    String sModelClassID;
    Vector addedOptions = new Vector();
    Color newExtColor = null;
    Color newIntColor = null;
    String _url="http://199.95.50.33/impactmotors/";
    String sHostName;
    private ResultSet _orderResultSet = null;
    powersoft.powerj.webpb.jdbc_sql.WebPBCall _PBObject = new powersoft.powerj.webpb.jdbc_sql.WebPBCall();
    private powersoft.powerj.webpb.jdbc_sql.WebPBResultSet _wpbResultSet = null;          		// result set data  
    private String _sIPAdress = new String("199.95.50.33"); // parameters for DPBCall
    private String _sWebPBLoc = new String("/scripts/Pbcgi60.exe/"); // the location of the web.pb files
    private String _sURLBase = "http://" + _sIPAdress + _sWebPBLoc;     	//      "
    private String _sDPBServer = new String("niexdpbs");        //      "
    private String _sDPBObject = new String("n_cst_java");  //      "
    private String _sDPBMethod = new String("of_getorderinfo");          //      "
    private String _sDPBArgs = new String("");             //      "
}

