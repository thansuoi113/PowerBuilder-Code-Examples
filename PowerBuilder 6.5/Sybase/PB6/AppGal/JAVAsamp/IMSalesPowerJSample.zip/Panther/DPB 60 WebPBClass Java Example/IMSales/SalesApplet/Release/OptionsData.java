/*
    OptionsData.java

    NOTE: This file is a generated file.
          Do not modify it by hand!
*/
// add your custom import statements here
/**
*   class used to store options information
*
*
*/

class OptionsData extends Object
{
    OptionsData(){}
    OptionsData(String p, String d, String i){
        price=p;
        description=d;
        id=i;
    }
    void setDesc(String desc){
        description = desc;
    }
    void setId(String i){
        id =i;
    }
    void setPrice(String p){
        price=p;
    }
    String getDesc(){
        return description;
    }
    String getId(){
        return id;
    }
    String getPrice(){
        return price;
    }
    void reset(){
        description ="";
        id="";
        price="";
    }
    OptionsData(OptionsData od)
    {
        price=od.getPrice();
        description=od.getDesc();
        id=od.getId();

    }
    // add your data members here
    // variables
    String description;
    String id;
    String price;
}

