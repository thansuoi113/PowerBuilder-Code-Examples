/*
    MessageDlg.java

    NOTE: This file is a generated file.
          Do not modify it by hand!
*/
import java.awt.Color;
import java.awt.Event;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Rectangle;
import java.awt.Insets;
import java.lang.Math;
import java.lang.String;

// custom imports for MessageDlg
// add your custom import statements here


class MessageDlg extends java.awt.Dialog
{
    public Rectangle DURectangle( int x, int y, int w, int h )
    {
        String        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        FontMetrics   fm = getFontMetrics( getFont() );
        double        fw = ( fm != null ) ? ( fm.stringWidth( alphabet ) / alphabet.length() ) : 0;
        double        fh = ( fm != null ) ? ( fm.getHeight() / 2.0 ) : 0.0;

        return new Rectangle( (int) Math.round( ( (double)fw * (double)x ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)y ) / 4.0 ),
                              (int) Math.round( ( (double)fw * (double)w ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)h ) / 4.0 ) );
    }

    public void DUPositionComponent( java.awt.Component comp, int x, int y, int w, int h, java.awt.Insets formInsets )
    {
        Rectangle     rect = DURectangle( x, y, w, h );
        if( formInsets != null ) {
             rect.x += formInsets.left;
             rect.y += formInsets.top;
        }
        comp.reshape( rect.x, rect.y, rect.width, rect.height );
    }

    public void setMainForm( boolean isMainForm )
    {
        __mainForm = isMainForm;
    }
    public boolean isMainForm()
    {
        return __mainForm;
    }
    public boolean create() throws java.lang.Exception
    {
        setTitle("Message Dialog");

        setResizable(true);

        setFont( new Font( "Dialog", Font.PLAIN, 12 ) );

        boolean retval = true;
        if( getPeer() == null ) {
            addNotify();
        }
        Insets formInsets = insets();
        setBackground( new Color( 187, 204, 213 ) );
        setForeground( Color.black );

        powersoft.powerj.ui.ResizePercentLayout layout = new powersoft.powerj.ui.ResizePercentLayout();
        setLayout( layout );
        add(mlabel_1);
        add(cb_1);
        DUPositionComponent( this, 66, 82, 256, 68, null );

        DUPositionComponent( mlabel_1, 10, 15, 185, 25, formInsets );
        mlabel_1.setAlignment(powersoft.powerj.ui.MultiLineLabel.LEFT);
        mlabel_1.setBackground( new Color( 187, 204, 213 ) );
        mlabel_1.setForeground( Color.black );
        mlabel_1.enable(true);
        mlabel_1.show();

        mlabel_1.setInsets( new java.awt.Insets(0,0,0,0) );

        DUPositionComponent( cb_1, 205, 21, 40, 14, formInsets );
        cb_1.setBackground( Color.lightGray );
        cb_1.setForeground( Color.black );
        cb_1.enable(true);
        cb_1.show();

        cb_1.setLabel("OK");


        layout.setResizePercent(mlabel_1,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(cb_1,new java.awt.Rectangle(0,0,0,0));

        show();
        return retval;
    }

    public synchronized boolean destroy()
    {
        if( (java.awt.Container)this instanceof java.awt.Window ) {
            ((java.awt.Window)(java.awt.Container)this).dispose();
        } else {
            removeNotify();
        }
        if( isMainForm() ) {
            System.gc();
            System.runFinalization();
            System.exit(0);
        }
        return true;
    }


    public boolean defaultHandleEvent(java.awt.Event event)
    {
        Object eventTarget = event.target;
        if( eventTarget == this && event.id == java.awt.Event.WINDOW_DESTROY ) {
            return MessageDlg_WindowDestroy(event);
        } else if( eventTarget == cb_1 && event.id == java.awt.Event.ACTION_EVENT ) {
            return cb_1_Action(event);
        }
        return super.handleEvent(event);
    }
    public MessageDlg(java.awt.Frame parent)
    {
        super(parent,true);
    }
    public boolean handleEvent(java.awt.Event event)
    {

        return defaultHandleEvent(event);
    }
    public void unhandledEvent( String listenerName, String methodName, java.lang.Object event )
    {

    }
    public void setMessageText()
    {
        mlabel_1.setText( "c" );

    }
    public void setMessageText(String msg)
    {
        mlabel_1.setText( msg );

    }
    public boolean MessageDlg_WindowDestroy(java.awt.Event event)
    {

        hide();
        destroy();
        return false;
    }
    public boolean cb_1_Action(java.awt.Event event)
    {

        hide();
        destroy();
        return false;
    }
    /****************************************
     * data members
     ****************************************/

    boolean __mainForm = false;

    private  powersoft.powerj.ui.MultiLineLabel  mlabel_1 = new powersoft.powerj.ui.MultiLineLabel();
    private  java.awt.Button  cb_1 = new java.awt.Button();

    // add your data members here
}

