/*
    ProgressWindow.java

    NOTE: This file is a generated file.
          Do not modify it by hand!
*/
import java.awt.Color;
import java.awt.Event;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Rectangle;
import java.awt.Insets;
import java.lang.Math;
import java.lang.String;

// custom imports for ProgressWindow
// add your custom import statements here


class ProgressWindow extends java.awt.Dialog
{
    public Rectangle DURectangle( int x, int y, int w, int h )
    {
        String        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        FontMetrics   fm = getFontMetrics( getFont() );
        double        fw = ( fm != null ) ? ( fm.stringWidth( alphabet ) / alphabet.length() ) : 0;
        double        fh = ( fm != null ) ? ( fm.getHeight() / 2.0 ) : 0.0;

        return new Rectangle( (int) Math.round( ( (double)fw * (double)x ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)y ) / 4.0 ),
                              (int) Math.round( ( (double)fw * (double)w ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)h ) / 4.0 ) );
    }

    public void DUPositionComponent( java.awt.Component comp, int x, int y, int w, int h, java.awt.Insets formInsets )
    {
        Rectangle     rect = DURectangle( x, y, w, h );
        if( formInsets != null ) {
             rect.x += formInsets.left;
             rect.y += formInsets.top;
        }
        comp.reshape( rect.x, rect.y, rect.width, rect.height );
    }

    public void setMainForm( boolean isMainForm )
    {
        __mainForm = isMainForm;
    }
    public boolean isMainForm()
    {
        return __mainForm;
    }
    public boolean create() throws java.lang.Exception
    {
        setResizable(false);

        setFont( new Font( "Dialog", Font.PLAIN, 12 ) );

        boolean retval = true;
        if( getPeer() == null ) {
            addNotify();
        }
        Insets formInsets = insets();
        setBackground( Color.lightGray );
        setForeground( Color.black );

        powersoft.powerj.ui.ResizePercentLayout layout = new powersoft.powerj.ui.ResizePercentLayout();
        setLayout( layout );
        add(pictb_1);
        add(label_msgtext);
        DUPositionComponent( this, 114, 129, 232, 56, null );

        DUPositionComponent( pictb_1, 1, 5, 40, 30, formInsets );
        pictb_1.setBackground( Color.lightGray );
        pictb_1.setForeground( Color.black );
        pictb_1.enable(true);
        pictb_1.show();

        Rectangle pictb_1_size_rect = DURectangle( 0, 0, 40, 30);
        pictb_1.resize(pictb_1_size_rect.width,pictb_1_size_rect.height);
        pictb_1.setImagePosition( powersoft.powerj.ui.PictureBox.CENTER );
        pictb_1.setInsets( new java.awt.Insets(0,0,0,0) );
        pictb_1.setAutoSize( true );
        pictb_1.setScaleImage( true );

        DUPositionComponent( label_msgtext, 39, 10, 186, 20, formInsets );
        label_msgtext.setAlignment(java.awt.Label.CENTER);
        label_msgtext.setText( "" );
        label_msgtext.setFont( new Font( "Dialog", Font.BOLD, 12 ) );
        label_msgtext.setBackground( Color.lightGray );
        label_msgtext.setForeground( Color.black );
        label_msgtext.enable(true);
        label_msgtext.show();


        layout.setResizePercent(pictb_1,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(label_msgtext,new java.awt.Rectangle(0,0,0,0));

        ProgressWindow_objectCreated( new powersoft.powerj.event.EventData( this ) );
        show();
        return retval;
    }

    public synchronized boolean destroy()
    {
        if( (java.awt.Container)this instanceof java.awt.Window ) {
            ((java.awt.Window)(java.awt.Container)this).dispose();
        } else {
            removeNotify();
        }
        if( isMainForm() ) {
            System.gc();
            System.runFinalization();
            System.exit(0);
        }
        return true;
    }


    public boolean defaultHandleEvent(java.awt.Event event)
    {
        Object eventTarget = event.target;
        if( eventTarget == this && event.id == java.awt.Event.WINDOW_DESTROY ) {
            return ProgressWindow_WindowDestroy(event);
        }
        return super.handleEvent(event);
    }
    public ProgressWindow(java.awt.Frame parent, String text, ImpactMotorsMainForm caller)
    {
        super(parent,true);
        _text = text;
        _parent = caller;

    }
    public boolean handleEvent(java.awt.Event event)
    {

        return defaultHandleEvent(event);
    }
    public void unhandledEvent( String listenerName, String methodName, java.lang.Object event )
    {

    }
    public void setLabelText(String text)
    {
       label_msgtext.setText( text );

    }
    public boolean ProgressWindow_WindowDestroy(java.awt.Event event)
    {
        _parent.requestFocus();
        hide();
        destroy();
        return false;
    }
    public boolean ProgressWindow_objectCreated(powersoft.powerj.event.EventData event)
    {
        pictb_1.setImage("hourglass.jpg");    
        setLabelText(_text);

        return false;
    }
    /****************************************
     * data members
     ****************************************/

    boolean __mainForm = false;

    private  powersoft.powerj.ui.PictureBox  pictb_1 = new powersoft.powerj.ui.PictureBox();
    private  java.awt.Label  label_msgtext = new java.awt.Label();

    // add your data members here
    String _text="";
    ImpactMotorsMainForm _parent;
}

