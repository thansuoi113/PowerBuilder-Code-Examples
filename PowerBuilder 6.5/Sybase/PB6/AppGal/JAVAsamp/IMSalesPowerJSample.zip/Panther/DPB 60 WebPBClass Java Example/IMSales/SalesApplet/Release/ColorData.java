/*
    ColorData.java

    NOTE: This file is a generated file.
          Do not modify it by hand!
*/
// add your custom import statements here
/**
** This class is used to store various color information that can be passed
** to and from objects
**
**/
import java.util.StringTokenizer;
import java.lang.*;
import java.awt.*;
import powersoft.powerj.db.Query;

public class ColorData extends Object
{
/**
** constructor using Model ID
**/
public ColorData(String model, Query q){


      modelID = model ;
      // set query object
      query_1 = q;
      // call function to load App color data
      numColorValues = getAppColorData();
      // get color for model
      numColors = getModelColors();
      // set the number of non-dupe colors
      numNDColors = setNDNumColors();
}
/**
** called to get exterior color array
**/

public String[] getExteriorColors(){
     return sExterior;
}
/**
** called to get interior color array
**/
public String[] getInteriorColors(){

    return sInterior;
}
/**
** called to get a list of available interior colors for exterior color
**/
public String[] getInteriorRGBColors(String extColor){

    String colors[] = new String[32];   // temp color array
    int count=0;
    int i=0;
    int j=0;

    for(count =0; count < numColors; count++)
        {
            if(sExterior[count].equals(extColor))
                {
                    for (j=0; j<numColorValues; j++)
                    {
                        if (sdbColors[j].equals(sInterior[count]))
                        {
                            colors[i] = sdbColorValues[j];
                            i++;
                        }
                }
        }
        }
        return colors;
    }
/**
** return RGB value for colors from the db
**/
public int getRGB(String color)
    {
        int count=0;
        int colorVal=0;

        for (count=0; count < numColorValues; count++)
            {
                if ( sdbColors[count].equals(color))
                    {
                    colorVal = Integer.parseInt(sdbColorValues[count], 16);
                    }
            }
        return colorVal;
    }
private int getAppColorData()
{
    boolean result=false;
    String sql ="";
    int i=0;

    sql = "SELECT color_name, color_value FROM colors ";

    query_1.setSQL(sql);
    result = query_1.open();
    if (result)
        query_1.moveFirst(false, false);

    while (result)
        {
        sdbColors[i] = query_1.getValue(1).toString();
        sdbColorValues[i] =  query_1.getValue(2).toString().trim();

        result = query_1.moveNext(false, false);
        i++;
        }
return i;
}
/**
** get colors for model
**/
private int getModelColors()
{
    String sql="";
    boolean result = false;
    int i=0;

    sql ="SELECT model_colors.exterior_color, model_colors.interior_color FROM model_colors"+  
         " WHERE model_colors.model_class_id  = " +modelID;


    query_1.close();     
    query_1.setSQL(sql);
    result = query_1.open();
    if(result)
        query_1.moveFirst(false, false);

    while(result)
    {
        sExterior[i] = query_1.getValue(1).toString();
        sInterior[i] = query_1.getValue(2).toString().trim();
        result = query_1.moveNext(false, false);
        i++;


    }
    return i;
}
/**
**  set Exterior color for curent order
**/
public void setExteriorColor(String color)
{

    int count;

    for (count = 0; count < numColors; count++)
    {
        if(sExterior[count].toLowerCase().equals(color.toLowerCase() ))
        {

            extColor = count;
            cExt = new Color(getRGB(color.toLowerCase()));
            break;
        }

    }
}
/**
**  set Interior color for curent order
**/
public void setInteriorColor(String color)
{
    int count;
    for (count = 0; count < numColors; count++)
    {
        if(sInterior[count].toLowerCase().equals(color.toLowerCase() ))
        {
            intColor = count;
            cInt = new Color(getRGB(color.toLowerCase()));
            break;
        }

    }
}
/**
**  get Interior color for curent order
**/
public String getInteriorColor()
{

    return sInterior[intColor];
}
/**
**  get Exterior color for curent order
**/
public String getExteriorColor()
{
    return sExterior[extColor];
}
/**
**  get number of colors for model class
**/
public int getNumColors()
{
    return numColors;
}
/**
**  get number of colors values in DB
**/
public int getNumColorValues()
{
    return numColorValues;
}
/**
** called to get App color array
**/
public String[] getAppColors(){

    return sdbColors;
}
/**
** called to get App color values array
**/
public String[] getAppColorValues(){

    return sdbColorValues;
}
/**
** called to get the model id for this instance
**/
public String getModelClass(){

    return modelID;
}
/**
** called to get current exterior selected color
**/
public int getExtColorIndex(){
    // index into exterior arrray
    return extColor;
}
/**
** called to get current interior selected color
**/
public int getIntColorIndex(){
    // index into interior arrray
    return intColor;
}
/**
** called to get the exterior rgb color values
**/
public String[] getExtRGB(){

    String colors[] = new String[32];
    int count;
    int i;

    for(count = 0; count < numColors;count++)
        {
            for(i=0; i < numColorValues; i++)
            {
                if(sExterior[count].equals(sdbColors[i]))
                    colors[count] = sdbColorValues[i];
            }
        }

    return colors;
}
/**
** called to get interior rgb color value
**/
public String[] getIntRGB(){

    String colors[] = new String[32];
    int count;
    int i;

    for(count = 0; count < numColors;count++)
        {
            for(i=0; i < numColorValues; i++)
            {
                if(sInterior[count].equals(sdbColors[i]))
                    colors[count] = sdbColorValues[i];
            }
        }

    return colors;
}
/**
** called to get non-dupe rgb interior color values for passed in exterior color
**/
public String[] getNDIntRGB(String extColor){

    String colors[] = new String[32];
    int count;
    int i=0;
    int j=0;

    for(count =0; count < numColors; count++)
        {
            if(sExterior[count].equals(extColor))
                {
                    for (j=0; j<numColorValues; j++)
                    {
                        if (sInterior[count].equals(sdbColors[j]))
                        {
                            //if(!(checkForDupe(colors, colors[i], i)))
                            //{
                            colors[i] = sdbColorValues[j];
                            i++;
                            //}
                        }
                }
        }
   }
        return colors;
}
/**
** called to get non-dupe rgb color value
**/
public String[] getNDExtRGB(){

    String colors[] = new String[32];
    int count;
    int i;
    int j=0;

    for(count = 0; count < numColors;count++)
        {
            for(i=0; i < numColorValues; i++)
            {
                if(sExterior[count].equals(sdbColors[i]))
                  if(!(checkForDupe(sExterior, sExterior[count], count)))
                    {
                    colors[j] = sdbColorValues[i];
                    j++;
                    }
            }
        }

    return colors;
}
/**
**  called to check for duplicate colors
**/
private boolean checkForDupe(String[] colors, String color, int index)
{
    String src[] = colors;
    String colr  = color;
    int count;
    int i;

    i = index;
    if (i==0)
        return false;
    src = colors;
        for(count=0; count < i; count++)
        {
         if (src[count].equals(colr))
            return true;
        }
        return false;
}
/**
**   set the number of non-dupe colors
**/
private int setNDNumColors()
{
    int count;
    int i=0;

    for(count =0; count < numColors; count++)
    {
        if( !(checkForDupe(sExterior, sExterior[count], count)))
            i++;
    }
    return i;
}
/**
**   get the number of non-dupe colors
**/
public int getNDNumColors()
{
 return numNDColors;
}
/**
**   get the color name from hex code
**/
public String getColorName( String hexColor)
{
    int count;
    int i;
    int len;
    String tmp="";
    // check size of string
    if( hexColor.length() != 6)
    {
       len = 6 - hexColor.length();
       for (i=0; i<len; i++)
           { tmp +="0";}
          tmp +=hexColor;
        }

      else
        tmp = hexColor;

    for (count=0; count<numColorValues;count++)
    {
        if(sdbColorValues[count].toLowerCase().equals(tmp))
            return sdbColors[count];
    }
    return "";
}
/**
** called to return a Color object for passed in hex value
**/
public Color getColorObj(String hexValue)
{
 Color color;
 int count;

        for(count=0; count<numColorValues;count++)
        {
            if (sdbColors[count].equals(hexValue))
                {
                color = new Color(Integer.parseInt(sdbColorValues[count], 16));
                return color;
                }

        }
        return null;
}
/**
**  called to return the size of passed in string array
**/
public int getArraySize(Object[] a)
{
    int count;

    for(count=0;count<a.length;count++)
       {
        if (a[count] == null)
            return count;
        }

     return count;

}
/**
* return a Color object for the exterior color
*/
public Color getExtColorObj()
{
    return cExt;
}
/**
* return a Color object for the exterior color
*/
public Color getIntColorObj()
{
    return cInt;
}
    // add your data members here

    // create object to retrieve color information from DPB object
    private String sExterior[] = new String[32];    // exterior color
    private String sInterior[]= new String[32];     // interior color
    private String sdbColors[] = new String[32];      // color names from db
    private String sdbColorValues[] = new String[32]; // hex color values from db
    private int    numColorValues;                  // the number of color values in the db
    private int    numColors;                          // the number of colors for model
    private String    modelID;                           // model number for color info
    private int    extColor;                          // exterior color for order. index into array
    private int    intColor;                          // interior color for order. index into array
    private Color  cExt;                              // exterior as Color object
    private Color  cInt;                              // interior as Color object
    private int    numNDColors;                     //the number of non-dupe colors for model
    powersoft.powerj.db.Query  query_1 = null;
}

