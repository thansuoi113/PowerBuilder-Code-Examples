function of_close()
{	
	jscallbackappeon("close");
}

function jscallbackappeon(as_data)
 {       
     if ( typeof(callbackappeon) == "function" )
     {                  
				callbackappeon(as_data);
     }
     else if (typeof(eon_android) == "object" ) 
     {  
				eon_android.callbackappeon(as_data);
     }  
}

