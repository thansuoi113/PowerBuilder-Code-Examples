	var status = 0;
	var autofix = 0;
	
	function AutoResizeImage(maxWidth,maxHeight,objImg){
		var img = new Image();
		img.src = objImg.src;
		var hRatio;
		var wRatio;
		var Ratio = 1;
		var w = img.width;
		var h = img.height;
		wRatio = maxWidth / w;
		hRatio = maxHeight / h;
	
		if (maxWidth ==0 && maxHeight==0){
			Ratio = 1; 
		}else if (maxWidth==0){
			if (hRatio<1) Ratio = hRatio;
		}else if (maxHeight==0){
			if (wRatio<1) Ratio = wRatio;
		}else if (wRatio<1 || hRatio<1){
			Ratio = (wRatio<=hRatio?wRatio:hRatio);
		}else if ((wRatio>1 || hRatio>1) ) {
			Ratio = (wRatio<=hRatio?wRatio:hRatio);
		}
	
	  if ( Ratio<1 || autofix==1) 
	  {
			w = w * Ratio;
			h = h * Ratio;
			if (Ratio>1  && autofix==1  ){
			  status = 1
			}else
			{
				status =0
			}			
		}
		objImg.height = h;
		objImg.width = w;
		//objImg.style.height = Math.round(h) +"px";
		//objImg.style.width = Math.round(w) +"px";

	}
	
    function cen()
	{  
		var img = document.getElementById('viewimg');
		var w=0;
		var h=0;
	
		if(status == 0){   
			if(document.documentElement)
			{
				w=document.documentElement.clientWidth;
				h=document.documentElement.clientHeight;			
			}
			else
			{
			w=document.body.clientWidth;
			h=document.body.clientHeight;			
			}
			status = 1;
		}else{  		  
		  status = 0;
		}
		
		AutoResizeImage(w,h,img);
		
		var ch;
		if(document.documentElement)
		{
			ch =document.documentElement.clientHeight;
		}
		else
		{
			ch=document.body.clientHeight;			
		}

		var topvalue = (ch - img.clientHeight)/2;  
		if (topvalue > 0 )
		{
			img.style.marginTop = topvalue;  
		}
		else
		{
			img.style.marginTop="0px";
		}

	}  
	
	function setimagepath(path)
	{
		path = './'+path;	
		setimage(path);				
		return 1;
	}
	
	function setimagepath2(path)
	{	
		path = path+".jpg";
		setimagepath(path);
		return 1;
	}
	
	
	
	function setimage(path)
	{	
		cleanp();
		status=0;
		var img = document.getElementById('viewimg');		
		img.style.display="inline";
		img.src=path;
			
		/*
		var h;
		
		if(document.documentElement)
		{
			h =document.documentElement.clientHeight;
		}
		else
		{
			h=document.body.clientHeight;			
		}

		var topvalue = (h - img.clientHeight)/2;  
		img.style.marginTop = topvalue;  
		*/
		
		//cen();
		return 1;
	}
	
	function setmsgtext(text)
	{
		var img = document.getElementById('viewimg');	
		img.src="";	
		img.style.display="none";

		cleanp();
		status=0;

		var divname = document.getElementById("contentdiv");  
		var para = document.createElement("p");
		var node = document.createTextNode( text);
		para.appendChild(node);
		divname.appendChild(para);
		return 1;

	}

	function cleanp()
	{
		var divname = document.getElementById("contentdiv");  
		var op = document.getElementsByTagName("p");
		for(var i = 0; i <op.length; i++)
		{
			var np = op[i];
			divname.removeChild(np);
		}
	}

	function cleanall()
	{
		var img = document.getElementById('viewimg');	
		img.src="";	
		img.style.display="none";

		cleanp();
		return 1;
	}

