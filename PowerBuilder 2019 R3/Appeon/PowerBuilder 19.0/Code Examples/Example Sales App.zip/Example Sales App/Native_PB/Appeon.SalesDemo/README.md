Welcome to this Sales CRM Demo application!

The application contains the basic function modules about sales order processing. Please use it to experience and learn the following PowerBuilder features:

•	RibbonBar implementation (For the RibbonBar definition file, see the ribbonbar_show.xml in the application folder);

•	UI theme and its customization (For the theme settings, see the Theme folder in the application folder);

•	Loading JavaScript in WebBrowser for reporting (For more information, see the bubble.html, column1.html, line.html, and loader.js files in the application folders). 
