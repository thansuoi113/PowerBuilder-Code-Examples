/*
    _WebPBSample_frame.java

    NOTE: This file is a generated file.
          Do not modify it by hand!
*/
// add your custom import statements here

public class _WebPBSample_frame extends java.awt.Frame
{
    public _WebPBSample_frame()
    {
        super();
    }
    public boolean handleEvent(java.awt.Event event)
    {
        Object pEvtSource = event.target;
        if( pEvtSource == this && event.id == java.awt.Event.WINDOW_DESTROY ) {
            hide();
            dispose();
            System.exit( 0 );
            return false;
        } else {
            return super.handleEvent( event );
        }
    }
    // add your data members here
}

