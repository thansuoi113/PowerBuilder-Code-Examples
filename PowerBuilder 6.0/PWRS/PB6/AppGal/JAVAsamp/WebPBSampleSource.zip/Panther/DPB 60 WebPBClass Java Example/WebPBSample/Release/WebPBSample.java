/*
    WebPBSample.java

    NOTE: This file is a generated file.
          Do not modify it by hand!
*/
// add your custom import statements here

public class WebPBSample extends MainForm 
{
    public WebPBSample()
    {
        super();
    }
    public void init()
    {
        super.init();
        addNotify();
        createAppletForm();
        
        set_webpb(getParameter("webpb"));
        set_url(getParameter("url"));
        
    }
    public void createAppletForm()
    {
        try {
            create();
        } catch ( java.lang.Exception __e ) {}
    }
    public static void main(String args[])
    {
        WebPBSample applet = new WebPBSample();
        _WebPBSample_frame f = new _WebPBSample_frame();
        f.setResizable(false);
        f.add(applet);
        f.addNotify();
        java.awt.Insets insets = f.insets();
        applet.setMainForm(true);
        applet.init();
        applet.move(insets.left,insets.top);
        f.resize(applet.preferredSize());
        applet.resize(applet.preferredSize());
        f.show();
    }
    // add your data members here
}

