/*
    MainForm.java

    NOTE: This file is a generated file.
          Do not modify it by hand!
*/
import java.awt.Color;
import java.awt.Event;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Rectangle;
import java.awt.Insets;
import java.lang.Math;
import java.lang.String;

// custom imports for MainForm
// add your custom import statements here
import jdbc.sql.SQLException;
import powersoft.powerj.webpb.jdbc_sql.WebPBResultSet;
import powersoft.powerj.webpb.jdbc_sql.WebPBResultSetMetaData;// add your custom import statements here


class MainForm extends java.applet.Applet implements powersoft.powerj.event.ClickListener
{
    public Rectangle DURectangle( int x, int y, int w, int h )
    {
        String        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        FontMetrics   fm = getFontMetrics( getFont() );
        double        fw = ( fm != null ) ? ( fm.stringWidth( alphabet ) / alphabet.length() ) : 0;
        double        fh = ( fm != null ) ? ( fm.getHeight() / 2.0 ) : 0.0;

        return new Rectangle( (int) Math.round( ( (double)fw * (double)x ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)y ) / 4.0 ),
                              (int) Math.round( ( (double)fw * (double)w ) / 4.0 ),
                              (int) Math.round( ( (double)fh * (double)h ) / 4.0 ) );
    }

    public void DUPositionComponent( java.awt.Component comp, int x, int y, int w, int h, java.awt.Insets formInsets )
    {
        Rectangle     rect = DURectangle( x, y, w, h );
        if( formInsets != null ) {
             rect.x += formInsets.left;
             rect.y += formInsets.top;
        }
        comp.reshape( rect.x, rect.y, rect.width, rect.height );
    }

    public void setMainForm( boolean isMainForm )
    {
        __mainForm = isMainForm;
    }
    public boolean isMainForm()
    {
        return __mainForm;
    }
    public boolean create() throws java.lang.Exception
    {
        setFont( new Font( "Dialog", Font.PLAIN, 12 ) );

        boolean retval = true;
        if( getPeer() == null ) {
            addNotify();
        }
        show();
        Insets formInsets = insets();
        hide();
        setBackground( Color.white );
        setForeground( Color.black );

        powersoft.powerj.ui.ResizePercentLayout layout = new powersoft.powerj.ui.ResizePercentLayout();
        setLayout( layout );
        groupb_textcontrols.setLayout( null );
        add(groupb_textcontrols);
        groupb_textcontrols.add(dataNavigator_1);
        groupb_textcontrols.add(textf_fname);
        groupb_textcontrols.add(textf_address1);
        groupb_textcontrols.add(textf_empuserid);
        groupb_textcontrols.add(textf_empcity);
        groupb_textcontrols.add(textf_empstate);
        groupb_textcontrols.add(textf_lname);
        groupb_textcontrols.add(label_14);
        groupb_textcontrols.add(label_20);
        groupb_textcontrols.add(label_21);
        groupb_textcontrols.add(label_22);
        groupb_textcontrols.add(label_23);
        groupb_textcontrols.add(label_24);
        groupb_textcontrols.add(textf_empzipcode);
        groupb_textcontrols.add(label_25);
        groupb_textcontrols.add(textf_empstartdate);
        groupb_textcontrols.add(textf_emphomephone);
        groupb_textcontrols.add(label_26);
        groupb_textcontrols.add(label_27);
        groupb_textcontrols.add(textf_empid);
        groupb_textcontrols.add(textf_deptid);
        groupb_textcontrols.add(label_28);
        groupb_textcontrols.add(label_29);
        groupb_textcontrols.add(textf_empssnum);
        groupb_textcontrols.add(label_30);
        groupb_textcontrols.add(textf_empsalary);
        groupb_textcontrols.add(label_31);
        groupb_textcontrols.add(textf_empbirthdate);
        groupb_textcontrols.add(label_32);
        groupb_textcontrols.add(textf_empsex);
        groupb_textcontrols.add(label_33);
        add(pictbttn_retrieve);
        DUPositionComponent( this, 0, 0, 339, 224, null );

        query_1.setTraceToLog( true );
        query_1.setName( "MainForm.query_1" );
        query_1.setTransactionObject( powersoft.powerj.db.Transaction.findByName(null, false ) );
        DUPositionComponent( groupb_textcontrols, 10, 25, 320, 180, formInsets );
        groupb_textcontrols.setFont( new Font( "Dialog", Font.PLAIN, 10 ) );
        groupb_textcontrols.setBackground( Color.lightGray );
        groupb_textcontrols.setForeground( Color.black );
        groupb_textcontrols.enable(true);
        groupb_textcontrols.show();

        groupb_textcontrols.setText("Bound Text Controls");

        DUPositionComponent( dataNavigator_1, 60, 156, 176, 16, null );
        dataNavigator_1.setBackground( Color.lightGray );
        dataNavigator_1.setForeground( Color.black );
        dataNavigator_1.enable(true);
        dataNavigator_1.show();

        dataNavigator_1.setDataSource( powersoft.powerj.db.Query.findByName( "MainForm.query_1", false ) );
        dataNavigator_1.setBOFAction(powersoft.powerj.ui.DataNavigator.ACTION_MOVE_FIRST);
        dataNavigator_1.setEOFAction(powersoft.powerj.ui.DataNavigator.ACTION_MOVE_LAST);
        dataNavigator_1.setShowAdd(false);
        dataNavigator_1.setShowCancel(false);
        dataNavigator_1.setShowDelete(false);
        dataNavigator_1.setShowEdit(false);
        dataNavigator_1.setShowMoveFirst(false);
        dataNavigator_1.setShowMoveLast(false);
        dataNavigator_1.setShowMoveNext(false);
        dataNavigator_1.setShowMovePrevious(false);
        dataNavigator_1.setShowUpdate(false);

        dataNavigator_1_objectCreated( new powersoft.powerj.event.EventData( dataNavigator_1 ) );
        DUPositionComponent( textf_fname, 16, 24, 64, 12, null );
        textf_fname.setBackground( Color.lightGray );
        textf_fname.setForeground( Color.black );
        textf_fname.setDataSource( powersoft.powerj.db.Query.findByName( "MainForm.query_1", false ) );
        textf_fname.enable(true);
        textf_fname.show();


        DUPositionComponent( textf_address1, 16, 52, 172, 12, null );
        textf_address1.setBackground( Color.lightGray );
        textf_address1.setForeground( Color.black );
        textf_address1.setDataSource( powersoft.powerj.db.Query.findByName( "MainForm.query_1", false ) );
        textf_address1.enable(true);
        textf_address1.show();


        DUPositionComponent( textf_empuserid, 200, 52, 88, 12, null );
        textf_empuserid.setBackground( Color.lightGray );
        textf_empuserid.setForeground( Color.black );
        textf_empuserid.setDataSource( powersoft.powerj.db.Query.findByName( "MainForm.query_1", false ) );
        textf_empuserid.enable(true);
        textf_empuserid.show();


        DUPositionComponent( textf_empcity, 16, 80, 64, 12, null );
        textf_empcity.setBackground( Color.lightGray );
        textf_empcity.setForeground( Color.black );
        textf_empcity.setDataSource( powersoft.powerj.db.Query.findByName( "MainForm.query_1", false ) );
        textf_empcity.enable(true);
        textf_empcity.show();


        DUPositionComponent( textf_empstate, 92, 80, 16, 12, null );
        textf_empstate.setBackground( Color.lightGray );
        textf_empstate.setForeground( Color.black );
        textf_empstate.setDataSource( powersoft.powerj.db.Query.findByName( "MainForm.query_1", false ) );
        textf_empstate.enable(true);
        textf_empstate.show();


        DUPositionComponent( textf_lname, 88, 24, 100, 12, null );
        textf_lname.setBackground( Color.lightGray );
        textf_lname.setForeground( Color.black );
        textf_lname.setDataSource( powersoft.powerj.db.Query.findByName( "MainForm.query_1", false ) );
        textf_lname.enable(true);
        textf_lname.show();


        DUPositionComponent( label_14, 10, 12, 62, 10, null );
        label_14.setAlignment(java.awt.Label.LEFT);
        label_14.setText( "First Name" );
        label_14.setBackground( Color.lightGray );
        label_14.setForeground( Color.black );
        label_14.enable(true);
        label_14.show();


        DUPositionComponent( label_20, 82, 12, 62, 10, null );
        label_20.setAlignment(java.awt.Label.LEFT);
        label_20.setText( "Last Name" );
        label_20.setBackground( Color.lightGray );
        label_20.setForeground( Color.black );
        label_20.enable(true);
        label_20.show();


        DUPositionComponent( label_21, 10, 43, 62, 10, null );
        label_21.setAlignment(java.awt.Label.LEFT);
        label_21.setText( "Address 1" );
        label_21.setBackground( Color.lightGray );
        label_21.setForeground( Color.black );
        label_21.enable(true);
        label_21.show();


        DUPositionComponent( label_22, 194, 12, 46, 10, null );
        label_22.setAlignment(java.awt.Label.CENTER);
        label_22.setText( "Emp ID" );
        label_22.setBackground( Color.lightGray );
        label_22.setForeground( Color.black );
        label_22.enable(true);
        label_22.show();


        DUPositionComponent( label_23, 10, 72, 62, 10, null );
        label_23.setAlignment(java.awt.Label.LEFT);
        label_23.setText( "City" );
        label_23.setBackground( Color.lightGray );
        label_23.setForeground( Color.black );
        label_23.enable(true);
        label_23.show();


        DUPositionComponent( label_24, 86, 72, 22, 10, null );
        label_24.setAlignment(java.awt.Label.LEFT);
        label_24.setText( "State" );
        label_24.setBackground( Color.lightGray );
        label_24.setForeground( Color.black );
        label_24.enable(true);
        label_24.show();


        DUPositionComponent( textf_empzipcode, 120, 80, 70, 12, null );
        textf_empzipcode.setBackground( Color.lightGray );
        textf_empzipcode.setForeground( Color.black );
        textf_empzipcode.setDataSource( powersoft.powerj.db.Query.findByName( "MainForm.query_1", false ) );
        textf_empzipcode.enable(true);
        textf_empzipcode.show();


        DUPositionComponent( label_25, 114, 72, 76, 10, null );
        label_25.setAlignment(java.awt.Label.LEFT);
        label_25.setText( "Zip Code" );
        label_25.setBackground( Color.lightGray );
        label_25.setForeground( Color.black );
        label_25.enable(true);
        label_25.show();


        DUPositionComponent( textf_empstartdate, 16, 132, 70, 12, null );
        textf_empstartdate.setBackground( Color.lightGray );
        textf_empstartdate.setForeground( Color.black );
        textf_empstartdate.setDataSource( powersoft.powerj.db.Query.findByName( "MainForm.query_1", false ) );
        textf_empstartdate.enable(true);
        textf_empstartdate.show();


        DUPositionComponent( textf_emphomephone, 104, 132, 70, 12, null );
        textf_emphomephone.setBackground( Color.lightGray );
        textf_emphomephone.setForeground( Color.black );
        textf_emphomephone.setDataSource( powersoft.powerj.db.Query.findByName( "MainForm.query_1", false ) );
        textf_emphomephone.enable(true);
        textf_emphomephone.show();


        DUPositionComponent( label_26, 10, 124, 76, 10, null );
        label_26.setAlignment(java.awt.Label.LEFT);
        label_26.setText( "Start Date" );
        label_26.setBackground( Color.lightGray );
        label_26.setForeground( Color.black );
        label_26.enable(true);
        label_26.show();


        DUPositionComponent( label_27, 98, 124, 76, 10, null );
        label_27.setAlignment(java.awt.Label.LEFT);
        label_27.setText( "Home Phone" );
        label_27.setBackground( Color.lightGray );
        label_27.setForeground( Color.black );
        label_27.enable(true);
        label_27.show();


        DUPositionComponent( textf_empid, 200, 24, 40, 12, null );
        textf_empid.setBackground( Color.lightGray );
        textf_empid.setForeground( Color.black );
        textf_empid.setDataSource( powersoft.powerj.db.Query.findByName( "MainForm.query_1", false ) );
        textf_empid.enable(true);
        textf_empid.show();


        DUPositionComponent( textf_deptid, 248, 24, 40, 12, null );
        textf_deptid.setBackground( Color.lightGray );
        textf_deptid.setForeground( Color.black );
        textf_deptid.setDataSource( powersoft.powerj.db.Query.findByName( "MainForm.query_1", false ) );
        textf_deptid.enable(true);
        textf_deptid.show();


        DUPositionComponent( label_28, 242, 12, 46, 10, null );
        label_28.setAlignment(java.awt.Label.CENTER);
        label_28.setText( "Dept. ID" );
        label_28.setBackground( Color.lightGray );
        label_28.setForeground( Color.black );
        label_28.enable(true);
        label_28.show();


        DUPositionComponent( label_29, 194, 44, 50, 8, null );
        label_29.setAlignment(java.awt.Label.LEFT);
        label_29.setText( "User ID" );
        label_29.setBackground( Color.lightGray );
        label_29.setForeground( Color.black );
        label_29.enable(true);
        label_29.show();


        DUPositionComponent( textf_empssnum, 16, 108, 70, 12, null );
        textf_empssnum.setBackground( Color.lightGray );
        textf_empssnum.setForeground( Color.black );
        textf_empssnum.setDataSource( powersoft.powerj.db.Query.findByName( "MainForm.query_1", false ) );
        textf_empssnum.enable(true);
        textf_empssnum.show();


        DUPositionComponent( label_30, 10, 100, 76, 10, null );
        label_30.setAlignment(java.awt.Label.LEFT);
        label_30.setText( "Social Security #" );
        label_30.setBackground( Color.lightGray );
        label_30.setForeground( Color.black );
        label_30.enable(true);
        label_30.show();


        DUPositionComponent( textf_empsalary, 104, 108, 70, 12, null );
        textf_empsalary.setBackground( Color.lightGray );
        textf_empsalary.setForeground( Color.black );
        textf_empsalary.setDataSource( powersoft.powerj.db.Query.findByName( "MainForm.query_1", false ) );
        textf_empsalary.enable(true);
        textf_empsalary.show();


        DUPositionComponent( label_31, 98, 100, 74, 8, null );
        label_31.setAlignment(java.awt.Label.LEFT);
        label_31.setText( "Salary" );
        label_31.setBackground( Color.lightGray );
        label_31.setForeground( Color.black );
        label_31.enable(true);
        label_31.show();


        DUPositionComponent( textf_empbirthdate, 196, 108, 70, 12, null );
        textf_empbirthdate.setBackground( Color.lightGray );
        textf_empbirthdate.setForeground( Color.black );
        textf_empbirthdate.setDataSource( powersoft.powerj.db.Query.findByName( "MainForm.query_1", false ) );
        textf_empbirthdate.enable(true);
        textf_empbirthdate.show();


        DUPositionComponent( label_32, 190, 96, 76, 10, null );
        label_32.setAlignment(java.awt.Label.LEFT);
        label_32.setText( "Birthday" );
        label_32.setBackground( Color.lightGray );
        label_32.setForeground( Color.black );
        label_32.enable(true);
        label_32.show();


        DUPositionComponent( textf_empsex, 208, 132, 12, 12, null );
        textf_empsex.setBackground( Color.lightGray );
        textf_empsex.setForeground( Color.black );
        textf_empsex.setDataSource( powersoft.powerj.db.Query.findByName( "MainForm.query_1", false ) );
        textf_empsex.enable(true);
        textf_empsex.show();


        DUPositionComponent( label_33, 190, 124, 76, 10, null );
        label_33.setAlignment(java.awt.Label.LEFT);
        label_33.setText( "Employee Sex" );
        label_33.setBackground( Color.lightGray );
        label_33.setForeground( Color.black );
        label_33.enable(true);
        label_33.show();



        pictbttn_retrieve.addClickListener(this);
        DUPositionComponent( pictbttn_retrieve, 230, 10, 100, 14, formInsets );
        pictbttn_retrieve.setBackground( Color.lightGray );
        pictbttn_retrieve.setForeground( Color.black );
        pictbttn_retrieve.enable(true);
        pictbttn_retrieve.show();

        Rectangle pictbttn_retrieve_size_rect = DURectangle( 0, 0, 100, 14);
        pictbttn_retrieve.resize(pictbttn_retrieve_size_rect.width,pictbttn_retrieve_size_rect.height);
        pictbttn_retrieve.setLabel("Retrieve Employees");
        pictbttn_retrieve.setLabelPosition( powersoft.powerj.ui.PictureButton.LABEL_BOTTOM );
        pictbttn_retrieve.setInsets( new java.awt.Insets(5,5,5,5) );
        pictbttn_retrieve.setShowFocus( true );

        layout.setResizePercent(groupb_textcontrols,new java.awt.Rectangle(0,0,0,0));
        layout.setResizePercent(pictbttn_retrieve,new java.awt.Rectangle(0,0,0,0));
        query_1.setAutoEdit(true);
        query_1.setAllowUpdates(true);
        query_1.setUpdateConnectionMode( powersoft.powerj.db.Query.NO_AUTOCONNECT );
        query_1.setUpdateMode( powersoft.powerj.db.Query.IMMEDIATE_UPDATES );
        query_1.setUpdateType( powersoft.powerj.db.Query.KEYS_ONLY );
        query_1.setKeyUpdate( powersoft.powerj.db.Query.USE_UPDATE );
        query_1.setBindUpdates(true);
        query_1.setQueryTimeout( 0 );
        query_1.setSQL("");
        if( query_1.open() ){
            query_1.moveNext( true, true );
        }

        show();
        return retval;
    }

    public synchronized void destroy()
    {
        query_1.destroy();
        if( (java.awt.Container)this instanceof java.awt.Window ) {
            ((java.awt.Window)(java.awt.Container)this).dispose();
        } else {
            removeNotify();
        }
        if( isMainForm() ) {
            System.gc();
            System.runFinalization();
            System.exit(0);
        }
    }


    public boolean defaultHandleEvent(java.awt.Event event)
    {
        return super.handleEvent(event);
    }

    public void click( powersoft.powerj.event.ClickEvent event )
    {
        Object eventTarget = event.getSource();
        if( eventTarget == pictbttn_retrieve ) {
            pictbttn_retrieve_click( event );
        } else {
            unhandledEvent( "powersoft.powerj.event.ClickListener", "click", event );
        }
    }
    public MainForm()
    {
        super();
    }
    public boolean handleEvent(java.awt.Event event)
    {

        return defaultHandleEvent(event);
    }
    public void unhandledEvent( String listenerName, String methodName, java.lang.Object event )
    {

    }
    public void bindControls()
    {
          // set control binding   

//       textf_empid.setDataSource( query_1 );
       textf_empid.setDataColumns( "1" );


//       textf_deptid.setDataSource( query_1 );
       textf_deptid.setDataColumns( "2" );

//       textf_empuserid.setDataSource( query_1 );
       textf_empuserid.setDataColumns( "3" );

//       textf_lname.setDataSource( query_1 );
       textf_lname.setDataColumns( "4" );

//       textf_fname.setDataSource( query_1 );
       textf_fname.setDataColumns( "5" );

//       textf_address1.setDataSource( query_1 );
       textf_address1.setDataColumns( "6" );

//       textf_empcity.setDataSource( query_1 );
       textf_empcity.setDataColumns( "7" );

//       textf_empstate.setDataSource( query_1 );
       textf_empstate.setDataColumns( "8" );

//       textf_empzipcode.setDataSource( query_1 );
       textf_empzipcode.setDataColumns( "9" );

//       textf_empssnum.setDataSource( query_1 );
       textf_empssnum.setDataColumns( "10" );

//       textf_empsalary.setDataSource( query_1 );
       textf_empsalary.setDataColumns( "11" );

//       textf_empstartdate.setDataSource( query_1 );
       textf_empstartdate.setDataColumns( "12" );

//       textf_empbirthdate.setDataSource( query_1 );
       textf_empbirthdate.setDataColumns( "13" );

//       textf_empsex.setDataSource( query_1 );
       textf_empsex.setDataColumns( "14" );

//       textf_emphomephone.setDataSource( query_1 );
       textf_emphomephone.setDataColumns( "15" );

//       dataNavigator_1.setDataSource( query_1 );

    }
    public void setControls()
    {
     int rCnt=0, cCnt=0;
     int result;
     boolean lastresult=false;
     String resultSet = "";
     String temp="";
     String label="";
     int width=0;

//openMsgWindow()

        _sDPBServer="niexdpbs";
        _sDPBObject="n_cst_java";
        _sDPBMethod="of_getemployees";
        _sDPBArgs="";

       _PBObject.setResultSetConsumer( query_1 );

       result = _PBObject.retrieve(_sURLBase, _sDPBServer, _sDPBObject, _sDPBMethod, _sDPBArgs );


         if ( result > 0 ) 
            {
                bindControls();
                query_1.moveNext( true, true );
            }
          else if (result < 0)
          { 
              System.out.println("Error Retrieving data: "+_PBObject.getErrorMsg());
//              setStatusText("Error Retrieving data: "+_PBObject.getErrorMsg());
          }

//closeMsgWindow();

    }
    //
    // _url Property
    //

    public String get_url()
    {
        return _sIPAdress;
    }

    public void set_url( String newValue )
    {
         _sIPAdress= newValue;
         _sURLBase ="http://" + _sIPAdress + _sWebPBLoc;

    }
    //
    // _webpb Property
    //

    public String get_webpb()
    {
        return _sWebPBLoc;
    }

    public void set_webpb( String newValue )
    {
        _sWebPBLoc = newValue;
        _sURLBase ="http://" + _sIPAdress + _sWebPBLoc;

    }
    public boolean dataNavigator_1_objectCreated(powersoft.powerj.event.EventData event)
    {
        dataNavigator_1.setShowMoveFirst( true );
        dataNavigator_1.setShowMoveLast( true );
        dataNavigator_1.setShowMoveNext( true );
        dataNavigator_1.setShowMovePrevious( true );


        return false;
    }
    public void pictbttn_retrieve_click( powersoft.powerj.event.ClickEvent event )
    {
    setControls();    

    }
    /****************************************
     * data members
     ****************************************/

    boolean __mainForm = false;

    private  powersoft.powerj.ui.GroupBox  groupb_textcontrols = new powersoft.powerj.ui.GroupBox();
    private  powersoft.powerj.ui.DataNavigator  dataNavigator_1 = new powersoft.powerj.ui.DataNavigator();
    private  powersoft.powerj.ui.DBTextField  textf_fname = new powersoft.powerj.ui.DBTextField();
    private  powersoft.powerj.ui.DBTextField  textf_address1 = new powersoft.powerj.ui.DBTextField();
    private  powersoft.powerj.ui.DBTextField  textf_empuserid = new powersoft.powerj.ui.DBTextField();
    private  powersoft.powerj.ui.DBTextField  textf_empcity = new powersoft.powerj.ui.DBTextField();
    private  powersoft.powerj.ui.DBTextField  textf_empstate = new powersoft.powerj.ui.DBTextField();
    private  powersoft.powerj.ui.DBTextField  textf_lname = new powersoft.powerj.ui.DBTextField();
    private  java.awt.Label  label_14 = new java.awt.Label();
    private  java.awt.Label  label_20 = new java.awt.Label();
    private  java.awt.Label  label_21 = new java.awt.Label();
    private  java.awt.Label  label_22 = new java.awt.Label();
    private  java.awt.Label  label_23 = new java.awt.Label();
    private  java.awt.Label  label_24 = new java.awt.Label();
    private  powersoft.powerj.ui.DBTextField  textf_empzipcode = new powersoft.powerj.ui.DBTextField();
    private  java.awt.Label  label_25 = new java.awt.Label();
    private  powersoft.powerj.ui.DBTextField  textf_empstartdate = new powersoft.powerj.ui.DBTextField();
    private  powersoft.powerj.ui.DBTextField  textf_emphomephone = new powersoft.powerj.ui.DBTextField();
    private  java.awt.Label  label_26 = new java.awt.Label();
    private  java.awt.Label  label_27 = new java.awt.Label();
    private  powersoft.powerj.ui.DBTextField  textf_empid = new powersoft.powerj.ui.DBTextField();
    private  powersoft.powerj.ui.DBTextField  textf_deptid = new powersoft.powerj.ui.DBTextField();
    private  java.awt.Label  label_28 = new java.awt.Label();
    private  java.awt.Label  label_29 = new java.awt.Label();
    private  powersoft.powerj.ui.DBTextField  textf_empssnum = new powersoft.powerj.ui.DBTextField();
    private  java.awt.Label  label_30 = new java.awt.Label();
    private  powersoft.powerj.ui.DBTextField  textf_empsalary = new powersoft.powerj.ui.DBTextField();
    private  java.awt.Label  label_31 = new java.awt.Label();
    private  powersoft.powerj.ui.DBTextField  textf_empbirthdate = new powersoft.powerj.ui.DBTextField();
    private  java.awt.Label  label_32 = new java.awt.Label();
    private  powersoft.powerj.ui.DBTextField  textf_empsex = new powersoft.powerj.ui.DBTextField();
    private  java.awt.Label  label_33 = new java.awt.Label();
    private  powersoft.powerj.db.jdbc_sql.Query  query_1 = new powersoft.powerj.db.jdbc_sql.Query();
    private  powersoft.powerj.ui.PictureButton  pictbttn_retrieve = new powersoft.powerj.ui.PictureButton();

    // add your data members here
   powersoft.powerj.webpb.jdbc_sql.WebPBCall _PBObject = new powersoft.powerj.webpb.jdbc_sql.WebPBCall();
    WebPBResultSetMetaData _wpbResultSetMetadata = null;          // result set metadata  
    WebPBResultSet _wpbResultSet = null;          // result set data  
    private String _sIPAdress = new String(""); // parameters for DPBCall
    private String _sWebPBLoc = new String(""); // the location of the web.pb files
    String _sURLBase ="http://" + _sIPAdress + _sWebPBLoc;                    //      "
    private String _sDPBServer = new String("niexdpbs");        //      "
    private String _sDPBObject = new String("n_cst_java");  //      "
    private String _sDPBMethod = new String("");          //      "
    private String _sDPBArgs = new String("");             //      "
    int _row=1, _column=1;
}

