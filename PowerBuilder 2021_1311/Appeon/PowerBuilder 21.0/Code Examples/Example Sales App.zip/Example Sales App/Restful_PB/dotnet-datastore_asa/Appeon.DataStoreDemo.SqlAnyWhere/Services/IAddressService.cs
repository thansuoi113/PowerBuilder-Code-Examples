﻿namespace Appeon.DataStoreDemo.SqlAnywhere.Services
{
    public interface IAddressService : IServiceBase
    {

    }

}
